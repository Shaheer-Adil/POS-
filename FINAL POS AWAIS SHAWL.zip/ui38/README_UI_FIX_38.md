# UI Fix 38

- Admin username changed to `bashir`.
- Admin password changed to `bashir`.
- Existing admin accounts are updated during database initialization so the new credentials work with an existing database.
- Staff login remains unchanged.
