using System.Drawing;
using System.Windows.Forms;

namespace ShopManagementSystem;

/// <summary>
/// Adds a dedicated, non-overlapping navigation area to child pages.
/// The page content is automatically pushed down because the bar is docked at the top.
/// </summary>
public static class BackButtonHelper
{
    public static void AddBackButton(Form form)
    {
        // All application pages that use the standard Back button open maximized.
        // LoginForm intentionally does not use this helper, so the login window
        // keeps its normal fixed size.
        form.WindowState = FormWindowState.Maximized;
        form.StartPosition = FormStartPosition.CenterScreen;

        var navigationBar = new Panel
        {
            Dock = DockStyle.Top,
            Height = 58,
            Padding = new Padding(14, 8, 14, 8),
            BackColor = Color.White
        };

        var backButton = new Button
        {
            Text = "Back",
            Dock = DockStyle.Left,
            Width = 90,
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.Red,
            ForeColor = Color.Black,
            FlatAppearance = { BorderSize = 0 },
            TabStop = false,
            AccessibleName = "Back",
            AccessibleDescription = "Go back to the previous page"
        };

        backButton.Click += (_, _) => form.Close();
        navigationBar.Controls.Add(backButton);

        // Add last so the top-docked navigation bar is laid out before the
        // existing DockStyle.Fill/top/bottom content. This reserves space
        // instead of drawing over any existing controls.
        form.Controls.Add(navigationBar);
    }
}
