using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

/// <summary>Step 30: simple salary screen. Select any salesman, see fixed salary and advances deducted automatically.</summary>
public class UnifiedSalaryManagementForm : Form
{
    private readonly SalaryService service = new();
    private readonly DataGridView grid = new();
    private readonly NumericUpDown advanceBox = new();
    private readonly Label selectedLabel = new();
    private readonly Label fixedLabel = new();
    private readonly Label commissionLabel = new();
    private readonly Label advanceLabel = new();
    private readonly Label payableLabel = new();
    private readonly DateTimePicker monthPicker = new();

    public UnifiedSalaryManagementForm()
    {
        if (!AuthorizationService.RequireAdmin(this, "Salary management")) return;
        Text = "Salary Management"; StartPosition = FormStartPosition.CenterScreen; Size = new Size(1180, 760); MinimumSize = new Size(1000, 650);
        BuildUi(); LoadGrid(); BackButtonHelper.AddBackButton(this);
    }

    private void BuildUi()
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(18), ColumnCount = 1, RowCount = 3 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 62)); root.RowStyles.Add(new RowStyle(SizeType.Percent, 65)); root.RowStyles.Add(new RowStyle(SizeType.Percent, 35));
        root.Controls.Add(new Label { Text = "SALARY MANAGEMENT\r\rSelect a salesman to view salary and automatic advance deduction.", Dock = DockStyle.Fill, Font = new Font("Segoe UI", 15, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft }, 0, 0);
        ConfigureGrid(); root.Controls.Add(grid, 0, 1);

        var bottom = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 3, Margin = new Padding(0), Padding = new Padding(0) };
        // Keep the salary details comfortably above Refresh with a professional gap.
        bottom.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        bottom.RowStyles.Add(new RowStyle(SizeType.Absolute, 176));
        bottom.RowStyles.Add(new RowStyle(SizeType.Absolute, 44));
        bottom.Controls.Add(new Panel { Dock = DockStyle.Fill, Margin = new Padding(0) }, 0, 0);
        bottom.Controls.Add(BuildDetails(), 0, 1);
        bottom.Controls.Add(BuildAdvanceHistory(), 0, 2);
        root.Controls.Add(bottom, 0, 2);
        Controls.Add(root);
    }

    private void ConfigureGrid()
    {
        grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.AllowUserToAddRows = false; grid.AutoGenerateColumns = false; grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; grid.MultiSelect = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Name", HeaderText = "SALESMAN" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Code", HeaderText = "CODE" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Salary", HeaderText = "FIXED SALARY" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Commission", HeaderText = "COMMISSION" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Advances", HeaderText = "ADVANCES" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Payable", HeaderText = "REMAINING / PAYABLE" });
        var statusColumn = new DataGridViewTextBoxColumn
        {
            Name = "Status",
            HeaderText = "STATUS",
            DefaultCellStyle = new DataGridViewCellStyle
            {
                Alignment = DataGridViewContentAlignment.MiddleCenter,
                Font = new Font("Segoe UI", 9, FontStyle.Bold)
            }
        };
        statusColumn.HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
        statusColumn.HeaderCell.Style.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        grid.Columns.Add(statusColumn);
        grid.SelectionChanged += (_, _) => RefreshSelected();
    }

    private void LoadGrid()
    {
        try
        {
            var rows = service.GetCurrentSummaries();
            var monthStart = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            using var db = new ShopDbContext();
            var paidSalesmanIds = db.SalaryPayments.AsNoTracking()
                .Where(x => x.PayrollMonth == monthStart)
                .Select(x => x.SalesmanId)
                .ToHashSet();

            grid.Rows.Clear();
            foreach (var x in rows)
            {
                var status = paidSalesmanIds.Contains(x.SalesmanId) ? "PAID" : "PENDING";
                grid.Rows.Add(
                    x.Name,
                    x.Code,
                    $"Rs. {x.MonthlySalary:#,##0.##}",
                    $"Rs. {x.CommissionThisMonth:#,##0.##}",
                    $"Rs. {x.AdvancesThisMonth:#,##0.##}",
                    $"Rs. {x.RemainingSalary:#,##0.##}",
                    status);
            }
            if (grid.Rows.Count > 0) grid.Rows[0].Selected = true;
        }
        catch (Exception ex) { MessageBox.Show("Could not load salaries.\r\n\r\n" + ex.Message, "Salary Management", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private Control BuildDetails()
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 6, RowCount = 2, Padding = new Padding(0, 0, 0, 6) };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 104));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 52));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130)); root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 22)); root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19)); root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19)); root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 19)); root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 21));
        root.Controls.Add(new Label { Text = "SELECTED", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) }, 0, 0);
        selectedLabel.Dock = DockStyle.Fill; selectedLabel.TextAlign = ContentAlignment.MiddleLeft; root.Controls.Add(selectedLabel, 1, 0); root.SetColumnSpan(selectedLabel, 2);
        root.Controls.Add(Stat("FIXED SALARY", fixedLabel), 3, 0); root.Controls.Add(Stat("ADVANCES", advanceLabel), 4, 0); root.Controls.Add(Stat("PAYABLE", payableLabel), 5, 0);
        var action = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            AutoScroll = false,
            Padding = new Padding(6, 8, 6, 6),
            Margin = new Padding(0),
            MinimumSize = new Size(0, 52)
        };
        action.Controls.Add(new Label
        {
            Text = "ADVANCE",
            AutoSize = false,
            Width = 105,
            Height = 32,
            Margin = new Padding(2, 0, 8, 0),
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        });
        advanceBox.DecimalPlaces = 0;
        advanceBox.Maximum = 100000000;
        advanceBox.ThousandsSeparator = true;
        advanceBox.Width = 140;
        advanceBox.Height = 32;
        advanceBox.Margin = new Padding(0, 0, 10, 0);
        advanceBox.Enter += (_, _) => { if (advanceBox.Value == 0) advanceBox.Text = string.Empty; else advanceBox.Select(0, advanceBox.Text.Length); };
        advanceBox.MouseDown += (_, _) => { if (advanceBox.Value == 0) advanceBox.Text = string.Empty; };
        advanceBox.Leave += (_, _) => { if (string.IsNullOrWhiteSpace(advanceBox.Text)) advanceBox.Value = 0; };
        advanceBox.Text = string.Empty;
        action.Controls.Add(advanceBox);
        var add = new Button { Text = "GIVE ADVANCE", Width = 142, Height = 32, AutoSize = false, Margin = new Padding(0, 0, 20, 0) }; add.Click += (_, _) => GiveAdvance(); action.Controls.Add(add);
        monthPicker.Format = DateTimePickerFormat.Custom; monthPicker.CustomFormat = "MMMM yyyy"; monthPicker.ShowUpDown = true; monthPicker.Value = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1); monthPicker.Width = 185; monthPicker.Height = 32; monthPicker.Margin = new Padding(0, 0, 10, 0);
        action.Controls.Add(new Label { Text = "MONTH", AutoSize = false, Width = 100, Height = 32, Margin = new Padding(0, 0, 8, 0), TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        action.Controls.Add(monthPicker);
        var pay = new Button { Text = "MARK SALARY PAID", Width = 170, Height = 32, AutoSize = false, Margin = new Padding(0) }; pay.Click += (_, _) => MarkPaid(); action.Controls.Add(pay);
        root.Controls.Add(action, 0, 1); root.SetColumnSpan(action, 6); return root;
    }

    private static Control Stat(string title, Label value)
    {
        var p = new Panel { Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle, Padding = new Padding(6), Margin = new Padding(4) };
        p.Controls.Add(value); value.Dock = DockStyle.Fill; value.Font = new Font("Segoe UI", 11, FontStyle.Bold); value.TextAlign = ContentAlignment.MiddleLeft;
        p.Controls.Add(new Label { Text = title, Dock = DockStyle.Top, Height = 20, Font = new Font("Segoe UI", 8, FontStyle.Bold) }); return p;
    }

    private Control BuildAdvanceHistory()
    {
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(0) };
        var refresh = new Button { Text = "REFRESH", Dock = DockStyle.Fill, Height = 32, Margin = new Padding(0, 10, 0, 0) }; refresh.Click += (_, _) => LoadGrid();
        panel.Controls.Add(refresh); return panel;
    }

    private int? SelectedId()
    {
        if (grid.SelectedRows.Count == 0) return null;
        var name = grid.SelectedRows[0].Cells["Name"].Value?.ToString(); var code = grid.SelectedRows[0].Cells["Code"].Value?.ToString();
        if (string.IsNullOrWhiteSpace(code)) return null;
        using var db = new ShopDbContext(); return db.Salesmen.AsNoTracking().Where(x => x.Code == code && x.Name == name).Select(x => (int?)x.SalesmanId).FirstOrDefault();
    }

    private void RefreshSelected()
    {
        var id = SelectedId(); if (!id.HasValue) { selectedLabel.Text = "Select a salesman"; return; }
        var s = service.GetCurrentSummary(id.Value); selectedLabel.Text = $"{s.Name}  ({s.Code})"; fixedLabel.Text = $"Rs. {s.MonthlySalary:#,##0.##}"; commissionLabel.Text = $"Rs. {s.CommissionThisMonth:#,##0.##}"; advanceLabel.Text = $"Rs. {s.AdvancesThisMonth:#,##0.##}"; payableLabel.Text = $"Rs. {s.RemainingSalary:#,##0.##}";
    }

    private void GiveAdvance()
    {
        var id = SelectedId(); if (!id.HasValue) { MessageBox.Show("Select a salesman first."); return; }
        try { service.AddAdvance(id.Value, advanceBox.Value, Session.CurrentUser?.Username ?? "Admin", string.Empty, true); advanceBox.Value = 0; advanceBox.Text = string.Empty; LoadGrid(); MessageBox.Show("Advance recorded. It has been deducted automatically from the remaining salary.", "Advance Recorded", MessageBoxButtons.OK, MessageBoxIcon.Information); }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Could Not Record Advance", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private void MarkPaid()
    {
        var id = SelectedId(); if (!id.HasValue) { MessageBox.Show("Select a salesman first."); return; }
        try { service.RecordSalaryPayment(id.Value, monthPicker.Value, Session.CurrentUser?.Username ?? "Admin"); MessageBox.Show("Salary payment recorded successfully. It will now appear in Salary History.", "Salary Paid", MessageBoxButtons.OK, MessageBoxIcon.Information); LoadGrid(); }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Could Not Record Salary", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }
}
