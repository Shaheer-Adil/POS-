# UI Fix 31

Updated the Staff Dashboard Inventory page:

- Removed the DELETE button from the top-right inventory controls.
- Added the DELETE button to the bottom-right action area.
- Positioned DELETE immediately to the left of RECENTLY DELETED.
- DELETE uses exactly the same 180x40 size as RECENTLY DELETED.
- Both buttons remain aligned on the same bottom row and right-aligned with 10px spacing.
- Existing delete/recovery functionality is unchanged.
