using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class RecentlyDeletedForm : Form
{
    private readonly TextBox searchBox = new();
    private readonly DataGridView grid = new();
    private readonly Label countLabel = new();
    private readonly ProductService service = new();
    private InventoryGroupRow[] groups = Array.Empty<InventoryGroupRow>();

    public RecentlyDeletedForm()
    {
        Text = "Recently Deleted";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(900, 600);
        Size = new Size(1200, 720);

        var top = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 115,
            Padding = new Padding(20),
            ColumnCount = 4,
            RowCount = 2
        };
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));

        top.Controls.Add(new Label
        {
            Text = "SEARCH",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        }, 0, 0);

        searchBox.Dock = DockStyle.Fill;
        searchBox.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                LoadDeleted();
                e.SuppressKeyPress = true;
            }
        };
        top.Controls.Add(searchBox, 1, 0);

        var searchButton = new Button { Text = "SEARCH", Dock = DockStyle.Fill };
        searchButton.Click += (_, _) => LoadDeleted();
        top.Controls.Add(searchButton, 2, 0);

        var refresh = new Button { Text = "REFRESH", Dock = DockStyle.Fill };
        refresh.Click += (_, _) =>
        {
            searchBox.Clear();
            LoadDeleted();
        };
        top.Controls.Add(refresh, 3, 0);

        countLabel.Dock = DockStyle.Fill;
        countLabel.TextAlign = ContentAlignment.MiddleLeft;
        top.Controls.Add(countLabel, 0, 1);
        top.SetColumnSpan(countLabel, 4);

        ConfigureGrid();
        Controls.Add(grid);
        Controls.Add(CreateBottomBar());
        Controls.Add(top);

        Shown += (_, _) => LoadDeleted();
        BackButtonHelper.AddBackButton(this);
    }

    private Control CreateBottomBar()
    {
        var bottom = new Panel
        {
            Dock = DockStyle.Bottom,
            Height = 62,
            Padding = new Padding(10)
        };

        var recover = new Button
        {
            Text = "RECOVER",
            Width = 120,
            Height = 40,
            Anchor = AnchorStyles.Right | AnchorStyles.Bottom,
            Left = bottom.ClientSize.Width - 130,
            Top = 10
        };
        recover.Click += (_, _) => RecoverSelected();

        bottom.Resize += (_, _) =>
        {
            recover.Left = bottom.ClientSize.Width - recover.Width - 10;
            recover.Top = bottom.ClientSize.Height - recover.Height - 10;
        };

        bottom.Controls.Add(recover);
        return bottom;
    }

    private void ConfigureGrid()
    {
        grid.Dock = DockStyle.Fill;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AutoGenerateColumns = false;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = false;
        grid.RowHeadersVisible = false;
        grid.AllowUserToResizeRows = false;

        grid.Columns.Add(new DataGridViewButtonColumn
        {
            Name = "Expand",
            HeaderText = "",
            Text = "▼",
            UseColumnTextForButtonValue = true,
            FillWeight = 45,
            FlatStyle = FlatStyle.System
        });

        AddColumn("Product", 145);
        AddColumn("Product Code", 110);
        AddColumn("Category", 110);
        AddColumn("Quantity", 80);
        AddColumn("Sale Price", 95);
        AddColumn("Status", 105);
        AddColumn("Unit / Tag", 135);
        AddColumn("Added At", 115);

        grid.CellContentClick += Grid_CellContentClick;
        grid.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex >= 0)
                ToggleGroup(e.RowIndex);
        };
    }

    private void AddColumn(string header, float fillWeight)
    {
        grid.Columns.Add(new DataGridViewTextBoxColumn
        {
            HeaderText = header,
            FillWeight = fillWeight
        });
    }

    private void Grid_CellContentClick(object? sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex != 0)
            return;

        ToggleGroup(e.RowIndex);
    }

    private void ToggleGroup(int rowIndex)
    {
        if (rowIndex < 0 || rowIndex >= grid.Rows.Count)
            return;

        if (grid.Rows[rowIndex].Tag is not InventoryGroupRow group)
            return;

        group.Expanded = !group.Expanded;
        BindRows();
    }

    private void BindRows()
    {
        grid.Rows.Clear();

        foreach (var group in groups)
        {
            var groupValues = new System.Collections.Generic.List<object>
            {
                group.Expanded ? "▲" : "▼",
                group.ProductName,
                group.ProductCode,
                group.Category,
                group.Quantity.ToString("N0"),
                group.SalePrice.HasValue ? $"Rs. {group.SalePrice.Value:N0}" : "Multiple",
                "Recently Deleted",
                group.Expanded ? "Hide units" : "View units",
                ""
            };

            var groupRowIndex = grid.Rows.Add(groupValues.ToArray());
            grid.Rows[groupRowIndex].Tag = group;
            grid.Rows[groupRowIndex].DefaultCellStyle.Font = new Font(grid.Font, FontStyle.Bold);

            if (!group.Expanded)
                continue;

            foreach (var unit in group.Units)
            {
                var unitValues = new object[]
                {
                    "•",
                    "   ↳ " + unit.ProductName,
                    unit.ProductCode,
                    unit.Category,
                    "—",
                    $"Rs. {unit.SalePrice:N0}",
                    "Deleted",
                    unit.UnitCode,
                    unit.AddedAt.ToString("dd-MMM-yyyy HH:mm")
                };

                var detailRowIndex = grid.Rows.Add(unitValues);
                grid.Rows[detailRowIndex].Tag = unit;
                grid.Rows[detailRowIndex].DefaultCellStyle.BackColor =
                    SystemColors.ControlLightLight;
            }
        }
    }

    private void RecoverSelected()
    {
        try
        {
            if (grid.CurrentRow?.Tag is InventoryDetailRow detail)
            {
                var confirm = MessageBox.Show(
                    $"Recover this inventory item?\n\nProduct: {detail.ProductName}\nUnit: {detail.UnitCode}",
                    "Confirm Recovery",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (confirm != DialogResult.Yes)
                    return;

                service.RestoreInventoryUnit(detail.InventoryUnitId);
                LoadDeleted();
                MessageBox.Show(
                    "The selected inventory item has been recovered and is available in Inventory again.",
                    "Recovered",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            if (grid.CurrentRow?.Tag is InventoryGroupRow group)
            {
                var confirm = MessageBox.Show(
                    $"Recover all {group.Quantity:N0} deleted units for this product?\n\nProduct: {group.ProductName}\nProduct Code: {group.ProductCode}",
                    "Recover Entire Product Group",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Question);

                if (confirm != DialogResult.Yes)
                    return;

                var restored = service.RestoreInventoryGroup(group.ProductId);
                LoadDeleted();
                MessageBox.Show(
                    $"{restored:N0} inventory unit(s) have been recovered and are available in Inventory again.",
                    "Recovered",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            MessageBox.Show(
                "Select a deleted product or an individual deleted unit first.",
                "Select Deleted Item",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Could not recover the selected item.\n\n" + ex.Message,
                "Recovery Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private void LoadDeleted()
    {
        try
        {
            groups = service.GetRecentlyDeletedGroups(searchBox.Text);
            foreach (var group in groups)
                group.Expanded = false;

            BindRows();

            var totalDeleted = groups.Sum(x => x.Quantity);
            countLabel.Text =
                $"Deleted products displayed: {groups.Length:N0}    |    Deleted units: {totalDeleted:N0}";
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Could not load Recently Deleted.\n\n" + ex.Message,
                "Recently Deleted Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
