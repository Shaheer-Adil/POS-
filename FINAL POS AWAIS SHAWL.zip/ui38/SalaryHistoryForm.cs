using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

/// <summary>Step 30: one clean list of salaries that have actually been paid.</summary>
public class SalaryHistoryForm : Form
{
    private readonly SalaryService service = new();
    private readonly DataGridView grid = new();
    private readonly Label totalLabel = new();
    private readonly DateTimePicker fromPicker = new();
    private readonly DateTimePicker toPicker = new();

    public SalaryHistoryForm()
    {
        if (!AuthorizationService.RequireAdmin(this, "Salary history")) return;
        Text = "Salary History";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1180, 700);
        MinimumSize = new Size(1000, 600);
        BuildUi();
        LoadHistory();
        BackButtonHelper.AddBackButton(this);
    }

    private void BuildUi()
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(18), ColumnCount = 1, RowCount = 3 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 58));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.Controls.Add(new Label { Text = "SALARY HISTORY", Dock = DockStyle.Fill, Font = new Font("Segoe UI", 16, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft }, 0, 0);

        var filter = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, Padding = new Padding(4) };
        filter.Controls.Add(new Label { Text = "FROM", AutoSize = true, Margin = new Padding(5, 10, 5, 0), Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        fromPicker.Format = DateTimePickerFormat.Short; fromPicker.Value = DateTime.Today.AddYears(-5); fromPicker.Width = 140; filter.Controls.Add(fromPicker);
        filter.Controls.Add(new Label { Text = "TO", AutoSize = true, Margin = new Padding(12, 10, 5, 0), Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        toPicker.Format = DateTimePickerFormat.Short; toPicker.Value = DateTime.Today; toPicker.Width = 140; filter.Controls.Add(toPicker);
        var refresh = new Button { Text = "REFRESH", Width = 100, Height = 30, Margin = new Padding(15, 3, 5, 3) }; refresh.Click += (_, _) => LoadHistory(); filter.Controls.Add(refresh);
        totalLabel.AutoSize = true; totalLabel.Font = new Font("Segoe UI", 10, FontStyle.Bold); totalLabel.Margin = new Padding(20, 8, 5, 0); filter.Controls.Add(totalLabel);
        root.Controls.Add(filter, 0, 1);

        grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.AllowUserToAddRows = false; grid.AutoGenerateColumns = false; grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Salesman", HeaderText = "SALESMAN" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Code", HeaderText = "CODE" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Month", HeaderText = "SALARY MONTH" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "PaidAt", HeaderText = "PAID DATE / TIME" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Fixed", HeaderText = "FIXED SALARY" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Commission", HeaderText = "COMMISSION" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Advances", HeaderText = "ADVANCES" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Amount", HeaderText = "AMOUNT PAID" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { Name = "PaidBy", HeaderText = "PAID BY" });
        root.Controls.Add(grid, 0, 2);
        Controls.Add(root);
    }

    private void LoadHistory()
    {
        if (toPicker.Value.Date < fromPicker.Value.Date) { MessageBox.Show("The TO date cannot be earlier than the FROM date."); return; }
        try
        {
            var rows = service.GetSalaryPayments(fromPicker.Value.Date, toPicker.Value.Date.AddDays(1));
            grid.Rows.Clear();
            foreach (var x in rows)
                grid.Rows.Add(x.Salesman, x.Code, x.PayrollMonth.ToString("MMMM yyyy"), x.PaidAt.ToString("dd-MMM-yyyy hh:mm tt"), $"Rs. {x.FixedSalary:#,##0.##}", $"Rs. {x.Commission:#,##0.##}", $"Rs. {x.Advances:#,##0.##}", $"Rs. {x.AmountPaid:#,##0.##}", x.PaidBy);
            totalLabel.Text = $"TOTAL PAID: Rs. {rows.Sum(x => x.AmountPaid):#,##0.##}";
        }
        catch (Exception ex) { MessageBox.Show("Could not load salary history.\r\n\r\n" + ex.Message, "Salary History", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }
}
