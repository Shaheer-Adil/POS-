# Step 30 — Salesmen + Salary + Salary History

This step reorganizes the Admin dashboard's salary-related controls into three clear modules:

1. **SALESMEN**
   - Add a new salesman.
   - Automatic unique 3-digit code.
   - Exact creation date/time is stored and shown.
   - Set the fixed monthly salary.
   - Set commission percentage for an individual suit/item.
   - **SELECT ALL ITEMS** applies one percentage to all current products.

2. **SALARY MANAGEMENT**
   - Shows every active salesman with name, code, fixed salary, commission, advances and remaining/payable amount.
   - Selecting a salesman shows the fixed salary and total advances already taken.
   - A new advance is permanently recorded with date/time and automatically deducted from remaining salary.
   - **MARK SALARY PAID** records the final payable amount for the selected month.

3. **SALARY HISTORY**
   - Shows all salary payments that have actually been recorded as paid.
   - Includes salesman, code, salary month, paid date/time, fixed salary, commission, advances, amount paid and admin/user who recorded it.

A small database table (`SalaryPayments`) is created automatically on startup if it does not already exist, so existing databases do not need a manual migration command.


UI Fix 22: Expense Management amount label clipping fixed, From/To alignment improved, and report columns reordered to Category, Date, Time, Amount, Description, Recorded By.
