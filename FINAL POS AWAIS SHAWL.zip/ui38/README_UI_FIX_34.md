# UI Fix 34

## Changes
- Login form increased from 520x390 to 1560x1950 (3x width and 5x height).
- Replaced the top title "SHOP MANAGEMENT SYSTEM" with centered, styled "Awais Shall".
- Centered and professionally aligned the username and password controls.
- Increased login control sizing for the larger login page.
- Bill prices use whole-rupee formatting (`N0`), so `.00` is not printed after each price.
- No image assets were generated.
