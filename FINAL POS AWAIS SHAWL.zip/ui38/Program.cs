using System;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;

namespace ShopManagementSystem;

internal static class Program
{
    [STAThread]
    static void Main()
    {
        ApplicationConfiguration.Initialize();

        try
        {
            using var db = new ShopDbContext();
            db.Database.EnsureCreated();
            EnsureSalaryPaymentTable(db);
            DbSeeder.Initialize(db);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "The application could not prepare the local SQL Server database.\n\n" +
                "Make sure SQL Server LocalDB is installed and available.\n\n" +
                "Technical details:\n" + ex.Message,
                "Database Connection Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
            return;
        }

        Application.Run(new LoginForm());
    }

    private static void EnsureSalaryPaymentTable(ShopDbContext db)
    {
        db.Database.ExecuteSqlRaw(@"
IF OBJECT_ID(N'dbo.SalaryPayments', N'U') IS NULL
BEGIN
    CREATE TABLE [dbo].[SalaryPayments](
        [SalaryPaymentId] INT IDENTITY(1,1) NOT NULL CONSTRAINT [PK_SalaryPayments] PRIMARY KEY,
        [SalesmanId] INT NOT NULL,
        [PayrollMonth] DATETIME2 NOT NULL,
        [PaidAt] DATETIME2 NOT NULL,
        [FixedSalary] DECIMAL(18,2) NOT NULL,
        [Commission] DECIMAL(18,2) NOT NULL,
        [Advances] DECIMAL(18,2) NOT NULL,
        [AmountPaid] DECIMAL(18,2) NOT NULL,
        [PaidBy] NVARCHAR(50) NOT NULL,
        CONSTRAINT [FK_SalaryPayments_Salesmen] FOREIGN KEY ([SalesmanId]) REFERENCES [dbo].[Salesmen]([SalesmanId]) ON DELETE CASCADE
    );
    CREATE UNIQUE INDEX [IX_SalaryPayments_SalesmanId_PayrollMonth] ON [dbo].[SalaryPayments]([SalesmanId],[PayrollMonth]);
END");
    }
}
