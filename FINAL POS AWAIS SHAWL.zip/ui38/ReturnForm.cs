using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class ReturnForm : Form
{
    private readonly TextBox searchBox = new();
    private readonly DataGridView resultsGrid = new();
    private readonly TextBox reasonBox = new();
    private readonly Label selectedLabel = new();
    private readonly ReturnService service = new();

    private List<ReturnSearchResult> results = new();

    private bool IsAdmin =>
        string.Equals(Session.CurrentUser?.Role, "Admin", StringComparison.OrdinalIgnoreCase);

    public ReturnForm()
    {
        Text = "Customer Returns";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(1050, 650);
        Size = new Size(1250, 750);

        var header = BuildHeader();
        var resultsPanel = BuildResults();
        var footer = BuildFooter();

        Controls.Add(resultsPanel);
        Controls.Add(footer);
        Controls.Add(header);

        Shown += (_, _) => searchBox.Focus();
            BackButtonHelper.AddBackButton(this);
}

    private Control BuildHeader()
    {
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 145,
            Padding = new Padding(20),
            ColumnCount = 4,
            RowCount = 2
        };

        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210));

        panel.Controls.Add(new Label
        {
            Text = "SCAN / SEARCH",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        }, 0, 0);

        searchBox.Dock = DockStyle.Fill;
        searchBox.Font = new Font("Consolas", 13);
        searchBox.PlaceholderText = "Scan returned tag, enter unit number, or type product name";
        searchBox.KeyDown += SearchBox_KeyDown;
        panel.Controls.Add(searchBox, 1, 0);

        var searchButton = new Button
        {
            Text = "SEARCH",
            Dock = DockStyle.Fill
        };
        searchButton.Click += (_, _) => Search();
        panel.Controls.Add(searchButton, 2, 0);

        panel.Controls.Add(new Label
        {
            Text = "Only previously SOLD units can be returned.",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 8, FontStyle.Bold)
        }, 3, 0);

        panel.Controls.Add(new Label
        {
            Text = "RETURN REASON",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        }, 0, 1);

        reasonBox.Dock = DockStyle.Fill;
        reasonBox.PlaceholderText = "Optional: damaged, wrong item, customer changed mind...";
        panel.Controls.Add(reasonBox, 1, 1);

        selectedLabel.Text = "No item selected";
        selectedLabel.Dock = DockStyle.Fill;
        selectedLabel.TextAlign = ContentAlignment.MiddleCenter;
        selectedLabel.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        panel.Controls.Add(selectedLabel, 2, 1);

        panel.Controls.Add(new Label
        {
            Text = IsAdmin
                ? "ADMIN: Purchase price visible"
                : "STAFF: Purchase price hidden",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 8, FontStyle.Bold)
        }, 3, 1);

        return panel;
    }

    private Control BuildResults()
    {
        var panel = new Panel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(20, 0, 20, 0)
        };

        ConfigureGrid();
        panel.Controls.Add(resultsGrid);
        return panel;
    }

    private Control BuildFooter()
    {
        var footer = new TableLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 85,
            Padding = new Padding(20, 10, 20, 15),
            ColumnCount = 2
        };

        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210));

        var instruction = new Label
        {
            Text = "Select the exact returned physical unit. Double-click a row to select it.",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 9)
        };
        footer.Controls.Add(instruction, 0, 0);

        var returnButton = new Button
        {
            Text = "PROCESS RETURN",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        };
        returnButton.Click += (_, _) => ProcessReturn();
        footer.Controls.Add(returnButton, 1, 0);

        return footer;
    }

    private void ConfigureGrid()
    {
        resultsGrid.Dock = DockStyle.Fill;
        resultsGrid.ReadOnly = true;
        resultsGrid.AllowUserToAddRows = false;
        resultsGrid.AutoGenerateColumns = false;
        resultsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        resultsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        resultsGrid.MultiSelect = false;

        AddColumn("UnitCode", "Tag / Unit Number", 105);
        AddColumn("ProductName", "Product", 125);
        AddColumn("ProductCode", "Product Code", 95);
        AddColumn("OriginalSalePrice", "Original Sale Price", 105, "N0");
        AddColumn("InvoiceNumber", "Invoice", 105);
        AddColumn("SaleDate", "Sold On", 105, "g");

        if (IsAdmin)
            AddColumn("PurchasePrice", "Purchase Price", 95, "N0");

        resultsGrid.DoubleClick += (_, _) => SelectCurrent();
        resultsGrid.SelectionChanged += (_, _) => UpdateSelectedLabel();
        resultsGrid.DataError += ResultsGrid_DataError;
    }

    private void ResultsGrid_DataError(object? sender, DataGridViewDataErrorEventArgs e)
    {
        // Prevent WinForms from displaying its default DataGridView error dialog
        // if a stale row index is reported during a completed-return reset.
        e.ThrowException = false;
    }

    private void ResetReturnGrid()
    {
        // Detach first, then clear the backing list. This prevents the
        // "Index 0 does not have a value" binding error after a return.
        resultsGrid.CurrentCell = null;
        resultsGrid.DataSource = null;
        results.Clear();
        resultsGrid.ClearSelection();
    }

    private void AddColumn(
        string property,
        string header,
        int weight,
        string? format = null)
    {
        var c = new DataGridViewTextBoxColumn
        {
            DataPropertyName = property,
            HeaderText = header,
            FillWeight = weight
        };

        if (format != null)
            c.DefaultCellStyle = new DataGridViewCellStyle { Format = format };

        resultsGrid.Columns.Add(c);
    }

    private void SearchBox_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            Search();
        }
    }

    private void Search()
    {
        var query = searchBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(query))
            return;

        var exact = service.FindSoldUnit(query);

        if (exact != null)
        {
            results = new List<ReturnSearchResult> { exact };
            resultsGrid.DataSource = null;
            resultsGrid.DataSource = results;
            resultsGrid.Rows[0].Selected = true;
            UpdateSelectedLabel();
            return;
        }

        results = service.SearchSoldUnits(query);

        resultsGrid.DataSource = null;
        resultsGrid.DataSource = results;

        if (results.Count == 0)
        {
            selectedLabel.Text = "No sold unit found";
            MessageBox.Show(
                "No eligible sold product was found. Search by unit number, product code, or product name.",
                "No Return Match",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        resultsGrid.Rows[0].Selected = true;
        UpdateSelectedLabel();
    }

    private void SelectCurrent()
    {
        UpdateSelectedLabel();
    }

    private ReturnSearchResult? GetSelected()
    {
        return resultsGrid.CurrentRow?.DataBoundItem as ReturnSearchResult;
    }

    private void UpdateSelectedLabel()
    {
        var selected = GetSelected();

        if (selected == null)
        {
            selectedLabel.Text = "No item selected";
            return;
        }

        selectedLabel.Text =
            $"{selected.ProductName} | {selected.UnitCode} | {selected.InvoiceNumber}";
    }

    private void ProcessReturn()
    {
        var selected = GetSelected();

        if (selected == null)
        {
            MessageBox.Show(
                "Select a returned product first.",
                "Select Product",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        var confirmation = MessageBox.Show(
            $"Return this exact physical unit?\n\n" +
            $"Product: {selected.ProductName}\n" +
            $"Unit: {selected.UnitCode}\n" +
            $"Invoice: {selected.InvoiceNumber}\n" +
            $"Original Sale Price: Rs. {selected.OriginalSalePrice:N0}\n\n" +
            "The unit will be restored to available inventory.",
            "Confirm Return",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (confirmation != DialogResult.Yes)
            return;

        try
        {
            service.CompleteReturn(
                selected,
                Session.CurrentUser?.Username ?? "Staff",
                reasonBox.Text);

            MessageBox.Show(
                $"Return completed successfully.\n\n" +
                $"{selected.ProductName} ({selected.UnitCode}) has been returned to inventory.\n" +
                $"Original customer sale price preserved: Rs. {selected.OriginalSalePrice:N0}",
                "Return Completed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            searchBox.Clear();
            reasonBox.Clear();
            ResetReturnGrid();
            selectedLabel.Text = "No item selected";
            searchBox.Focus();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "Return Could Not Be Completed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
