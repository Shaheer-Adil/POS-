using System;

namespace ShopManagementSystem.Models;

public class InventoryUnit
{
    public int InventoryUnitId { get; set; }
    public int ProductId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public decimal PurchasePrice { get; set; }
    public decimal SalePrice { get; set; }
    public string Status { get; set; } = "InStock";
    public DateTime AddedAt { get; set; }

    public Product? Product { get; set; }
}
