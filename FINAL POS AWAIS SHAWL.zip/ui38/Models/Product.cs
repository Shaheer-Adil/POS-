using System;
using System.Collections.Generic;

namespace ShopManagementSystem.Models;

public class Product
{
    public int ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public decimal PurchasePrice { get; set; }
    public decimal SalePrice { get; set; }
    public int Quantity { get; set; }
    public DateTime CreatedAt { get; set; }

    public ICollection<InventoryUnit> InventoryUnits { get; set; } = new List<InventoryUnit>();
}
