using System;
using System.Collections.Generic;

namespace ShopManagementSystem.Models;

public class CreditAccount
{
    public int CreditAccountId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string PhoneNumber { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public ICollection<CreditTransaction> Transactions { get; set; } = new List<CreditTransaction>();
}
