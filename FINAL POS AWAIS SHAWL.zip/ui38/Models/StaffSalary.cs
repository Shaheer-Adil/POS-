using System;
namespace ShopManagementSystem.Models;
public class StaffSalary
{
    public int StaffSalaryId { get; set; }
    public int SalesmanId { get; set; }
    public decimal MonthlySalary { get; set; }
    public DateTime UpdatedAt { get; set; }
    public Salesman? Salesman { get; set; }
}
