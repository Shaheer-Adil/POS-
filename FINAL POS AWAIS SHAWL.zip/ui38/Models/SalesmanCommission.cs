using System;

namespace ShopManagementSystem.Models;

public class SalesmanCommission
{
    public int SalesmanCommissionId { get; set; }
    public int SalesmanId { get; set; }
    public int ProductId { get; set; }
    public decimal Percentage { get; set; }
    public DateTime UpdatedAt { get; set; }

    public Salesman? Salesman { get; set; }
    public Product? Product { get; set; }
}
