using System;

namespace ShopManagementSystem.Models;

public class CreditTransaction
{
    public int CreditTransactionId { get; set; }
    public int CreditAccountId { get; set; }
    public int? SaleId { get; set; }
    public string TransactionType { get; set; } = string.Empty; // CreditSale or Payment
    public decimal Amount { get; set; }
    public DateTime TransactionDate { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public CreditAccount? CreditAccount { get; set; }
    public Sale? Sale { get; set; }
}
