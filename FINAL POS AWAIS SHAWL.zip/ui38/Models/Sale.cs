using System;
using System.Collections.Generic;

namespace ShopManagementSystem.Models;

public class Sale
{
    public int SaleId { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public decimal TotalAmount { get; set; }
    public DateTime SaleDate { get; set; }
    public string SoldBy { get; set; } = string.Empty;
    public int? SalesmanId { get; set; }
    public string SalesmanCode { get; set; } = string.Empty;
    public string SalesmanName { get; set; } = string.Empty;
    public decimal TotalCommission { get; set; }
    public ICollection<SaleItem> Items { get; set; } = new List<SaleItem>();
}
