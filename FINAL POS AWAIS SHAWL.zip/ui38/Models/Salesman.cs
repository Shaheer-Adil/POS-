using System;
using System.Collections.Generic;

namespace ShopManagementSystem.Models;

public class Salesman
{
    public int SalesmanId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
    public ICollection<SalesmanCommission> Commissions { get; set; } = new List<SalesmanCommission>();
}
