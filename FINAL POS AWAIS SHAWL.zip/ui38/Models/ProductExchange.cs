using System;

namespace ShopManagementSystem.Models;

public class ProductExchange
{
    public int ProductExchangeId { get; set; }

    public int OriginalSaleItemId { get; set; }
    public int OriginalInventoryUnitId { get; set; }
    public string OriginalUnitCode { get; set; } = string.Empty;
    public decimal OriginalSalePrice { get; set; }

    public int ReplacementInventoryUnitId { get; set; }
    public string ReplacementUnitCode { get; set; } = string.Empty;
    public decimal ReplacementSalePrice { get; set; }

    public decimal PriceDifference { get; set; }

    public DateTime ExchangeDate { get; set; }
    public string ExchangedBy { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;
}
