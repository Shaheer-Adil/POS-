using System;

namespace ShopManagementSystem.Models;

public class ProductReturn
{
    public int ProductReturnId { get; set; }
    public int SaleItemId { get; set; }
    public int InventoryUnitId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public decimal OriginalSalePrice { get; set; }
    public DateTime ReturnDate { get; set; }
    public string ReturnedBy { get; set; } = string.Empty;
    public string Reason { get; set; } = string.Empty;

    public SaleItem? SaleItem { get; set; }
    public InventoryUnit? InventoryUnit { get; set; }
}
