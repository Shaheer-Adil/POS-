using System;

namespace ShopManagementSystem.Models;

public class SaleItem
{
    public int SaleItemId { get; set; }
    public int SaleId { get; set; }
    public int InventoryUnitId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public decimal PurchasePrice { get; set; }
    public decimal SalePrice { get; set; }
    public decimal CommissionPercentage { get; set; }
    public decimal CommissionAmount { get; set; }
    public Sale? Sale { get; set; }
    public InventoryUnit? InventoryUnit { get; set; }
}
