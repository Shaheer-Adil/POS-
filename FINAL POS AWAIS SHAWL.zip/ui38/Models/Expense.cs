using System;

namespace ShopManagementSystem.Models;

public class Expense
{
    public int ExpenseId { get; set; }
    public string Category { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public DateTime ExpenseDate { get; set; }
    public string Description { get; set; } = string.Empty;
    public string RecordedBy { get; set; } = string.Empty;
}
