using System;
namespace ShopManagementSystem.Models;
public class SalaryAdvance
{
    public int SalaryAdvanceId { get; set; }
    public int SalesmanId { get; set; }
    public decimal Amount { get; set; }
    public DateTime PaidAt { get; set; }
    public string PaidBy { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
    public Salesman? Salesman { get; set; }
}
