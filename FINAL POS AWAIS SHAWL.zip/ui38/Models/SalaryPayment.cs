using System;

namespace ShopManagementSystem.Models;

public class SalaryPayment
{
    public int SalaryPaymentId { get; set; }
    public int SalesmanId { get; set; }
    public DateTime PayrollMonth { get; set; }
    public DateTime PaidAt { get; set; }
    public decimal FixedSalary { get; set; }
    public decimal Commission { get; set; }
    public decimal Advances { get; set; }
    public decimal AmountPaid { get; set; }
    public string PaidBy { get; set; } = string.Empty;
    public Salesman? Salesman { get; set; }
}
