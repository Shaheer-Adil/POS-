using System;
using System.Drawing;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class SalaryManagementForm : Form
{
    private readonly SalaryService service = new();
    private readonly ComboBox staffBox = new();
    private readonly NumericUpDown salaryBox = new();
    private readonly NumericUpDown advanceBox = new();
    private readonly TextBox notesBox = new();
    private readonly DataGridView summaryGrid = new();
    private readonly DataGridView historyGrid = new();

    public SalaryManagementForm()
    {
        if (!AuthorizationService.RequireAdmin(this, "Salary management"))
            return;

        Text = "Salary Management";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1180, 760);
        MinimumSize = new Size(1000, 650);
        BuildUi();
        LoadStaff();
        RefreshSummary();
            BackButtonHelper.AddBackButton(this);
}

    private void BuildUi()
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(18), ColumnCount = 1, RowCount = 4 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 120));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 55));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 45));

        root.Controls.Add(new Label
        {
            Text = "SALARY MANAGEMENT\r\nFixed salary • commission • advances • remaining salary",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 16, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 0);
        root.Controls.Add(BuildControls(), 0, 1);
        root.Controls.Add(BuildSummary(), 0, 2);
        root.Controls.Add(BuildHistory(), 0, 3);
        Controls.Add(root);
    }

    private Control BuildControls()
    {
        var p = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 6, RowCount = 2 };
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 125));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 24));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 125));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 26));

        p.Controls.Add(new Label { Text = "STAFF / SALESMAN", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) }, 0, 0);
        staffBox.Dock = DockStyle.Fill;
        staffBox.DropDownStyle = ComboBoxStyle.DropDownList;
        staffBox.SelectedIndexChanged += (_, _) => LoadSelectedSalary();
        p.Controls.Add(staffBox, 1, 0);

        p.Controls.Add(new Label { Text = "MONTHLY SALARY", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) }, 2, 0);
        salaryBox.Dock = DockStyle.Fill;
        salaryBox.DecimalPlaces = 0;
        salaryBox.Maximum = 100000000;
        salaryBox.ThousandsSeparator = true;
        salaryBox.Text = string.Empty;
        salaryBox.Enter += (_, _) => { if (salaryBox.Value == 0) salaryBox.Text = string.Empty; };
        salaryBox.MouseDown += (_, _) => { if (salaryBox.Value == 0) salaryBox.Text = string.Empty; };
        p.Controls.Add(salaryBox, 3, 0);

        var save = new Button { Text = "SAVE SALARY", Dock = DockStyle.Fill };
        save.Click += (_, _) => SaveSalary();
        p.Controls.Add(save, 4, 0);

        var refresh = new Button { Text = "REFRESH", Dock = DockStyle.Fill };
        refresh.Click += (_, _) => { LoadStaff(); RefreshSummary(); };
        p.Controls.Add(refresh, 5, 0);

        p.Controls.Add(new Label { Text = "SALARY ADVANCE", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) }, 0, 1);
        advanceBox.Dock = DockStyle.Fill;
        advanceBox.DecimalPlaces = 0;
        advanceBox.Maximum = 100000000;
        advanceBox.ThousandsSeparator = true;
        advanceBox.Text = string.Empty;
        advanceBox.Enter += (_, _) => { if (advanceBox.Value == 0) advanceBox.Text = string.Empty; };
        advanceBox.MouseDown += (_, _) => { if (advanceBox.Value == 0) advanceBox.Text = string.Empty; };
        p.Controls.Add(advanceBox, 1, 1);

        notesBox.Dock = DockStyle.Fill;
        notesBox.PlaceholderText = "Advance note (optional)";
        p.Controls.Add(notesBox, 2, 1);
        p.SetColumnSpan(notesBox, 2);

        var pay = new Button { Text = "PAY ADVANCE & RECORD", Dock = DockStyle.Fill };
        pay.Click += (_, _) => PayAdvance();
        p.Controls.Add(pay, 4, 1);

        var history = new Button { Text = "VIEW SELECTED HISTORY", Dock = DockStyle.Fill };
        history.Click += (_, _) => RefreshHistory();
        p.Controls.Add(history, 5, 1);
        return p;
    }

    private Control BuildSummary()
    {
        ConfigureGrid(summaryGrid);
        summaryGrid.Columns.Add("Name", "Staff Name");
        summaryGrid.Columns.Add("Code", "Code");
        summaryGrid.Columns.Add("Salary", "Fixed Salary");
        summaryGrid.Columns.Add("Commission", "Commission This Month");
        summaryGrid.Columns.Add("Advances", "Advances This Month");
        summaryGrid.Columns.Add("Remaining", "Remaining Salary");
        summaryGrid.CellDoubleClick += (_, _) => SelectGridStaff();
        return summaryGrid;
    }

    private Control BuildHistory()
    {
        ConfigureGrid(historyGrid);
        historyGrid.Columns.Add("Date", "Date / Time");
        historyGrid.Columns.Add("Amount", "Advance Amount");
        historyGrid.Columns.Add("PaidBy", "Paid By");
        historyGrid.Columns.Add("Notes", "Notes");
        return historyGrid;
    }

    private static void ConfigureGrid(DataGridView grid)
    {
        grid.Dock = DockStyle.Fill;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.ReadOnly = true;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.RowHeadersVisible = false;
    }

    private void LoadStaff()
    {
        var list = service.GetCurrentSummaries();
        staffBox.DataSource = list;
        staffBox.DisplayMember = nameof(SalarySummary.Name);
        staffBox.ValueMember = nameof(SalarySummary.SalesmanId);
        if (list.Count > 0) staffBox.SelectedIndex = 0;
    }

    private SalarySummary? Selected() => staffBox.SelectedItem as SalarySummary;

    private void LoadSelectedSalary()
    {
        var s = Selected();
        if (s == null) return;
        salaryBox.Value = s.MonthlySalary;
        RefreshHistory();
    }

    private void RefreshSummary()
    {
        var rows = service.GetCurrentSummaries();
        summaryGrid.Rows.Clear();
        foreach (var x in rows)
        {
            var i = summaryGrid.Rows.Add(x.Name, x.Code, x.MonthlySalary.ToString("#,##0.##"), x.CommissionThisMonth.ToString("#,##0.##"), x.AdvancesThisMonth.ToString("#,##0.##"), x.RemainingSalary.ToString("#,##0.##"));
            summaryGrid.Rows[i].Tag = x.SalesmanId;
        }
        LoadSelectedSalary();
    }

    private void RefreshHistory()
    {
        historyGrid.Rows.Clear();
        var s = Selected();
        if (s == null) return;
        foreach (var x in service.GetAdvanceHistory(s.SalesmanId))
            historyGrid.Rows.Add(x.PaidAt.ToString("dd-MMM-yyyy hh:mm tt"), x.Amount.ToString("#,##0.##"), x.PaidBy, x.Notes);
    }

    private void SelectGridStaff()
    {
        if (summaryGrid.SelectedRows.Count == 0) return;
        if (summaryGrid.SelectedRows[0].Tag is int id) staffBox.SelectedValue = id;
    }

    private void SaveSalary()
    {
        var s = Selected();
        if (s == null) { MessageBox.Show("Select a staff member first."); return; }
        try
        {
            service.SetMonthlySalary(s.SalesmanId, salaryBox.Value);
            RefreshSummary();
            MessageBox.Show("Monthly salary saved successfully.", "Salary", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Salary", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void PayAdvance()
    {
        var s = Selected();
        if (s == null) { MessageBox.Show("Select a staff member first."); return; }
        if (advanceBox.Value <= 0) { MessageBox.Show("Enter an advance amount greater than zero."); return; }
        if (advanceBox.Value > s.RemainingSalary)
        {
            MessageBox.Show($"Advance cannot exceed current remaining salary of {s.RemainingSalary:#,##0.##}.", "Salary", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }
        try
        {
            service.AddAdvance(s.SalesmanId, advanceBox.Value, Session.CurrentUser?.Username ?? "Admin", notesBox.Text);
            advanceBox.Value = 0; advanceBox.Text = string.Empty;
            notesBox.Clear();
            RefreshSummary();
            MessageBox.Show("Advance recorded and deducted from this month's remaining salary.", "Salary Advance", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Salary Advance", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }
}
