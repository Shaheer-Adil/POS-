using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class SalesForm : Form
{
    private readonly TextBox searchBox = new();
    private readonly DataGridView resultsGrid = new();
    private readonly DataGridView billGrid = new();
    private readonly Label totalLabel = new();
    private readonly NumericUpDown priceBox = new();
    private readonly NumericUpDown addQuantityBox = new();
    private readonly Label securityLabel = new();
    private readonly TextBox salesmanCodeBox = new();
    private readonly Label salesmanStatusLabel = new();
    private readonly Label billSalesmanLabel = new();
    private readonly Label billDateTimeLabel = new();
    

    private readonly SalesService service = new();
    private SalesmanSaleInfo? selectedSalesman;
    private readonly List<SaleCartItem> cart = new();
    private List<SaleScanResult> searchResults = new();
    private string lastInvoiceNumber = string.Empty;
    private decimal lastInvoiceTotal;
    private string lastPaymentText = string.Empty;
    private List<SaleCartItem> lastInvoiceItems = new();
    private string? lastSalesmanName;
    private string? lastSalesmanCode;

    private bool IsAdmin =>
        string.Equals(Session.CurrentUser?.Role, "Admin", StringComparison.OrdinalIgnoreCase);

    public SalesForm()
    {
        Text = "Sales & Billing";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(1050, 700);
        Size = new Size(1250, 800);

        var searchPanel = BuildSearchPanel();
        var salesmanPanel = BuildSalesmanPanel();
        var resultsPanel = BuildResultsPanel();
        var billPanel = BuildBillPanel();
        var footer = BuildFooter();

        Controls.Add(billPanel);
        Controls.Add(footer);
        Controls.Add(resultsPanel);
        Controls.Add(salesmanPanel);
        Controls.Add(searchPanel);
        BackButtonHelper.AddBackButton(this);

        Shown += (_, _) => searchBox.Focus();
    }

    private Control BuildSearchPanel()
    {
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 165,
            Padding = new Padding(20, 15, 20, 8),
            ColumnCount = 5,
            RowCount = 3
        };

        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 155));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 180));

        panel.Controls.Add(new Label
        {
            Text = "SCAN / SEARCH",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        }, 0, 0);

        searchBox.Dock = DockStyle.Fill;
        searchBox.Font = new Font("Consolas", 13);
        searchBox.PlaceholderText = "Scan QR/tag, enter unit number, or type product name";
        searchBox.KeyDown += SearchBox_KeyDown;
        searchBox.TextChanged += SearchBox_TextChanged;
        panel.Controls.Add(searchBox, 1, 0);

        var searchButton = new Button
        {
            Text = "SEARCH / ADD",
            Dock = DockStyle.Fill
        };
        searchButton.Click += (_, _) => SearchOrAdd();
        panel.Controls.Add(searchButton, 2, 0);

        securityLabel.Text = IsAdmin
            ? "ADMIN MODE: Purchase prices visible"
            : "STAFF MODE: Purchase prices hidden";
        securityLabel.Dock = DockStyle.Fill;
        securityLabel.TextAlign = ContentAlignment.MiddleCenter;
        securityLabel.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        panel.Controls.Add(securityLabel, 3, 0);

        panel.Controls.Add(new Label
        {
            Text = "Scanner: code + Enter. If damaged, search by number/name.",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 8),
            TextAlign = ContentAlignment.MiddleLeft
        }, 4, 0);

        panel.Controls.Add(new Label
        {
            Text = "SAME ITEM QUANTITY",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        }, 0, 1);

        addQuantityBox.Dock = DockStyle.Fill;
        addQuantityBox.Minimum = 1;
        addQuantityBox.Maximum = 1000;
        addQuantityBox.Value = 1;
        addQuantityBox.TextAlign = HorizontalAlignment.Left;
        addQuantityBox.Font = new Font("Segoe UI", 11, FontStyle.Bold);
        panel.Controls.Add(addQuantityBox, 1, 1);

        var addSameButton = new Button
        {
            Text = "ADD SAME ITEM",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };
        addSameButton.Click += (_, _) => AddSelectedQuantity();
        panel.Controls.Add(addSameButton, 2, 1);

        panel.Controls.Add(new Label
        {
            Text = "Example: search Kurta → choose a unit → set 2 → ADD SAME ITEM.\r\nEach selected physical unit keeps its own unique code.",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 8),
            TextAlign = ContentAlignment.MiddleLeft
        }, 3, 1);
        panel.SetColumnSpan(panel.GetControlFromPosition(3, 1)!, 2);

        panel.Controls.Add(new Label
        {
            Text = "CUSTOMER SALE PRICE",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        }, 0, 2);

        priceBox.Dock = DockStyle.Fill;
        priceBox.DecimalPlaces = 0;
        priceBox.Maximum = 100000000;
        priceBox.Increment = 100;
        priceBox.ThousandsSeparator = true;
        priceBox.Text = string.Empty;
        priceBox.Enter += (_, _) => { if (priceBox.Value == 0) priceBox.Text = string.Empty; };
        priceBox.MouseDown += (_, _) => { if (priceBox.Value == 0) priceBox.Text = string.Empty; };
        panel.Controls.Add(priceBox, 1, 2);

        var updateButton = new Button
        {
            Text = "UPDATE SELECTED PRICE",
            Dock = DockStyle.Fill
        };
        updateButton.Click += (_, _) => UpdateSelectedPrice();
        panel.Controls.Add(updateButton, 2, 2);

        var khataButton = new Button
        {
            Text = "KHATA / CREDIT",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };
        khataButton.Click += (_, _) => CompleteCreditSale();
        panel.Controls.Add(khataButton, 4, 2);

        return panel;
    }

    private Control BuildSalesmanPanel()
    {
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 78,
            Padding = new Padding(20, 8, 20, 8),
            ColumnCount = 5,
            RowCount = 1
        };

        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 125));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210));

        panel.Controls.Add(new Label
        {
            Text = "SALESMAN CODE",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        }, 0, 0);

        salesmanCodeBox.Dock = DockStyle.Fill;
        salesmanCodeBox.MaxLength = 3;
        salesmanCodeBox.Font = new Font("Consolas", 13, FontStyle.Bold);
        salesmanCodeBox.PlaceholderText = "3-digit code";
        salesmanCodeBox.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                ValidateSalesmanCode();
            }
        };
        panel.Controls.Add(salesmanCodeBox, 1, 0);

        var verify = new Button
        {
            Text = "VERIFY CODE",
            Dock = DockStyle.Fill
        };
        verify.Click += (_, _) => ValidateSalesmanCode();
        panel.Controls.Add(verify, 2, 0);

        salesmanStatusLabel.Text = "No salesman selected";
        salesmanStatusLabel.Dock = DockStyle.Fill;
        salesmanStatusLabel.TextAlign = ContentAlignment.MiddleLeft;
        salesmanStatusLabel.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        panel.Controls.Add(salesmanStatusLabel, 3, 0);

        panel.Controls.Add(new Label
        {
            Text = IsAdmin ? "Admin: code optional" : "Staff: salesman code required",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        }, 4, 0);

        return panel;
    }

    private void ValidateSalesmanCode()
    {
        var code = salesmanCodeBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(code))
        {
            selectedSalesman = null;
            salesmanStatusLabel.Text = IsAdmin ? "No salesman selected" : "Enter a valid 3-digit salesman code.";
            salesmanStatusLabel.ForeColor = SystemColors.ControlText;
            UpdateBillHeader();
            return;
        }

        if (code.Length != 3 || !code.All(char.IsDigit))
        {
            selectedSalesman = null;
            salesmanStatusLabel.Text = "Code must contain exactly 3 digits.";
            salesmanStatusLabel.ForeColor = System.Drawing.Color.DarkRed;
            UpdateBillHeader();
            return;
        }

        var salesman = new SalesmanService().FindActiveByCode(code);
        if (salesman == null)
        {
            selectedSalesman = null;
            salesmanStatusLabel.Text = "Invalid or inactive salesman code.";
            salesmanStatusLabel.ForeColor = System.Drawing.Color.DarkRed;
            UpdateBillHeader();
            return;
        }

        selectedSalesman = salesman;
        salesmanStatusLabel.Text = $"Salesman: {salesman.Name}  |  Code: {salesman.Code}";
        salesmanStatusLabel.ForeColor = System.Drawing.Color.DarkGreen;
        UpdateBillHeader();
    }

    private Control BuildResultsPanel()
    {
        var outer = new Panel
        {
            Dock = DockStyle.Top,
            Height = 190,
            Padding = new Padding(20, 0, 20, 8)
        };

        var title = new Label
        {
            Text = "AVAILABLE MATCHES — select the exact physical unit",
            Dock = DockStyle.Top,
            Height = 28,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };

        ConfigureResultsGrid();

        outer.Controls.Add(resultsGrid);
        outer.Controls.Add(title);
        return outer;
    }

    private Control BuildBillPanel()
    {
        ConfigureBillGrid();

        var panel = new Panel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(20, 0, 20, 0)
        };

        billSalesmanLabel.Text = "SALESMAN: Not selected";
        billSalesmanLabel.Dock = DockStyle.Top;
        billSalesmanLabel.Height = 28;
        billSalesmanLabel.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        billSalesmanLabel.TextAlign = ContentAlignment.MiddleLeft;

        billDateTimeLabel.Text = $"DATE / TIME: {DateTime.Now:dd-MMM-yyyy hh:mm:ss tt}";
        billDateTimeLabel.Dock = DockStyle.Top;
        billDateTimeLabel.Height = 28;
        billDateTimeLabel.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        billDateTimeLabel.TextAlign = ContentAlignment.MiddleLeft;

        panel.Controls.Add(billGrid);
        panel.Controls.Add(billDateTimeLabel);
        panel.Controls.Add(billSalesmanLabel);
        return panel;
    }

    private void UpdateBillHeader()
    {
        billSalesmanLabel.Text = selectedSalesman == null
            ? "SALESMAN: Not selected"
            : $"SALESMAN: {selectedSalesman.Name}   |   CODE: {selectedSalesman.Code}";
        billDateTimeLabel.Text = $"DATE / TIME: {DateTime.Now:dd-MMM-yyyy hh:mm:ss tt}";
    }



    private Control BuildFooter()
    {
        var footer = new TableLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 90,
            Padding = new Padding(20, 10, 20, 15),
            ColumnCount = 4
        };

        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 180));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 180));

        totalLabel.Text = "TOTAL: Rs. 0";
        totalLabel.Dock = DockStyle.Fill;
        totalLabel.TextAlign = ContentAlignment.MiddleLeft;
        totalLabel.Font = new Font("Segoe UI", 18, FontStyle.Bold);
        footer.Controls.Add(totalLabel, 0, 0);

        var remove = new Button
        {
            Text = "REMOVE SELECTED",
            Dock = DockStyle.Fill
        };
        remove.Click += (_, _) => RemoveSelected();
        footer.Controls.Add(remove, 1, 0);

        var completeBill = new Button
        {
            Text = "COMPLETE BILL",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 11, FontStyle.Bold)
        };
        completeBill.Click += (_, _) => CompleteSale();
        footer.Controls.Add(completeBill, 2, 0);

        var billHistory = new Button
        {
            Text = "BILL HISTORY (LAST 3)",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };
        billHistory.Click += (_, _) =>
        {
            using var form = new BillHistoryForm();
            form.ShowDialog(this);
        };
        footer.Controls.Add(billHistory, 3, 0);

        return footer;
    }

    private void ConfigureResultsGrid()
    {
        resultsGrid.Dock = DockStyle.Fill;
        resultsGrid.ReadOnly = true;
        resultsGrid.AllowUserToAddRows = false;
        resultsGrid.AutoGenerateColumns = false;
        resultsGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        resultsGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        resultsGrid.MultiSelect = false;

        AddColumn(resultsGrid, "UnitCode", "Tag / Unit Number", 105);
        AddColumn(resultsGrid, "ProductName", "Product", 130);
        AddColumn(resultsGrid, "ProductCode", "Product Code", 95);
        AddColumn(resultsGrid, "SalePrice", "Sale Price", 95, "N0");

        if (IsAdmin)
            AddColumn(resultsGrid, "PurchasePrice", "Purchase Price", 95, "N0");

        resultsGrid.DoubleClick += (_, _) => AddSelectedSearchResult();
    }

    private void ConfigureBillGrid()
    {
        billGrid.Dock = DockStyle.Fill;
        billGrid.ReadOnly = true;
        billGrid.AllowUserToAddRows = false;
        billGrid.AutoGenerateColumns = false;
        billGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        billGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        billGrid.MultiSelect = false;

        AddColumn(billGrid, "UnitCode", "Tag / Unit Number", 110);
        AddColumn(billGrid, "ProductName", "Product", 130);

        // SECURITY REQUIREMENT:
        // Staff must not see purchase price anywhere on the sales screen.
        // Admin can see it because IsAdmin is based on the authenticated role.
        if (IsAdmin)
            AddColumn(billGrid, "PurchasePrice", "Purchase Price", 95, "N0");

        AddColumn(billGrid, "SalePrice", "Customer Sale Price", 110, "N0");
    }

    private static void AddColumn(
        DataGridView grid,
        string property,
        string header,
        int weight,
        string? format = null)
    {
        var c = new DataGridViewTextBoxColumn
        {
            DataPropertyName = property,
            HeaderText = header,
            FillWeight = weight
        };

        if (format != null)
            c.DefaultCellStyle = new DataGridViewCellStyle { Format = format };

        grid.Columns.Add(c);
    }

    private void SearchBox_TextChanged(object? sender, EventArgs e)
    {
        var query = searchBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(query))
        {
            searchResults.Clear();
            resultsGrid.DataSource = null;
            return;
        }

        // Live product suggestions: every typed character immediately filters
        // the available in-stock products shown in the grid below.
        searchResults = service.SearchInStock(query);
        resultsGrid.DataSource = null;
        resultsGrid.DataSource = searchResults;
        if (resultsGrid.Rows.Count > 0)
            resultsGrid.Rows[0].Selected = true;
    }

    private void SearchBox_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            SearchOrAdd();
        }
    }

    private void SearchOrAdd()
    {
        var query = searchBox.Text.Trim();

        if (string.IsNullOrWhiteSpace(query))
            return;

        // First priority: exact physical unit/tag number.
        var exact = service.ScanUnit(query);

        if (exact != null)
        {
            if (!string.Equals(exact.Status, "InStock", StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show(
                    $"This tagged unit is currently {exact.Status} and cannot be added to a new sale.",
                    "Unit Not Available",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                return;
            }

            AddToCart(exact);
            return;
        }

        // If the QR is damaged/unreadable, search by product name/code/unit text.
        searchResults = service.SearchInStock(query);

        resultsGrid.DataSource = null;
        resultsGrid.DataSource = searchResults;

        if (searchResults.Count == 0)
        {
            MessageBox.Show(
                "No available product was found. You can search using the unit number, product code, or product name.",
                "No Match",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        // Typing is now an autocomplete workflow. Keep the matching product
        // visible so the user can select/double-click the exact physical unit.
        resultsGrid.Focus();
        resultsGrid.Rows[0].Selected = true;
    }

    private void AddSelectedSearchResult()
    {
        if (resultsGrid.CurrentRow?.DataBoundItem is SaleScanResult item)
            AddToCart(item);
    }

    private void AddSelectedQuantity()
    {
        if (resultsGrid.CurrentRow?.DataBoundItem is not SaleScanResult selected)
        {
            MessageBox.Show(
                "Search for the product first, then select one of its available physical units.",
                "Select Product",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            resultsGrid.Focus();
            return;
        }

        var quantity = (int)addQuantityBox.Value;
        var availableUnits = searchResults
            .Where(x => x.ProductId == selected.ProductId &&
                        string.Equals(x.Status, "InStock", StringComparison.OrdinalIgnoreCase) &&
                        cart.All(c => c.InventoryUnitId != x.InventoryUnitId))
            .Take(quantity)
            .ToList();

        if (availableUnits.Count < quantity)
        {
            MessageBox.Show(
                $"Only {availableUnits.Count} additional physical unit(s) of {selected.ProductName} are available from the current search results.",
                "Insufficient Stock",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        foreach (var unit in availableUnits)
            AddToCart(unit, showDuplicateMessage: false, keepSearchOpen: true);

        resultsGrid.DataSource = null;
        resultsGrid.DataSource = searchResults;
        addQuantityBox.Value = 1;
        searchBox.Focus();
    }

    private void AddToCart(SaleScanResult item, bool showDuplicateMessage = true, bool keepSearchOpen = false)
    {
        if (cart.Any(x => x.InventoryUnitId == item.InventoryUnitId))
        {
            if (showDuplicateMessage)
            {
                MessageBox.Show(
                    "This physical tagged unit is already in the current bill. Select another unit or use SAME ITEM QUANTITY to add another physical unit of the same product.",
                    "Duplicate Physical Unit",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
            }
            return;
        }

        priceBox.Value = Math.Min(priceBox.Maximum, item.SalePrice);

        cart.Add(new SaleCartItem
        {
            InventoryUnitId = item.InventoryUnitId,
            ProductId = item.ProductId,
            UnitCode = item.UnitCode,
            ProductName = item.ProductName,
            PurchasePrice = item.PurchasePrice,
            SalePrice = item.SalePrice
        });

        RefreshBill();
        if (!keepSearchOpen)
        {
            searchBox.Clear();
            resultsGrid.DataSource = null;
            searchResults.Clear();
        }
        searchBox.Focus();
    }

    private void UpdateSelectedPrice()
    {
        if (billGrid.CurrentRow?.DataBoundItem is not SaleCartItem selected)
        {
            MessageBox.Show(
                "Select an item in the bill first.",
                "Select Item",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        if (priceBox.Value < selected.PurchasePrice)
        {
            MessageBox.Show(
                "The customer sale price cannot be lower than the purchase price.",
                "Invalid Sale Price",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        selected.SalePrice = priceBox.Value;
        RefreshBill();
    }

    private void RemoveSelected()
    {
        if (billGrid.CurrentRow?.DataBoundItem is SaleCartItem selected)
        {
            cart.Remove(selected);
            RefreshBill();
            searchBox.Focus();
        }
    }

    private void RefreshBill()
    {
        billGrid.DataSource = null;
        billGrid.DataSource = cart.ToList();
        totalLabel.Text = $"TOTAL: Rs. {cart.Sum(x => x.SalePrice):N0}";
    }

    private void CompleteSale()
    {
        if (cart.Count == 0)
        {
            MessageBox.Show(
                "Add at least one product to the bill.",
                "Empty Bill",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        try
        {
            foreach (var item in cart)
            {
                if (item.SalePrice < item.PurchasePrice)
                    throw new InvalidOperationException(
                        $"Sale price for {item.UnitCode} cannot be lower than purchase price.");
            }

            if (!IsAdmin && selectedSalesman == null)
            {
                MessageBox.Show(
                    "Enter and verify the 3-digit salesman code before completing a Staff sale.",
                    "Salesman Code Required",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                salesmanCodeBox.Focus();
                return;
            }

            if (!string.IsNullOrWhiteSpace(salesmanCodeBox.Text) && selectedSalesman == null)
            {
                ValidateSalesmanCode();
                if (selectedSalesman == null) return;
            }

            var total = cart.Sum(x => x.SalePrice);

            var result = service.CompleteSale(
                cart,
                Session.CurrentUser?.Username ?? "Staff",
                selectedSalesman?.Code ?? string.Empty,
                null);

            lastInvoiceNumber = result.InvoiceNumber;
            lastInvoiceTotal = result.TotalAmount;
            lastPaymentText = "Cash";
            lastInvoiceItems = cart.Select(x => new SaleCartItem
            {
                InventoryUnitId = x.InventoryUnitId,
                ProductId = x.ProductId,
                UnitCode = x.UnitCode,
                ProductName = x.ProductName,
                PurchasePrice = x.PurchasePrice,
                SalePrice = x.SalePrice
            }).ToList();
            lastSalesmanName = result.SalesmanName;
            lastSalesmanCode = result.SalesmanCode;
            // Complete Bill finalizes the sale and immediately sends the bill to the printer.
            PrintCompletedBill(cart, result.InvoiceNumber, result.TotalAmount, "Cash",
                result.SalesmanName);
            MessageBox.Show(
                $"Sale completed successfully.\\n\\n" +
                $"Invoice: {result.InvoiceNumber}\\n" +
                $"Total: Rs. {result.TotalAmount:N0}\\n" +
                (string.IsNullOrWhiteSpace(result.SalesmanName) ? "" : $"Salesman: {result.SalesmanName} ({result.SalesmanCode})\\n") +
                "Payment type: Cash\\n\\n" +
                "The sold units have been removed from available stock.\\n" +
                "Salesman commission has been recorded in the backend.",
                "Sale Completed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            cart.Clear();
            RefreshBill();
            searchBox.Clear();
            resultsGrid.DataSource = null;
            priceBox.Value = 0; priceBox.Text = string.Empty;
            addQuantityBox.Value = 1;
            salesmanCodeBox.Clear();
            selectedSalesman = null;
            salesmanStatusLabel.Text = "No salesman selected";
            salesmanStatusLabel.ForeColor = SystemColors.ControlText;
            UpdateBillHeader();
            searchBox.Focus();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "Sale Could Not Be Completed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
    private void CompleteCreditSale()
    {
        if (cart.Count == 0)
        {
            MessageBox.Show(
                "Add at least one product to the bill before creating a Khata sale.",
                "Empty Bill",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        try
        {
            foreach (var item in cart)
            {
                if (item.SalePrice < item.PurchasePrice)
                    throw new InvalidOperationException(
                        $"Sale price for {item.UnitCode} cannot be lower than purchase price.");
            }

            if (!IsAdmin && selectedSalesman == null)
            {
                MessageBox.Show(
                    "Enter and verify the 3-digit salesman code before completing a Staff sale.",
                    "Salesman Code Required",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                salesmanCodeBox.Focus();
                return;
            }

            if (!string.IsNullOrWhiteSpace(salesmanCodeBox.Text) && selectedSalesman == null)
            {
                ValidateSalesmanCode();
                if (selectedSalesman == null) return;
            }

            var total = cart.Sum(x => x.SalePrice);
            using var creditDialog = new CreditSaleDialog(total);
            if (creditDialog.ShowDialog(this) != DialogResult.OK)
                return;

            var creditInfo = new CreditSaleInfo
            {
                CustomerName = creditDialog.CustomerName,
                PhoneNumber = creditDialog.PhoneNumber,
                AmountPaid = creditDialog.AmountPaid
            };

            var result = service.CompleteSale(
                cart,
                Session.CurrentUser?.Username ?? "Staff",
                selectedSalesman?.Code ?? string.Empty,
                creditInfo);

            var outstanding = result.TotalAmount - creditInfo.AmountPaid;
            lastInvoiceNumber = result.InvoiceNumber;
            lastInvoiceTotal = result.TotalAmount;
            lastPaymentText = "Credit / Khata";
            lastInvoiceItems = cart.Select(x => new SaleCartItem
            {
                InventoryUnitId = x.InventoryUnitId,
                ProductId = x.ProductId,
                UnitCode = x.UnitCode,
                ProductName = x.ProductName,
                PurchasePrice = x.PurchasePrice,
                SalePrice = x.SalePrice
            }).ToList();
            lastSalesmanName = result.SalesmanName;
            lastSalesmanCode = result.SalesmanCode;
            // Complete Bill finalizes the Khata sale and immediately prints the bill.
            PrintCompletedBill(
                cart,
                result.InvoiceNumber,
                result.TotalAmount,
                "Credit / Khata",
                result.SalesmanName);
            MessageBox.Show(
                $"Khata sale completed successfully.\r\n\r\n" +
                $"Invoice: {result.InvoiceNumber}\r\n" +
                $"Total: Rs. {result.TotalAmount:N0}\r\n" +
                $"Outstanding: Rs. {outstanding:N0}\r\n" +
                "The bill will now be printed.",
                "Khata Sale Completed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            cart.Clear();
            RefreshBill();
            searchBox.Clear();
            resultsGrid.DataSource = null;
            priceBox.Value = 0; priceBox.Text = string.Empty;
            addQuantityBox.Value = 1;
            salesmanCodeBox.Clear();
            selectedSalesman = null;
            salesmanStatusLabel.Text = "No salesman selected";
            salesmanStatusLabel.ForeColor = SystemColors.ControlText;
            UpdateBillHeader();
            searchBox.Focus();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "Khata Sale Could Not Be Completed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private void PrintCompletedBill(
        IReadOnlyList<SaleCartItem> items,
        string invoiceNumber,
        decimal total,
        string paymentType,
        string? salesmanName)
    {
        try
        {
            using var document = new PrintDocument();
            document.DocumentName = $"Bill-{invoiceNumber}";

            // Use a standard 80mm thermal-receipt width instead of the printer's
            // default page size (which can otherwise be A4/Letter). PaperSize
            // values are in hundredths of an inch: 80mm ≈ 3.15in = 315.
            // The height is calculated from the number of items so the receipt
            // remains a compact, shop-style roll receipt.
            const int receiptWidth = 330;
            int receiptHeight = Math.Clamp(330 + (items.Count * 42), 450, 2000);
            var receiptPaper = new PaperSize("Receipt 83mm", receiptWidth, receiptHeight);

            document.DefaultPageSettings.PaperSize = receiptPaper;
            document.DefaultPageSettings.Margins = new Margins(8, 8, 8, 8);
            document.DefaultPageSettings.Landscape = false;

            var saleTime = DateTime.Now;
            var soldBy = Session.CurrentUser?.Username ?? "Staff";

            document.PrintPage += (_, e) =>
            {
                using var titleFont = new Font("Segoe UI", 15, FontStyle.Bold);
                using var sectionFont = new Font("Segoe UI", 10, FontStyle.Bold);
                using var bodyFont = new Font("Segoe UI", 9);
                using var smallFont = new Font("Segoe UI", 8);

                float y = 35;
                float left = e.MarginBounds.Left;
                float right = e.MarginBounds.Right;

                e.Graphics.DrawString("Awais Shall", titleFont, Brushes.Black, left, y);
                y += 32;
                e.Graphics.DrawString("SALES BILL / INVOICE", sectionFont, Brushes.Black, left, y);
                y += 22;
                e.Graphics.DrawString($"Invoice No: {invoiceNumber}", bodyFont, Brushes.Black, left, y);
                y += 18;
                e.Graphics.DrawString($"Date / Time: {saleTime:dd-MMM-yyyy hh:mm:ss tt}", bodyFont, Brushes.Black, left, y);
                y += 18;
                e.Graphics.DrawString($"Processed By: {soldBy}", bodyFont, Brushes.Black, left, y);
                y += 18;

                if (!string.IsNullOrWhiteSpace(salesmanName))
                {
                    e.Graphics.DrawString($"Salesman: {salesmanName}", bodyFont, Brushes.Black, left, y);
                    y += 18;
                }

                e.Graphics.DrawLine(Pens.Black, left, y, right, y);
                y += 10;
                e.Graphics.DrawString("ITEMS", sectionFont, Brushes.Black, left, y);
                y += 22;

                int index = 1;
                foreach (var item in items)
                {
                    e.Graphics.DrawString($"{index}. {item.ProductName}", bodyFont, Brushes.Black, left, y);
                    y += 18;
                    e.Graphics.DrawString($"   Unit/Tag: {item.UnitCode}", smallFont, Brushes.Black, left + 8, y);
                    e.Graphics.DrawString($"Rs. {item.SalePrice:N0}", bodyFont, Brushes.Black, right - 105, y);
                    y += 20;
                    index++;
                }

                e.Graphics.DrawLine(Pens.Black, left, y, right, y);
                y += 10;
                e.Graphics.DrawString($"Items: {items.Count}", bodyFont, Brushes.Black, left, y);
                y += 20;
                e.Graphics.DrawString($"TOTAL: Rs. {total:N0}", sectionFont, Brushes.Black, left, y);
                y += 22;
                e.Graphics.DrawString($"Payment Type: {paymentType}", bodyFont, Brushes.Black, left, y);
                y += 28;
                e.Graphics.DrawString("Thank you for shopping with us.", smallFont, Brushes.Black, left, y);
                y += 16;
                e.Graphics.DrawString("This bill contains the complete sale transaction details.", smallFont, Brushes.Black, left, y);

                e.HasMorePages = false;
            };

            document.Print();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "The sale was completed successfully, but the bill could not be printed.\r\n\r\n" +
                "Please check that a printer is installed and available.\r\n\r\n" +
                ex.Message,
                "Printing Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }

}
