using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class CreditManagementForm : Form
{
    private readonly CreditService service = new();
    private readonly TextBox searchBox = new();
    private readonly DataGridView customersGrid = new();
    private readonly Label summaryLabel = new();
    private CreditCustomerSummary? selected;

    public CreditManagementForm()
    {
        Text = "Khata / Credit Management"; StartPosition = FormStartPosition.CenterParent; MinimumSize = new Size(1100, 700); Size = new Size(1250, 780);
        var top = new TableLayoutPanel { Dock = DockStyle.Top, Height = 80, Padding = new Padding(18), ColumnCount = 3 }; top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150)); top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100)); top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130));
        top.Controls.Add(new Label { Text = "SEARCH CUSTOMER", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) }, 0, 0); searchBox.Dock = DockStyle.Fill; searchBox.PlaceholderText = "Name or phone number"; searchBox.KeyDown += (_, e) => { if (e.KeyCode == Keys.Enter) { e.SuppressKeyPress = true; LoadCustomers(); } }; top.Controls.Add(searchBox, 1, 0); var search = new Button { Text = "SEARCH", Dock = DockStyle.Fill }; search.Click += (_, _) => LoadCustomers(); top.Controls.Add(search, 2, 0);
        ConfigureCustomers();
        // The old right-side transaction/history box has been removed.
        var footer = new TableLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 85,
            Padding = new Padding(18, 8, 18, 15),
            ColumnCount = 3
        };
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));

        summaryLabel.Dock = DockStyle.Fill;
        summaryLabel.Font = new Font("Segoe UI", 11, FontStyle.Bold);
        footer.Controls.Add(summaryLabel, 0, 0);

        var payment = new Button
        {
            Text = "RECORD PAYMENT",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        };
        payment.Click += (_, _) => RecordPayment();
        footer.Controls.Add(payment, 1, 0);

        var delete = new Button
        {
            Text = "DELETE KHATA",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        };
        delete.Click += (_, _) => DeleteSelectedKhata();
        footer.Controls.Add(delete, 2, 0);

        Controls.Add(customersGrid);
        Controls.Add(footer);
        Controls.Add(top);
        BackButtonHelper.AddBackButton(this);
        Shown += (_, _) =>
        {
            LoadCustomers();
            searchBox.Focus();
        };
    }

    private void ConfigureCustomers()
    { customersGrid.Dock = DockStyle.Fill; customersGrid.ReadOnly = true; customersGrid.AllowUserToAddRows = false; customersGrid.AutoGenerateColumns = false; customersGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; customersGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; customersGrid.MultiSelect = false; AddColumn(customersGrid,"CustomerName","Customer",130); AddColumn(customersGrid,"PhoneNumber","Phone",95); AddColumn(customersGrid,"TotalCredit","Credit",90,"#,##0.##"); AddColumn(customersGrid,"TotalPaid","Paid",90,"#,##0.##"); AddColumn(customersGrid,"Outstanding","Outstanding",105,"#,##0.##"); customersGrid.SelectionChanged += (_, _) => SelectCustomer(); }
    private static void AddColumn(DataGridView grid,string prop,string header,int weight,string? format=null){ var c=new DataGridViewTextBoxColumn{DataPropertyName=prop,HeaderText=header,FillWeight=weight}; if(format!=null)c.DefaultCellStyle=new DataGridViewCellStyle{Format=format}; grid.Columns.Add(c); }
    private void LoadCustomers(){ customersGrid.DataSource=null; customersGrid.DataSource=service.SearchCustomers(searchBox.Text); if(customersGrid.Rows.Count>0) customersGrid.Rows[0].Selected=true; else { selected=null; summaryLabel.Text="No customer credit accounts found."; } }
    private void SelectCustomer(){ if(customersGrid.CurrentRow?.DataBoundItem is CreditCustomerSummary item){ selected=item; summaryLabel.Text=$"{item.CustomerName}  |  Credit: Rs. {item.TotalCredit:#,##0.##}  |  Paid: Rs. {item.TotalPaid:#,##0.##}  |  OUTSTANDING: Rs. {item.Outstanding:#,##0.##}"; } }
    private void DeleteSelectedKhata()
    {
        if (selected == null)
        {
            MessageBox.Show("Select a customer first.", "Khata", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        var result = MessageBox.Show(
            $"Would you like to delete this khata?\r\n\r\nCustomer: {selected.CustomerName}",
            "Delete Khata",
            MessageBoxButtons.OKCancel,
            MessageBoxIcon.Warning);

        if (result != DialogResult.OK)
            return;

        try
        {
            service.DeleteAccount(selected.CreditAccountId);
            selected = null;
            LoadCustomers();

            MessageBox.Show("Khata deleted successfully.", "Khata Deleted",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Delete Error",
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void RecordPayment(){ if(selected==null){MessageBox.Show("Select a customer first.","Khata",MessageBoxButtons.OK,MessageBoxIcon.Information);return;} if(selected.Outstanding<=0){MessageBox.Show("This customer has no outstanding balance.","Khata",MessageBoxButtons.OK,MessageBoxIcon.Information);return;} using var dlg=new PaymentDialog(selected.CustomerName, selected.Outstanding); if(dlg.ShowDialog(this)!=DialogResult.OK)return; try { service.RecordPayment(selected.CreditAccountId,dlg.Amount,dlg.Notes,Session.CurrentUser?.Username??"Staff"); LoadCustomers(); SelectCustomer(); MessageBox.Show("Payment recorded successfully.","Payment Saved",MessageBoxButtons.OK,MessageBoxIcon.Information); } catch(Exception ex){MessageBox.Show(ex.Message,"Payment Error",MessageBoxButtons.OK,MessageBoxIcon.Error);} }
}

public class PaymentDialog : Form
{ public decimal Amount => amountBox.Value; public string Notes=>notesBox.Text.Trim(); private readonly NumericUpDown amountBox=new(); private readonly TextBox notesBox=new(); public PaymentDialog(string customer,decimal outstanding){ Text="Record Khata Payment"; StartPosition=FormStartPosition.CenterParent; Size=new Size(480,280); var grid=new TableLayoutPanel{Dock=DockStyle.Fill,Padding=new Padding(22),ColumnCount=2,RowCount=4};grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute,150));grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent,100)); grid.Controls.Add(new Label{Text="CUSTOMER",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,0);grid.Controls.Add(new Label{Text=customer,Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft,Font=new Font("Segoe UI",10,FontStyle.Bold)},1,0);grid.Controls.Add(new Label{Text="OUTSTANDING",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,1);grid.Controls.Add(new Label{Text=$"Rs. {outstanding:#,##0.##}",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},1,1);grid.Controls.Add(new Label{Text="PAYMENT",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,2);amountBox.DecimalPlaces=0;amountBox.Maximum=outstanding;amountBox.Dock=DockStyle.Fill;amountBox.ThousandsSeparator=true; amountBox.Text = string.Empty; amountBox.Enter += (_, _) => { if (amountBox.Value == 0) amountBox.Text = string.Empty; }; amountBox.MouseDown += (_, _) => { if (amountBox.Value == 0) amountBox.Text = string.Empty; }; grid.Controls.Add(amountBox,1,2);grid.Controls.Add(new Label{Text="NOTES",Dock=DockStyle.Fill,TextAlign=ContentAlignment.MiddleLeft},0,3);notesBox.Dock=DockStyle.Fill;grid.Controls.Add(notesBox,1,3);var ok=new Button{Text="SAVE",Width=100};ok.Click+=(_,_)=>{if(Amount<=0){MessageBox.Show("Enter a payment amount.");return;}DialogResult=DialogResult.OK;Close();};var cancel=new Button{Text="CANCEL",Width=100};cancel.Click+=(_,_)=>{DialogResult=DialogResult.Cancel;Close();};var buttons=new FlowLayoutPanel{Dock=DockStyle.Bottom,Height=45,FlowDirection=FlowDirection.RightToLeft};buttons.Controls.Add(ok);buttons.Controls.Add(cancel);grid.Controls.Add(buttons,0,4);grid.SetColumnSpan(buttons,2);grid.RowCount=5;Controls.Add(grid); } }
