# UI Fix 32

## Sales & Billing
- Added live product autocomplete: matching in-stock products refresh below the search box as each character is typed.
- Enter on an exact scanner/unit code still adds the scanned physical unit automatically.
- Product-name searches now remain as selectable suggestions instead of auto-adding a single match.
- Added a `PRINT LAST BILL` option in the Sales & Billing footer.
- Completed cash and credit/Khata sales continue to print automatically, and the last completed bill can be printed again.

## Price display/input
- Sale-price and purchase-price UI displays now use whole-rupee formatting without `.00`.
- Sales price input, product-entry price inputs, and exchange replacement price input no longer show decimal places.
- Inventory, sales, exchange, returns, QR tags, and Recently Deleted sale/purchase price displays were updated accordingly.
- Database decimal precision is unchanged; this is a UI formatting/input change.

No images were generated.
