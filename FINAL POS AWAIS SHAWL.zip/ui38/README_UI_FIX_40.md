# UI FIX 40

Changes:
- Added an eye button beside the password field on the login page to show/hide the password.
- Removed the informational text block above the ADD TO INVENTORY button on Staff -> Product Entry to eliminate clipped/cut text.
- Preserved all other UI and functionality from UI Fix 39.
