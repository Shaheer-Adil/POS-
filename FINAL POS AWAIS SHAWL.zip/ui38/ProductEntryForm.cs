using System;
using System.Drawing;
using System.Globalization;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class ProductEntryForm : Form
{
    private readonly TextBox nameBox = new();
    private readonly TextBox categoryBox = new();
    private readonly TextBox quantityBox = new();
    private readonly TextBox purchaseBox = new();
    private readonly TextBox saleBox = new();
    private readonly ProductService productService = new();

    public ProductEntryForm()
    {
        Text = "Product Entry";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(700, 560);
        Size = new Size(820, 620);

        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(35),
            ColumnCount = 2,
            RowCount = 8
        };
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));
        root.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 70));

        var heading = new Label
        {
            Text = "PRODUCT ENTRY",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 20, FontStyle.Bold),
            AutoSize = false
        };
        root.Controls.Add(heading, 0, 0);
        root.SetColumnSpan(heading, 2);

        AddRow(root, "Product Name", nameBox, 1, "Enter product name");
        AddRow(root, "Category", categoryBox, 2, "Enter category");
        AddRow(root, "Quantity", quantityBox, 3, "Enter quantity");
        AddRow(root, "Purchase Price (Rs.)", purchaseBox, 4, "Enter purchase price");
        AddRow(root, "Sale Price (Rs.)", saleBox, 5, "Enter sale price");

        ConfigureNumericTextBox(quantityBox, allowDecimal: false);
        ConfigureNumericTextBox(purchaseBox, allowDecimal: false);
        ConfigureNumericTextBox(saleBox, allowDecimal: false);

        // Keep the button prominent, but centered at the top of the action area.
        // Width and height are intentionally based on the previous button size: 3x width and 2x height.
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 100));
        var actionPanel = new Panel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(0, 0, 0, 0)
        };

        var save = new Button
        {
            Text = "ADD TO INVENTORY",
            Width = 570,
            Height = 84,
            Anchor = AnchorStyles.Top,
            Font = new Font("Segoe UI", 10, FontStyle.Bold),
            Margin = new Padding(0)
        };
        actionPanel.Controls.Add(save);
        actionPanel.Resize += (_, _) =>
        {
            save.Left = Math.Max(0, (actionPanel.ClientSize.Width - save.Width) / 2);
            save.Top = 0;
        };
        save.Click += Save_Click;
        root.Controls.Add(actionPanel, 0, 7);
        root.SetColumnSpan(actionPanel, 2);

        Controls.Add(root);
        Shown += (_, _) => nameBox.Focus();
            BackButtonHelper.AddBackButton(this);
}

    private static void AddRow(TableLayoutPanel table, string labelText, TextBox control, int row, string placeholder)
    {
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
        table.Controls.Add(new Label
        {
            Text = labelText,
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        }, 0, row);

        control.Dock = DockStyle.Fill;
        control.Font = new Font("Segoe UI", 11);
        control.PlaceholderText = placeholder;
        control.Margin = new Padding(3, 8, 3, 8);
        table.Controls.Add(control, 1, row);
    }

    private static void ConfigureNumericTextBox(TextBox box, bool allowDecimal)
    {
        box.TextAlign = HorizontalAlignment.Left;
        box.KeyPress += (_, e) =>
        {
            if (char.IsControl(e.KeyChar))
                return;

            if (char.IsDigit(e.KeyChar))
                return;

            if (allowDecimal && (e.KeyChar == '.' || e.KeyChar == ','))
            {
                var separator = CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator;
                if (!box.Text.Contains(separator, StringComparison.Ordinal) &&
                    !box.Text.Contains('.', StringComparison.Ordinal) &&
                    !box.Text.Contains(',', StringComparison.Ordinal))
                    return;
            }

            e.Handled = true;
        };
    }

    private static bool TryReadInteger(TextBox box, string fieldName, out int value)
    {
        if (int.TryParse(box.Text.Trim(), NumberStyles.Integer, CultureInfo.CurrentCulture, out value) && value > 0)
            return true;

        MessageBox.Show($"Enter a valid {fieldName}.", "Required Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        box.Focus();
        return false;
    }

    private static bool TryReadDecimal(TextBox box, string fieldName, out decimal value)
    {
        var text = box.Text.Trim().Replace(',', '.');
        if (decimal.TryParse(text, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign,
            CultureInfo.InvariantCulture, out value) && value >= 0)
            return true;

        MessageBox.Show($"Enter a valid {fieldName}.", "Required Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        box.Focus();
        return false;
    }

    private void Save_Click(object? sender, EventArgs e)
    {
        try
        {
            if (string.IsNullOrWhiteSpace(nameBox.Text))
            {
                MessageBox.Show("Product name is required.", "Required Value", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                nameBox.Focus();
                return;
            }

            if (!TryReadInteger(quantityBox, "quantity", out var quantity))
                return;
            if (!TryReadDecimal(purchaseBox, "purchase price", out var purchasePrice))
                return;
            if (!TryReadDecimal(saleBox, "sale price", out var salePrice))
                return;

            if (salePrice < purchasePrice)
            {
                MessageBox.Show(
                    "Sale price cannot be lower than purchase price.",
                    "Invalid Price",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                saleBox.Focus();
                return;
            }

            var result = productService.AddProduct(
                nameBox.Text,
                categoryBox.Text,
                quantity,
                purchasePrice,
                salePrice);

            MessageBox.Show(
                "Product successfully added to inventory.\n\n" +
                $"Quantity added: {result.Quantity:N0}\n" +
                $"Product code: {result.ProductCode}\n\n" +
                "A unique QR code has been generated for each inventory unit. " +
                "The printable QR tag preview will open next.",
                "Product Added",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            using (var tagForm = new TagPrintForm(result.Tags))
            {
                tagForm.ShowDialog(this);
            }

            nameBox.Clear();
            categoryBox.Clear();
            quantityBox.Clear();
            purchaseBox.Clear();
            saleBox.Clear();
            nameBox.Focus();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "Could Not Add Product",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }
}
