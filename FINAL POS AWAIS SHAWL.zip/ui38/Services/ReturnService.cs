using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Services;

public class ReturnSearchResult
{
    public int SaleItemId { get; set; }
    public int InventoryUnitId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string ProductCode { get; set; } = string.Empty;
    public decimal OriginalSalePrice { get; set; }
    public decimal PurchasePrice { get; set; }
    public DateTime SaleDate { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
}

public class ReturnService
{
    public ReturnSearchResult? FindSoldUnit(string unitCode)
    {
        if (string.IsNullOrWhiteSpace(unitCode))
            return null;

        using var db = new ShopDbContext();

        return db.SaleItems
            .AsNoTracking()
            .Include(x => x.Sale)
            .Include(x => x.InventoryUnit)
            .ThenInclude(x => x!.Product)
            .Where(x =>
                x.UnitCode == unitCode.Trim() &&
                x.InventoryUnit!.Status == "Sold")
            .Where(x => !db.ProductReturns.Any(r => r.InventoryUnitId == x.InventoryUnitId))
            .Select(x => new ReturnSearchResult
            {
                SaleItemId = x.SaleItemId,
                InventoryUnitId = x.InventoryUnitId,
                UnitCode = x.UnitCode,
                ProductName = x.ProductName,
                ProductCode = x.InventoryUnit!.Product!.ProductCode,
                OriginalSalePrice = x.SalePrice,
                PurchasePrice = x.PurchasePrice,
                SaleDate = x.Sale!.SaleDate,
                InvoiceNumber = x.Sale.InvoiceNumber,
                Status = x.InventoryUnit.Status
            })
            .SingleOrDefault();
    }

    public List<ReturnSearchResult> SearchSoldUnits(string searchText)
    {
        if (string.IsNullOrWhiteSpace(searchText))
            return new List<ReturnSearchResult>();

        var text = searchText.Trim();

        using var db = new ShopDbContext();

        return db.SaleItems
            .AsNoTracking()
            .Include(x => x.Sale)
            .Include(x => x.InventoryUnit)
            .ThenInclude(x => x!.Product)
            .Where(x =>
                x.InventoryUnit!.Status == "Sold" &&
                !db.ProductReturns.Any(r => r.InventoryUnitId == x.InventoryUnitId) &&
                (x.UnitCode.Contains(text) ||
                 x.ProductName.Contains(text) ||
                 x.InventoryUnit.Product!.ProductCode.Contains(text)))
            .OrderByDescending(x => x.Sale!.SaleDate)
            .ThenBy(x => x.ProductName)
            .Select(x => new ReturnSearchResult
            {
                SaleItemId = x.SaleItemId,
                InventoryUnitId = x.InventoryUnitId,
                UnitCode = x.UnitCode,
                ProductName = x.ProductName,
                ProductCode = x.InventoryUnit!.Product!.ProductCode,
                OriginalSalePrice = x.SalePrice,
                PurchasePrice = x.PurchasePrice,
                SaleDate = x.Sale!.SaleDate,
                InvoiceNumber = x.Sale.InvoiceNumber,
                Status = x.InventoryUnit.Status
            })
            .Take(100)
            .ToList();
    }

    public void CompleteReturn(
        ReturnSearchResult item,
        string returnedBy,
        string reason)
    {
        if (item == null)
            throw new ArgumentNullException(nameof(item));

        using var db = new ShopDbContext();
        using var transaction = db.Database.BeginTransaction();

        var unit = db.InventoryUnits
            .SingleOrDefault(x => x.InventoryUnitId == item.InventoryUnitId);

        if (unit == null)
            throw new InvalidOperationException("The inventory unit no longer exists.");

        if (!string.Equals(unit.Status, "Sold", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException(
                $"This unit is currently {unit.Status}. Only sold units can be returned.");

        if (db.ProductReturns.Any(x => x.InventoryUnitId == unit.InventoryUnitId))
            throw new InvalidOperationException(
                "This exact physical unit has already been returned.");

        var saleItem = db.SaleItems
            .SingleOrDefault(x =>
                x.SaleItemId == item.SaleItemId &&
                x.InventoryUnitId == item.InventoryUnitId);

        if (saleItem == null)
            throw new InvalidOperationException(
                "The original sale record for this unit could not be found.");

        // Return the exact physical unit to available stock.
        unit.Status = "InStock";

        // Preserve the original customer sale price. This is important for
        // audit/profit calculations and future exchange handling.
        db.ProductReturns.Add(new ProductReturn
        {
            SaleItemId = saleItem.SaleItemId,
            InventoryUnitId = unit.InventoryUnitId,
            UnitCode = unit.UnitCode,
            OriginalSalePrice = saleItem.SalePrice,
            ReturnDate = DateTime.Now,
            ReturnedBy = string.IsNullOrWhiteSpace(returnedBy) ? "Staff" : returnedBy,
            Reason = string.IsNullOrWhiteSpace(reason) ? "Customer return" : reason.Trim()
        });

        db.SaveChanges();
        transaction.Commit();
    }
}
