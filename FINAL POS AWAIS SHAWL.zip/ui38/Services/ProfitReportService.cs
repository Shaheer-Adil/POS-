using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;

namespace ShopManagementSystem.Services;

public class ProfitReportRow
{
    public DateTime Date { get; set; }
    public decimal StockEnteredValue { get; set; }
    public int StockEnteredItems { get; set; }
    public decimal SoldStockValue { get; set; }
    public int ItemsSold { get; set; }
    public decimal Sales { get; set; }
    public decimal Cost { get; set; }
    public decimal GrossProfit { get; set; }
    public decimal Returns { get; set; }
    public decimal ExchangeProfit { get; set; }
    public decimal Expenses { get; set; }
    public decimal NetProfit { get; set; }
    public decimal Revenue { get; set; }
    public decimal CostOfGoods { get; set; }
    public decimal CommissionExpense { get; set; }
    public decimal FixedSalaryExpense { get; set; }
    public decimal OtherExpenses { get; set; }
}

public class ProfitReportSummary
{
    public string PeriodName { get; set; } = string.Empty;
    public DateTime StartDate { get; set; }
    public DateTime EndDate { get; set; }

    public decimal Sales { get; set; }
    public decimal Cost { get; set; }
    public decimal GrossProfit { get; set; }
    public decimal ReturnedSales { get; set; }
    public decimal ReturnProfitAdjustment { get; set; }
    public decimal ExchangeProfit { get; set; }
    public decimal Expenses { get; set; }
    public decimal NetProfit { get; set; }

    // Step 22 integrated financial components.
    public decimal Revenue { get; set; }
    public decimal CostOfGoods { get; set; }
    public decimal CommissionExpense { get; set; }
    public decimal FixedSalaryExpense { get; set; }
    public decimal OtherExpenses { get; set; }
    public decimal ManualSalaryExpenses { get; set; }
    public decimal TotalPayrollExpense { get; set; }
    public decimal TotalOperatingExpenses { get; set; }

    public int ItemsSold { get; set; }
    public int ItemsReturned { get; set; }
    public int Exchanges { get; set; }

    // Inventory movement information for the selected period.
    public int StockEnteredItems { get; set; }
    public decimal StockEnteredValue { get; set; }
    public int SoldStockItems { get; set; }
    public decimal SoldStockValue { get; set; }

    // Current unsold inventory snapshot.
    public int CurrentStockItems { get; set; }
    public decimal CurrentStockPurchaseValue { get; set; }
    public decimal CurrentStockSaleValue { get; set; }
}

public class ProfitReportService
{
    public ProfitReportSummary GetSummary(DateTime startDate, DateTime endDate, string periodName)
    {
        if (endDate < startDate)
            throw new ArgumentException("End date cannot be earlier than start date.");

        var start = startDate.Date;
        var endExclusive = endDate.Date.AddDays(1);

        using var db = new ShopDbContext();

        var saleItems = db.SaleItems
            .AsNoTracking()
            .Include(x => x.Sale)
            .Where(x => x.Sale!.SaleDate >= start && x.Sale.SaleDate < endExclusive)
            .ToList();

        var returns = db.ProductReturns
            .AsNoTracking()
            .Include(x => x.SaleItem)
            .Where(x => x.ReturnDate >= start && x.ReturnDate < endExclusive)
            .ToList();

        var exchanges = db.ProductExchanges
            .AsNoTracking()
            .Where(x => x.ExchangeDate >= start && x.ExchangeDate < endExclusive)
            .ToList();

        // Inventory entered during the selected period.
        var enteredUnits = db.InventoryUnits
            .AsNoTracking()
            .Where(x => x.AddedAt >= start && x.AddedAt < endExclusive)
            .ToList();

        // Current stock snapshot: only units that are still available in inventory.
        var currentStock = db.InventoryUnits
            .AsNoTracking()
            .Where(x => x.Status == "InStock")
            .ToList();

        var expenseRows = db.Expenses
            .AsNoTracking()
            .Where(x => x.ExpenseDate >= start && x.ExpenseDate < endExclusive)
            .ToList();

        var sales = saleItems.Sum(x => x.SalePrice);
        var cost = saleItems.Sum(x => x.PurchasePrice);

        var returnedSales = returns.Sum(x => x.OriginalSalePrice);
        var returnedCost = returns.Sum(x => x.SaleItem?.PurchasePrice ?? 0m);
        var returnProfitAdjustment = returnedSales - returnedCost;

        // Step 22: revenue and COGS are presented separately so returned items
        // do not remain mixed with ordinary sales.
        var revenue = sales - returnedSales;
        var costOfGoods = cost - returnedCost;
        var grossProfit = revenue - costOfGoods;

        var replacementIds = exchanges
            .Select(x => x.ReplacementInventoryUnitId)
            .Distinct()
            .ToArray();

        var originalIds = exchanges
            .Select(x => x.OriginalSaleItemId)
            .Distinct()
            .ToArray();

        var originalSaleItems = db.SaleItems
            .AsNoTracking()
            .Where(x => originalIds.Contains(x.SaleItemId))
            .ToDictionary(x => x.SaleItemId);

        var replacementCosts = db.InventoryUnits
            .AsNoTracking()
            .Where(x => replacementIds.Contains(x.InventoryUnitId))
            .ToDictionary(x => x.InventoryUnitId, x => x.PurchasePrice);

        var exchangeProfit = 0m;
        foreach (var exchange in exchanges)
        {
            var originalProfit = originalSaleItems.TryGetValue(exchange.OriginalSaleItemId, out var originalItem)
                ? originalItem.SalePrice - originalItem.PurchasePrice
                : exchange.OriginalSalePrice;

            var replacementCost = replacementCosts.TryGetValue(
                exchange.ReplacementInventoryUnitId, out var costValue)
                ? costValue
                : 0m;

            exchangeProfit +=
                (exchange.ReplacementSalePrice - replacementCost) - originalProfit;
        }

        // Step 22 payroll integration. Fixed salaries are accrued proportionally
        // for the selected period; commissions come directly from completed sales.
        var commissionExpense = saleItems.Sum(x => x.CommissionAmount);
        var returnedCommission = returns.Sum(x => x.SaleItem?.CommissionAmount ?? 0m);
        commissionExpense = Math.Max(0m, commissionExpense - returnedCommission);
        var fixedSalaryExpense = GetProratedFixedSalaryExpense(db, start, endExclusive);

        // "Staff Salaries" in the old Expenses screen is retained for historical
        // visibility, but is not added again because StaffSalary + Commission are
        // now the authoritative payroll sources. This prevents double counting.
        var manualSalaryExpenses = expenseRows
            .Where(x => x.Category == "Staff Salaries")
            .Sum(x => x.Amount);

        var otherExpenses = expenseRows
            .Where(x => x.Category != "Staff Salaries")
            .Sum(x => x.Amount);

        var totalPayrollExpense = fixedSalaryExpense + commissionExpense;
        var totalOperatingExpenses = totalPayrollExpense + otherExpenses;
        var netProfit = grossProfit + exchangeProfit - totalOperatingExpenses;

        return new ProfitReportSummary
        {
            PeriodName = periodName,
            StartDate = start,
            EndDate = endDate.Date,

            Sales = sales,
            Cost = cost,
            GrossProfit = grossProfit,
            ReturnedSales = returnedSales,
            ReturnProfitAdjustment = returnProfitAdjustment,
            ExchangeProfit = exchangeProfit,
            Expenses = otherExpenses,
            NetProfit = netProfit,

            Revenue = revenue,
            CostOfGoods = costOfGoods,
            CommissionExpense = commissionExpense,
            FixedSalaryExpense = fixedSalaryExpense,
            OtherExpenses = otherExpenses,
            ManualSalaryExpenses = manualSalaryExpenses,
            TotalPayrollExpense = totalPayrollExpense,
            TotalOperatingExpenses = totalOperatingExpenses,

            ItemsSold = saleItems.Count,
            ItemsReturned = returns.Count,
            Exchanges = exchanges.Count,

            StockEnteredItems = enteredUnits.Count,
            StockEnteredValue = enteredUnits.Sum(x => x.PurchasePrice),

            SoldStockItems = saleItems.Count,
            SoldStockValue = saleItems.Sum(x => x.SalePrice),

            CurrentStockItems = currentStock.Count,
            CurrentStockPurchaseValue = currentStock.Sum(x => x.PurchasePrice),
            CurrentStockSaleValue = currentStock.Sum(x => x.SalePrice)
        };
    }

    private static decimal GetProratedFixedSalaryExpense(ShopDbContext db, DateTime start, DateTime endExclusive)
    {
        var salaries = db.StaffSalaries.AsNoTracking().ToList();
        if (salaries.Count == 0)
            return 0m;

        var total = 0m;
        var cursor = new DateTime(start.Year, start.Month, 1);
        var lastMonth = new DateTime(endExclusive.AddDays(-1).Year, endExclusive.AddDays(-1).Month, 1);

        while (cursor <= lastMonth)
        {
            var next = cursor.AddMonths(1);
            var overlapStart = start > cursor ? start : cursor;
            var overlapEnd = endExclusive < next ? endExclusive : next;
            var days = (overlapEnd - overlapStart).Days;
            if (days > 0)
            {
                var daysInMonth = DateTime.DaysInMonth(cursor.Year, cursor.Month);
                var monthlyTotal = salaries.Sum(x => x.MonthlySalary);
                total += monthlyTotal * days / daysInMonth;
            }
            cursor = next;
        }

        return total;
    }

    public List<ProfitReportRow> GetDailyBreakdown(DateTime startDate, DateTime endDate)
    {
        var rows = new List<ProfitReportRow>();

        for (var day = startDate.Date; day <= endDate.Date; day = day.AddDays(1))
        {
            var summary = GetSummary(day, day, day.ToString("dd-MMM-yyyy"));

            rows.Add(new ProfitReportRow
            {
                Date = day,

                StockEnteredValue = summary.StockEnteredValue,
                StockEnteredItems = summary.StockEnteredItems,

                SoldStockValue = summary.SoldStockValue,
                ItemsSold = summary.ItemsSold,

                Sales = summary.Sales,
                Cost = summary.Cost,
                GrossProfit = summary.GrossProfit,
                Returns = summary.ReturnedSales,
                ExchangeProfit = summary.ExchangeProfit,
                Expenses = summary.Expenses,
                NetProfit = summary.NetProfit,
                Revenue = summary.Revenue,
                CostOfGoods = summary.CostOfGoods,
                CommissionExpense = summary.CommissionExpense,
                FixedSalaryExpense = summary.FixedSalaryExpense,
                OtherExpenses = summary.OtherExpenses
            });
        }

        return rows;
    }
}
