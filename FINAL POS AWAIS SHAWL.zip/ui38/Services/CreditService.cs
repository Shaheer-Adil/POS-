using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Services;

public class CreditCustomerSummary
{
    public int CreditAccountId { get; set; }
    public string CustomerName { get; set; } = string.Empty;
    public string PhoneNumber { get; set; } = string.Empty;
    public decimal TotalCredit { get; set; }
    public decimal TotalPaid { get; set; }
    public decimal Outstanding { get; set; }
}

public class CreditHistoryItem
{
    public DateTime Date { get; set; }
    public string Type { get; set; } = string.Empty;
    public string InvoiceNumber { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public decimal BalanceAfter { get; set; }
    public string Notes { get; set; } = string.Empty;
}

public class CreditService
{
    public List<CreditCustomerSummary> SearchCustomers(string text = "")
    {
        using var db = new ShopDbContext();
        var query = db.CreditAccounts.AsNoTracking().AsQueryable();
        text = text?.Trim() ?? "";
        if (!string.IsNullOrWhiteSpace(text))
            query = query.Where(x => x.CustomerName.Contains(text) || x.PhoneNumber.Contains(text));

        return query.OrderBy(x => x.CustomerName).Select(x => new CreditCustomerSummary
        {
            CreditAccountId = x.CreditAccountId,
            CustomerName = x.CustomerName,
            PhoneNumber = x.PhoneNumber,
            TotalCredit = x.Transactions.Where(t => t.TransactionType == "CreditSale").Sum(t => (decimal?)t.Amount) ?? 0,
            TotalPaid = x.Transactions.Where(t => t.TransactionType == "Payment").Sum(t => (decimal?)t.Amount) ?? 0
        }).AsEnumerable().Select(x => { x.Outstanding = Math.Max(0, x.TotalCredit - x.TotalPaid); return x; }).ToList();
    }

    public CreditCustomerSummary GetCustomer(int accountId)
    {
        var item = SearchCustomers().SingleOrDefault(x => x.CreditAccountId == accountId);
        return item ?? throw new InvalidOperationException("Customer credit account was not found.");
    }

    public List<CreditHistoryItem> GetHistory(int accountId)
    {
        using var db = new ShopDbContext();
        var rows = db.CreditTransactions.AsNoTracking()
            .Where(x => x.CreditAccountId == accountId)
            .OrderBy(x => x.TransactionDate).ThenBy(x => x.CreditTransactionId)
            .ToList();

        decimal balance = 0;
        var result = new List<CreditHistoryItem>();
        foreach (var row in rows)
        {
            if (row.TransactionType == "CreditSale") balance += row.Amount;
            else if (row.TransactionType == "Payment") balance -= row.Amount;
            result.Add(new CreditHistoryItem
            {
                Date = row.TransactionDate,
                Type = row.TransactionType == "CreditSale" ? "Credit Sale" : "Payment",
                InvoiceNumber = row.InvoiceNumber,
                Amount = row.Amount,
                BalanceAfter = Math.Max(0, balance),
                Notes = row.Notes
            });
        }
        return result.OrderByDescending(x => x.Date).ToList();
    }

    public void DeleteAccount(int accountId)
    {
        using var db = new ShopDbContext();
        using var tx = db.Database.BeginTransaction();

        var account = db.CreditAccounts.SingleOrDefault(x => x.CreditAccountId == accountId)
            ?? throw new InvalidOperationException("Customer credit account was not found.");

        var transactions = db.CreditTransactions
            .Where(x => x.CreditAccountId == accountId)
            .ToList();

        if (transactions.Count > 0)
            db.CreditTransactions.RemoveRange(transactions);

        db.CreditAccounts.Remove(account);
        db.SaveChanges();
        tx.Commit();
    }

    public CreditCustomerSummary RecordPayment(int accountId, decimal amount, string notes, string receivedBy)
    {
        if (amount <= 0) throw new InvalidOperationException("Payment amount must be greater than zero.");
        using var db = new ShopDbContext();
        using var tx = db.Database.BeginTransaction();
        var account = db.CreditAccounts.SingleOrDefault(x => x.CreditAccountId == accountId)
            ?? throw new InvalidOperationException("Customer credit account was not found.");
        var outstanding = db.CreditTransactions.Where(x => x.CreditAccountId == accountId)
            .Sum(x => x.TransactionType == "CreditSale" ? x.Amount : -x.Amount);
        if (amount > outstanding)
            throw new InvalidOperationException($"Payment cannot exceed the outstanding balance of Rs. {outstanding:#,##0.##}.");
        db.CreditTransactions.Add(new CreditTransaction
        {
            CreditAccountId = account.CreditAccountId,
            TransactionType = "Payment",
            Amount = amount,
            TransactionDate = DateTime.Now,
            InvoiceNumber = $"PAY-{DateTime.Now:yyyyMMddHHmmssfff}",
            Notes = string.IsNullOrWhiteSpace(notes) ? $"Payment received by {receivedBy}" : notes.Trim()
        });
        db.SaveChanges();
        tx.Commit();
        return GetCustomer(accountId);
    }

    public void RecordCreditSale(int saleId, string customerName, string phoneNumber, decimal totalAmount, decimal amountPaid, string invoiceNumber, string soldBy)
    {
        if (string.IsNullOrWhiteSpace(customerName)) throw new InvalidOperationException("Customer name is required for a credit sale.");
        if (amountPaid < 0 || amountPaid > totalAmount) throw new InvalidOperationException("Initial payment must be between Rs. 0 and the total bill.");
        var outstanding = totalAmount - amountPaid;
        if (outstanding <= 0) return;

        using var db = new ShopDbContext();
        using var tx = db.Database.BeginTransaction();
        var normalizedPhone = phoneNumber?.Trim() ?? "";
        var account = !string.IsNullOrWhiteSpace(normalizedPhone)
            ? db.CreditAccounts.FirstOrDefault(x => x.PhoneNumber == normalizedPhone)
            : null;
        if (account == null)
        {
            account = new CreditAccount { CustomerName = customerName.Trim(), PhoneNumber = normalizedPhone, CreatedAt = DateTime.Now };
            db.CreditAccounts.Add(account);
            db.SaveChanges();
        }
        else
        {
            account.CustomerName = customerName.Trim();
        }

        db.CreditTransactions.Add(new CreditTransaction
        {
            CreditAccountId = account.CreditAccountId,
            SaleId = saleId,
            TransactionType = "CreditSale",
            Amount = totalAmount,
            TransactionDate = DateTime.Now,
            InvoiceNumber = invoiceNumber,
            Notes = $"Credit sale recorded by {soldBy}"
        });
        if (amountPaid > 0)
        {
            db.CreditTransactions.Add(new CreditTransaction
            {
                CreditAccountId = account.CreditAccountId,
                SaleId = saleId,
                TransactionType = "Payment",
                Amount = amountPaid,
                TransactionDate = DateTime.Now,
                InvoiceNumber = invoiceNumber,
                Notes = $"Initial payment received by {soldBy}"
            });
        }
        db.SaveChanges();
        tx.Commit();
    }
}
