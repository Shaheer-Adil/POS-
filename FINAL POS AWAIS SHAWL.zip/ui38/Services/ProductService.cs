using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Services;

public class ProductService
{
    public ProductBatchResult AddProduct(string name, string category, int quantity,
        decimal purchasePrice, decimal salePrice)
    {
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Product name is required.");
        if (quantity <= 0)
            throw new ArgumentException("Quantity must be greater than zero.");
        if (purchasePrice < 0)
            throw new ArgumentException("Purchase price cannot be negative.");
        if (salePrice < purchasePrice)
            throw new ArgumentException("Sale price cannot be lower than purchase price.");

        using var db = new ShopDbContext();
        using var transaction = db.Database.BeginTransaction();

        var productCode = GenerateProductCode(db);
        var product = new Product
        {
            ProductCode = productCode,
            ProductName = name.Trim(),
            Category = category.Trim(),
            PurchasePrice = purchasePrice,
            SalePrice = salePrice,
            Quantity = quantity,
            CreatedAt = DateTime.Now
        };

        db.Products.Add(product);
        db.SaveChanges();

        var tags = new System.Collections.Generic.List<InventoryTag>();
        for (var i = 1; i <= quantity; i++)
        {
            var unit = new InventoryUnit
            {
                ProductId = product.ProductId,
                UnitCode = GenerateUnitCode(product.ProductId, i),
                PurchasePrice = purchasePrice,
                SalePrice = salePrice,
                Status = "InStock",
                AddedAt = DateTime.Now
            };
            db.InventoryUnits.Add(unit);
            tags.Add(new InventoryTag
            {
                UnitCode = unit.UnitCode,
                ProductCode = productCode,
                ProductName = product.ProductName,
                Category = product.Category,
                SalePrice = product.SalePrice
            });
        }

        db.SaveChanges();
        transaction.Commit();

        return new ProductBatchResult
        {
            ProductId = product.ProductId,
            ProductCode = productCode,
            ProductName = product.ProductName,
            Quantity = quantity,
            Tags = tags.ToArray()
        };
    }

    public Product[] GetProducts(string? search = null)
    {
        using var db = new ShopDbContext();
        var query = db.Products.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(x =>
                x.ProductName.Contains(term) ||
                x.ProductCode.Contains(term) ||
                x.Category.Contains(term));
        }

        return query.OrderByDescending(x => x.ProductId).ToArray();
    }

    public InventoryRow[] GetInventory(string? search = null)
    {
        using var db = new ShopDbContext();
        var query = db.InventoryUnits
            .AsNoTracking()
            .Include(x => x.Product)
            .OrderByDescending(x => x.InventoryUnitId)
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(x =>
                x.UnitCode.Contains(term) ||
                (x.Product != null && (
                    x.Product.ProductName.Contains(term) ||
                    x.Product.ProductCode.Contains(term))));
        }

        return query.Select(x => new InventoryRow
        {
            UnitCode = x.UnitCode,
            ProductCode = x.Product!.ProductCode,
            ProductName = x.Product.ProductName,
            Category = x.Product.Category,
            PurchasePrice = x.PurchasePrice,
            SalePrice = x.SalePrice,
            Status = x.Status,
            AddedAt = x.AddedAt
        }).ToArray();
    }


    public InventoryGroupRow[] GetInventoryGroups(string? search = null)
    {
        using var db = new ShopDbContext();

        var query = db.InventoryUnits
            .AsNoTracking()
            .Include(x => x.Product)
            .Where(x => x.Product != null && x.Status != "Deleted")
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(x =>
                x.UnitCode.Contains(term) ||
                x.Product!.ProductName.Contains(term) ||
                x.Product.ProductCode.Contains(term) ||
                x.Product.Category.Contains(term));
        }

        var units = query
            .OrderBy(x => x.Product!.ProductName)
            .ThenBy(x => x.UnitCode)
            .Select(x => new InventoryUnitSnapshot
            {
                InventoryUnitId = x.InventoryUnitId,
                ProductId = x.ProductId,
                UnitCode = x.UnitCode,
                ProductCode = x.Product!.ProductCode,
                ProductName = x.Product.ProductName,
                Category = x.Product.Category,
                PurchasePrice = x.PurchasePrice,
                SalePrice = x.SalePrice,
                Status = x.Status,
                AddedAt = x.AddedAt
            })
            .ToList();

        return units
            .GroupBy(x => new { x.ProductName, x.Category })
            .OrderBy(g => g.Key.ProductName)
            .Select(g =>
            {
                var items = g.OrderBy(x => x.UnitCode).ToArray();
                var inStock = items.Count(x =>
                    string.Equals(x.Status, "InStock", StringComparison.OrdinalIgnoreCase));
                var distinctCodes = items.Select(x => x.ProductCode).Distinct().ToArray();

                return new InventoryGroupRow
                {
                    ProductId = items.Length > 0 ? items[0].ProductId : 0,
                    ProductCode = distinctCodes.Length == 1 ? distinctCodes[0] : "Multiple",
                    ProductName = g.Key.ProductName,
                    Category = g.Key.Category,
                    Quantity = inStock,
                    TotalUnits = items.Length,
                    PurchasePrice = items.Length > 0 && items.All(x => x.PurchasePrice == items[0].PurchasePrice)
                        ? items[0].PurchasePrice
                        : null,
                    SalePrice = items.Length > 0 && items.All(x => x.SalePrice == items[0].SalePrice)
                        ? items[0].SalePrice
                        : null,
                    Status = inStock > 0 ? "In Stock" : "Out of Stock",
                    Units = items.Select(x => new InventoryDetailRow
                    {
                        InventoryUnitId = x.InventoryUnitId,
                        UnitCode = x.UnitCode,
                        ProductCode = x.ProductCode,
                        ProductName = x.ProductName,
                        Category = x.Category,
                        PurchasePrice = x.PurchasePrice,
                        SalePrice = x.SalePrice,
                        Status = x.Status,
                        AddedAt = x.AddedAt
                    }).ToArray()
                };
            })
            .ToArray();
    }

    public void DeleteInventoryUnit(int inventoryUnitId)
    {
        using var db = new ShopDbContext();
        var unit = db.InventoryUnits.SingleOrDefault(x => x.InventoryUnitId == inventoryUnitId);

        if (unit == null)
            throw new InvalidOperationException("The selected inventory item no longer exists.");

        if (!string.Equals(unit.Status, "InStock", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException(
                $"Only an in-stock inventory item can be deleted. This item is currently {unit.Status}.");

        unit.Status = "Deleted";
        db.SaveChanges();
    }

    public int DeleteInventoryGroup(int productId)
    {
        using var db = new ShopDbContext();
        var units = db.InventoryUnits
            .Where(x => x.ProductId == productId && x.Status == "InStock")
            .ToList();

        if (units.Count == 0)
            throw new InvalidOperationException("There are no in-stock units available to delete for this product.");

        foreach (var unit in units)
            unit.Status = "Deleted";

        db.SaveChanges();
        return units.Count;
    }

    public InventoryGroupRow[] GetRecentlyDeletedGroups(string? search = null)
    {
        using var db = new ShopDbContext();

        var query = db.InventoryUnits
            .AsNoTracking()
            .Include(x => x.Product)
            .Where(x => x.Product != null && x.Status == "Deleted")
            .AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            var term = search.Trim();
            query = query.Where(x =>
                x.UnitCode.Contains(term) ||
                x.Product!.ProductName.Contains(term) ||
                x.Product.ProductCode.Contains(term) ||
                x.Product.Category.Contains(term));
        }

        var units = query
            .OrderBy(x => x.Product!.ProductName)
            .ThenBy(x => x.UnitCode)
            .Select(x => new InventoryUnitSnapshot
            {
                InventoryUnitId = x.InventoryUnitId,
                ProductId = x.ProductId,
                UnitCode = x.UnitCode,
                ProductCode = x.Product!.ProductCode,
                ProductName = x.Product.ProductName,
                Category = x.Product.Category,
                PurchasePrice = x.PurchasePrice,
                SalePrice = x.SalePrice,
                Status = x.Status,
                AddedAt = x.AddedAt
            })
            .ToList();

        return units
            .GroupBy(x => new { x.ProductId, x.ProductName, x.Category })
            .OrderBy(g => g.Key.ProductName)
            .Select(g =>
            {
                var items = g.OrderBy(x => x.UnitCode).ToArray();
                var distinctCodes = items.Select(x => x.ProductCode).Distinct().ToArray();

                return new InventoryGroupRow
                {
                    ProductId = g.Key.ProductId,
                    ProductCode = distinctCodes.Length == 1 ? distinctCodes[0] : "Multiple",
                    ProductName = g.Key.ProductName,
                    Category = g.Key.Category,
                    Quantity = items.Length,
                    TotalUnits = items.Length,
                    PurchasePrice = items.All(x => x.PurchasePrice == items[0].PurchasePrice)
                        ? items[0].PurchasePrice
                        : null,
                    SalePrice = items.All(x => x.SalePrice == items[0].SalePrice)
                        ? items[0].SalePrice
                        : null,
                    Status = "Recently Deleted",
                    Units = items.Select(x => new InventoryDetailRow
                    {
                        InventoryUnitId = x.InventoryUnitId,
                        UnitCode = x.UnitCode,
                        ProductCode = x.ProductCode,
                        ProductName = x.ProductName,
                        Category = x.Category,
                        PurchasePrice = x.PurchasePrice,
                        SalePrice = x.SalePrice,
                        Status = x.Status,
                        AddedAt = x.AddedAt
                    }).ToArray()
                };
            })
            .ToArray();
    }

    public void RestoreInventoryUnit(int inventoryUnitId)
    {
        using var db = new ShopDbContext();
        var unit = db.InventoryUnits.SingleOrDefault(x => x.InventoryUnitId == inventoryUnitId);

        if (unit == null)
            throw new InvalidOperationException("The selected deleted item no longer exists.");

        if (!string.Equals(unit.Status, "Deleted", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException("The selected item is not in Recently Deleted.");

        unit.Status = "InStock";
        db.SaveChanges();
    }

    public int RestoreInventoryGroup(int productId)
    {
        using var db = new ShopDbContext();
        var units = db.InventoryUnits
            .Where(x => x.ProductId == productId && x.Status == "Deleted")
            .ToList();

        if (units.Count == 0)
            throw new InvalidOperationException("There are no deleted units available to recover for this product.");

        foreach (var unit in units)
            unit.Status = "InStock";

        db.SaveChanges();
        return units.Count;
    }

    public InventoryTag? GetTag(string unitCode)
    {
        using var db = new ShopDbContext();
        return db.InventoryUnits
            .AsNoTracking()
            .Include(x => x.Product)
            .Where(x => x.UnitCode == unitCode)
            .Select(x => new InventoryTag
            {
                UnitCode = x.UnitCode,
                ProductCode = x.Product!.ProductCode,
                ProductName = x.Product.ProductName,
                Category = x.Product.Category,
                SalePrice = x.SalePrice
            })
            .SingleOrDefault();
    }

    private static string GenerateProductCode(ShopDbContext db)
    {
        var next = (db.Products.Max(x => (int?)x.ProductId) ?? 0) + 1;
        return $"PRD-{next:000000}";
    }

    private static string GenerateUnitCode(int productId, int sequence)
        => $"UNIT-{productId:000000}-{sequence:0000}";
}

public class ProductBatchResult
{
    public int ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public InventoryTag[] Tags { get; set; } = Array.Empty<InventoryTag>();
}

public class InventoryGroupRow
{
    public int ProductId { get; set; }
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public int TotalUnits { get; set; }
    public decimal? PurchasePrice { get; set; }
    public decimal? SalePrice { get; set; }
    public string Status { get; set; } = string.Empty;
    public InventoryDetailRow[] Units { get; set; } = Array.Empty<InventoryDetailRow>();
    public bool Expanded { get; set; }
}

public class InventoryDetailRow
{
    public int InventoryUnitId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public decimal PurchasePrice { get; set; }
    public decimal SalePrice { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime AddedAt { get; set; }
}

internal class InventoryUnitSnapshot
{
    public int InventoryUnitId { get; set; }
    public int ProductId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public decimal PurchasePrice { get; set; }
    public decimal SalePrice { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime AddedAt { get; set; }
}

public class InventoryTag
{
    public string UnitCode { get; set; } = string.Empty;
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public decimal SalePrice { get; set; }
}

public class InventoryRow
{
    public string UnitCode { get; set; } = string.Empty;
    public string ProductCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string Category { get; set; } = string.Empty;
    public decimal PurchasePrice { get; set; }
    public decimal SalePrice { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime AddedAt { get; set; }
}
