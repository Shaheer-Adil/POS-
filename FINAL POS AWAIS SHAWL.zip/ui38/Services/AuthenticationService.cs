using System.Linq;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Services;

public class AuthenticationService
{
    public User? Authenticate(string username, string password)
    {
        using var db = new ShopDbContext();

        var user = db.Users.SingleOrDefault(
            x => x.Username == username && x.IsActive);

        if (user == null)
            return null;

        return BCrypt.Net.BCrypt.Verify(password, user.PasswordHash)
            ? user
            : null;
    }
}
