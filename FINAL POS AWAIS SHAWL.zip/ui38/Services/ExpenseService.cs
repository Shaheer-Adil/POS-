using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Services;

public class ExpenseSummary
{
    public decimal StaffSalaries { get; set; }
    public decimal Electricity { get; set; }
    public decimal Other { get; set; }
    public decimal Total => StaffSalaries + Electricity + Other;
}

public class ExpenseRecord
{
    public int ExpenseId { get; set; }
    public DateTime ExpenseDate { get; set; }
    public string Category { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Description { get; set; } = string.Empty;
    public string RecordedBy { get; set; } = string.Empty;
}

public class ExpenseService
{
    public void AddExpense(string category, decimal amount, DateTime date, string description, string recordedBy)
    {
        category = (category ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(category))
            throw new ArgumentException("Expense category is required.");

        if (amount <= 0)
            throw new ArgumentException("Expense amount must be greater than zero.");

        using var db = new ShopDbContext();
        db.Expenses.Add(new Expense
        {
            Category = category,
            Amount = amount,
            ExpenseDate = date,
            Description = (description ?? string.Empty).Trim(),
            RecordedBy = string.IsNullOrWhiteSpace(recordedBy) ? "Admin" : recordedBy.Trim()
        });
        db.SaveChanges();
    }

    public ExpenseSummary GetSummary(DateTime startDate, DateTime endDate)
    {
        var start = startDate.Date;
        var endExclusive = endDate.Date.AddDays(1);

        using var db = new ShopDbContext();
        var expenses = db.Expenses.AsNoTracking()
            .Where(x => x.ExpenseDate >= start && x.ExpenseDate < endExclusive)
            .ToList();

        return new ExpenseSummary
        {
            StaffSalaries = expenses.Where(x => x.Category == "Staff Salaries").Sum(x => x.Amount),
            Electricity = expenses.Where(x => x.Category == "Electricity Bill").Sum(x => x.Amount),
            Other = expenses
                .Where(x => x.Category != "Staff Salaries" && x.Category != "Electricity Bill")
                .Sum(x => x.Amount)
        };
    }

    public List<ExpenseRecord> GetRecords(DateTime startDate, DateTime endDate)
    {
        var start = startDate.Date;
        var endExclusive = endDate.Date.AddDays(1);

        using var db = new ShopDbContext();
        return db.Expenses.AsNoTracking()
            .Where(x => x.ExpenseDate >= start && x.ExpenseDate < endExclusive)
            .OrderByDescending(x => x.ExpenseDate)
            .Select(x => new ExpenseRecord
            {
                ExpenseId = x.ExpenseId,
                ExpenseDate = x.ExpenseDate,
                Category = x.Category,
                Amount = x.Amount,
                Description = x.Description,
                RecordedBy = x.RecordedBy
            })
            .ToList();
    }

    public bool DeleteExpense(int expenseId)
    {
        using var db = new ShopDbContext();
        var expense = db.Expenses.Find(expenseId);
        if (expense == null) return false;

        db.Expenses.Remove(expense);
        db.SaveChanges();
        return true;
    }
}
