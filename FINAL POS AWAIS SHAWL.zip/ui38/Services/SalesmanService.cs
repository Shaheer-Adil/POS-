using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Services;

public class SalesmanSaleInfo
{
    public int SalesmanId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
}

public class SalesmanService
{
    public string GenerateNextCode()
    {
        using var db = new ShopDbContext();
        var used = db.Salesmen.AsNoTracking().Select(x => x.Code).ToList()
            .Select(x => int.TryParse(x, out var n) ? n : 0)
            .Where(n => n >= 1 && n <= 999).ToHashSet();

        for (var n = 1; n <= 999; n++)
            if (!used.Contains(n)) return n.ToString("D3");

        throw new InvalidOperationException("All 999 three-digit salesman codes are already in use.");
    }

    public Salesman AddSalesman(string name)
    {
        name = (name ?? "").Trim();
        if (string.IsNullOrWhiteSpace(name))
            throw new ArgumentException("Salesman name is required.");

        using var db = new ShopDbContext();
        var salesman = new Salesman
        {
            Name = name,
            Code = GenerateNextCode(),
            IsActive = true,
            CreatedAt = DateTime.Now
        };
        db.Salesmen.Add(salesman);
        db.SaveChanges();
        return salesman;
    }

    public SalesmanSaleInfo? FindActiveByCode(string code)
    {
        code = (code ?? "").Trim();
        if (string.IsNullOrWhiteSpace(code)) return null;
        using var db = new ShopDbContext();
        return db.Salesmen.AsNoTracking()
            .Where(x => x.Code == code && x.IsActive)
            .Select(x => new SalesmanSaleInfo { SalesmanId = x.SalesmanId, Name = x.Name, Code = x.Code })
            .SingleOrDefault();
    }

    public Dictionary<int, decimal> GetCommissionPercentages(int salesmanId, IEnumerable<int> productIds)
    {
        var ids = productIds.Distinct().ToArray();
        if (ids.Length == 0) return new Dictionary<int, decimal>();
        using var db = new ShopDbContext();
        return db.SalesmanCommissions.AsNoTracking()
            .Where(x => x.SalesmanId == salesmanId && ids.Contains(x.ProductId))
            .ToDictionary(x => x.ProductId, x => x.Percentage);
    }

    public void SetCommission(int salesmanId, int productId, decimal percentage)
    {
        if (percentage < 0 || percentage > 100)
            throw new ArgumentException("Commission percentage must be between 0 and 100.");

        using var db = new ShopDbContext();
        if (db.Salesmen.Find(salesmanId) == null) throw new InvalidOperationException("Salesman was not found.");
        if (db.Products.Find(productId) == null) throw new InvalidOperationException("Product was not found.");

        var existing = db.SalesmanCommissions.FirstOrDefault(x => x.SalesmanId == salesmanId && x.ProductId == productId);
        if (existing == null)
        {
            db.SalesmanCommissions.Add(new SalesmanCommission
            {
                SalesmanId = salesmanId, ProductId = productId,
                Percentage = percentage, UpdatedAt = DateTime.Now
            });
        }
        else
        {
            existing.Percentage = percentage;
            existing.UpdatedAt = DateTime.Now;
        }
        db.SaveChanges();
    }


    public void DeleteSalesmanByCode(string code)
    {
        code = (code ?? string.Empty).Trim();
        if (string.IsNullOrWhiteSpace(code))
            throw new ArgumentException("Salesman code is required.");

        using var db = new ShopDbContext();
        var salesman = db.Salesmen.SingleOrDefault(x => x.Code == code);
        if (salesman == null)
            throw new InvalidOperationException("Salesman was not found.");

        db.Salesmen.Remove(salesman);
        db.SaveChanges();
    }

    public void SetSalesmanStatus(int salesmanId, bool active)
    {
        using var db = new ShopDbContext();
        var s = db.Salesmen.Find(salesmanId) ?? throw new InvalidOperationException("Salesman was not found.");
        s.IsActive = active;
        db.SaveChanges();
    }
}
