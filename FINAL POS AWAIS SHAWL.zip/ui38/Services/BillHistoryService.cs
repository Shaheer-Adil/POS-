using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Services;

public class BillHistoryItem
{
    public int SaleId { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public DateTime SaleDate { get; set; }
    public string SoldBy { get; set; } = string.Empty;
    public string SalesmanName { get; set; } = string.Empty;
    public string SalesmanCode { get; set; } = string.Empty;
    public decimal TotalAmount { get; set; }
    public string PaymentType { get; set; } = "Cash";
    public List<SaleCartItem> Items { get; set; } = new();
}

public class BillHistoryService
{
    public List<BillHistoryItem> GetLastThreeBills()
    {
        using var db = new ShopDbContext();

        var sales = db.Sales
            .AsNoTracking()
            .Include(x => x.Items)
            .OrderByDescending(x => x.SaleDate)
            .ThenByDescending(x => x.SaleId)
            .Take(3)
            .ToList();

        var saleIds = sales.Select(x => x.SaleId).ToArray();
        var creditSaleIds = db.CreditTransactions
            .AsNoTracking()
            .Where(x => x.SaleId.HasValue && saleIds.Contains(x.SaleId.Value) && x.TransactionType == "CreditSale")
            .Select(x => x.SaleId!.Value)
            .Distinct()
            .ToHashSet();

        return sales.Select(x => new BillHistoryItem
        {
            SaleId = x.SaleId,
            InvoiceNumber = x.InvoiceNumber,
            SaleDate = x.SaleDate,
            SoldBy = x.SoldBy,
            SalesmanName = x.SalesmanName,
            SalesmanCode = x.SalesmanCode,
            TotalAmount = x.TotalAmount,
            PaymentType = creditSaleIds.Contains(x.SaleId) ? "Credit / Khata" : "Cash",
            Items = x.Items
                .OrderBy(i => i.SaleItemId)
                .Select(i => new SaleCartItem
                {
                    InventoryUnitId = i.InventoryUnitId,
                    ProductId = i.InventoryUnit?.ProductId ?? 0,
                    UnitCode = i.UnitCode,
                    ProductName = i.ProductName,
                    PurchasePrice = i.PurchasePrice,
                    SalePrice = i.SalePrice
                })
                .ToList()
        }).ToList();
    }
}
