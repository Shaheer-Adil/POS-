using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;
namespace ShopManagementSystem.Services;
public class SalarySummary
{
    public int SalesmanId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public decimal MonthlySalary { get; set; }
    public decimal CommissionThisMonth { get; set; }
    public decimal AdvancesThisMonth { get; set; }
    public decimal RemainingSalary => MonthlySalary + CommissionThisMonth - AdvancesThisMonth;
}
public class SalaryAdvanceRecord
{
    public DateTime PaidAt { get; set; }
    public decimal Amount { get; set; }
    public string PaidBy { get; set; } = string.Empty;
    public string Notes { get; set; } = string.Empty;
}

public class SalaryHistoryResult
{
    public decimal MonthlySalary { get; set; }
    public decimal Commission { get; set; }
    public decimal Advances { get; set; }
    public decimal Remaining => MonthlySalary + Commission - Advances;
    public List<SalaryMonthRecord> Months { get; set; } = new();
    public List<SalaryAdvanceRecord> AdvancesList { get; set; } = new();
}

public class SalaryMonthRecord
{
    public DateTime Month { get; set; }
    public decimal Salary { get; set; }
    public decimal Commission { get; set; }
    public decimal Advances { get; set; }
}


public class SalaryPaymentHistoryRow
{
    public string Salesman { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public DateTime PayrollMonth { get; set; }
    public DateTime PaidAt { get; set; }
    public decimal FixedSalary { get; set; }
    public decimal Commission { get; set; }
    public decimal Advances { get; set; }
    public decimal AmountPaid { get; set; }
    public string PaidBy { get; set; } = string.Empty;
}

public class FinalSalarySummary
{
    public int SalesmanId { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Code { get; set; } = string.Empty;
    public decimal FixedSalary { get; set; }
    public decimal Commission { get; set; }
    public decimal Advances { get; set; }
    public decimal FinalPayable => FixedSalary + Commission - Advances;
}

public class SalaryService
{
    public List<SalarySummary> GetCurrentSummaries(DateTime? now = null)
    {
        var current = now ?? DateTime.Now;
        var monthStart = new DateTime(current.Year, current.Month, 1);
        var nextMonth = monthStart.AddMonths(1);
        using var db = new ShopDbContext();
        var salesmen = db.Salesmen.AsNoTracking().OrderBy(x => x.Name).ToList();
        var salaryMap = db.StaffSalaries.AsNoTracking().ToDictionary(x => x.SalesmanId, x => x.MonthlySalary);
        var commissionMap = db.Sales.AsNoTracking()
            .Where(x => x.SalesmanId != null && x.SaleDate >= monthStart && x.SaleDate < nextMonth)
            .GroupBy(x => x.SalesmanId!.Value)
            .Select(g => new { SalesmanId = g.Key, Total = g.Sum(x => x.TotalCommission) })
            .ToDictionary(x => x.SalesmanId, x => x.Total);
        var advanceMap = db.SalaryAdvances.AsNoTracking()
            .Where(x => x.PaidAt >= monthStart && x.PaidAt < nextMonth)
            .GroupBy(x => x.SalesmanId)
            .Select(g => new { SalesmanId = g.Key, Total = g.Sum(x => x.Amount) })
            .ToDictionary(x => x.SalesmanId, x => x.Total);
        return salesmen.Select(s => new SalarySummary
        {
            SalesmanId = s.SalesmanId, Name = s.Name, Code = s.Code,
            MonthlySalary = salaryMap.GetValueOrDefault(s.SalesmanId, 0m),
            CommissionThisMonth = commissionMap.GetValueOrDefault(s.SalesmanId, 0m),
            AdvancesThisMonth = advanceMap.GetValueOrDefault(s.SalesmanId, 0m)
        }).ToList();
    }
    public void SetMonthlySalary(int salesmanId, decimal amount)
    {
        if (amount < 0) throw new ArgumentException("Salary cannot be negative.");
        using var db = new ShopDbContext();
        if (db.Salesmen.Find(salesmanId) == null) throw new InvalidOperationException("Salesman was not found.");
        var salary = db.StaffSalaries.SingleOrDefault(x => x.SalesmanId == salesmanId);
        if (salary == null) db.StaffSalaries.Add(new StaffSalary { SalesmanId = salesmanId, MonthlySalary = amount, UpdatedAt = DateTime.Now });
        else { salary.MonthlySalary = amount; salary.UpdatedAt = DateTime.Now; }
        db.SaveChanges();
    }
    public void AddAdvance(int salesmanId, decimal amount, string paidBy, string notes)
    {
        if (amount <= 0) throw new ArgumentException("Advance amount must be greater than zero.");
        using var db = new ShopDbContext();
        if (db.Salesmen.Find(salesmanId) == null) throw new InvalidOperationException("Salesman was not found.");
        db.SalaryAdvances.Add(new SalaryAdvance { SalesmanId = salesmanId, Amount = amount, PaidAt = DateTime.Now, PaidBy = string.IsNullOrWhiteSpace(paidBy) ? "Admin" : paidBy.Trim(), Notes = (notes ?? string.Empty).Trim() });
        db.SaveChanges();
    }
    public SalarySummary GetCurrentSummary(int salesmanId, DateTime? now = null)
    {
        var summary = GetCurrentSummaries(now).FirstOrDefault(x => x.SalesmanId == salesmanId);
        if (summary == null) throw new InvalidOperationException("Salesman was not found.");
        return summary;
    }

    public void AddAdvance(int salesmanId, decimal amount, string paidBy, string notes, bool validateAgainstRemainingSalary)
    {
        if (amount <= 0) throw new ArgumentException("Advance amount must be greater than zero.");
        using var db = new ShopDbContext();
        if (db.Salesmen.Find(salesmanId) == null) throw new InvalidOperationException("Salesman was not found.");

        if (validateAgainstRemainingSalary)
        {
            var now = DateTime.Now;
            var monthStart = new DateTime(now.Year, now.Month, 1);
            var nextMonth = monthStart.AddMonths(1);
            var salary = db.StaffSalaries.AsNoTracking().SingleOrDefault(x => x.SalesmanId == salesmanId)?.MonthlySalary ?? 0m;
            var commission = db.Sales.AsNoTracking()
                .Where(x => x.SalesmanId == salesmanId && x.SaleDate >= monthStart && x.SaleDate < nextMonth)
                .Sum(x => (decimal?)x.TotalCommission) ?? 0m;
            var advances = db.SalaryAdvances.AsNoTracking()
                .Where(x => x.SalesmanId == salesmanId && x.PaidAt >= monthStart && x.PaidAt < nextMonth)
                .Sum(x => (decimal?)x.Amount) ?? 0m;
            var remaining = salary + commission - advances;
            if (amount > remaining)
                throw new InvalidOperationException($"Advance exceeds the employee's remaining salary. Maximum available: Rs. {remaining:#,##0.##}");
        }

        db.SalaryAdvances.Add(new SalaryAdvance
        {
            SalesmanId = salesmanId,
            Amount = amount,
            PaidAt = DateTime.Now,
            PaidBy = string.IsNullOrWhiteSpace(paidBy) ? "Admin" : paidBy.Trim(),
            Notes = (notes ?? string.Empty).Trim()
        });
        db.SaveChanges();
    }

    public List<SalaryAdvanceRecord> GetAdvanceHistory(int salesmanId)
    {
        using var db = new ShopDbContext();
        return db.SalaryAdvances.AsNoTracking().Where(x => x.SalesmanId == salesmanId).OrderByDescending(x => x.PaidAt)
            .Select(x => new SalaryAdvanceRecord { PaidAt = x.PaidAt, Amount = x.Amount, PaidBy = x.PaidBy, Notes = x.Notes }).ToList();
    }

    public SalaryHistoryResult GetSalaryHistory(int salesmanId, DateTime from, DateTime toExclusive)
    {
        if (toExclusive <= from)
            throw new ArgumentException("The history end date must be after the start date.");

        using var db = new ShopDbContext();
        var salesmanExists = db.Salesmen.AsNoTracking().Any(x => x.SalesmanId == salesmanId);
        if (!salesmanExists)
            throw new InvalidOperationException("Salesman was not found.");

        var salary = db.StaffSalaries.AsNoTracking()
            .Where(x => x.SalesmanId == salesmanId)
            .Select(x => (decimal?)x.MonthlySalary)
            .FirstOrDefault() ?? 0m;

        var commission = db.Sales.AsNoTracking()
            .Where(x => x.SalesmanId == salesmanId && x.SaleDate >= from && x.SaleDate < toExclusive)
            .Sum(x => (decimal?)x.TotalCommission) ?? 0m;

        var advanceRows = db.SalaryAdvances.AsNoTracking()
            .Where(x => x.SalesmanId == salesmanId && x.PaidAt >= from && x.PaidAt < toExclusive)
            .OrderByDescending(x => x.PaidAt)
            .Select(x => new SalaryAdvanceRecord
            {
                PaidAt = x.PaidAt,
                Amount = x.Amount,
                PaidBy = x.PaidBy,
                Notes = x.Notes
            })
            .ToList();

        var advances = advanceRows.Sum(x => x.Amount);
        var result = new SalaryHistoryResult
        {
            MonthlySalary = salary,
            Commission = commission,
            Advances = advances,
            AdvancesList = advanceRows
        };

        var cursor = new DateTime(from.Year, from.Month, 1);
        var lastMonth = new DateTime(toExclusive.AddDays(-1).Year, toExclusive.AddDays(-1).Month, 1);
        while (cursor <= lastMonth)
        {
            var next = cursor.AddMonths(1);
            var monthCommission = db.Sales.AsNoTracking()
                .Where(x => x.SalesmanId == salesmanId && x.SaleDate >= cursor && x.SaleDate < next)
                .Sum(x => (decimal?)x.TotalCommission) ?? 0m;
            var monthAdvances = db.SalaryAdvances.AsNoTracking()
                .Where(x => x.SalesmanId == salesmanId && x.PaidAt >= cursor && x.PaidAt < next)
                .Sum(x => (decimal?)x.Amount) ?? 0m;

            result.Months.Add(new SalaryMonthRecord
            {
                Month = cursor,
                Salary = salary,
                Commission = monthCommission,
                Advances = monthAdvances
            });
            cursor = next;
        }

        return result;
    }


    /// <summary>
    /// Calculates the final salary payable for every active salesman for the selected month.
    /// Formula: Fixed Salary + Commission - Salary Advances.
    /// </summary>
    public List<FinalSalarySummary> GetFinalSalarySummaries(DateTime month)
    {
        var monthStart = new DateTime(month.Year, month.Month, 1);
        var nextMonth = monthStart.AddMonths(1);
        using var db = new ShopDbContext();

        var salesmen = db.Salesmen.AsNoTracking()
            .Where(x => x.IsActive)
            .OrderBy(x => x.Name)
            .ToList();

        var salaryMap = db.StaffSalaries.AsNoTracking()
            .ToDictionary(x => x.SalesmanId, x => x.MonthlySalary);

        var commissionMap = db.Sales.AsNoTracking()
            .Where(x => x.SalesmanId != null && x.SaleDate >= monthStart && x.SaleDate < nextMonth)
            .GroupBy(x => x.SalesmanId!.Value)
            .Select(g => new { SalesmanId = g.Key, Total = g.Sum(x => x.TotalCommission) })
            .ToDictionary(x => x.SalesmanId, x => x.Total);

        var advanceMap = db.SalaryAdvances.AsNoTracking()
            .Where(x => x.PaidAt >= monthStart && x.PaidAt < nextMonth)
            .GroupBy(x => x.SalesmanId)
            .Select(g => new { SalesmanId = g.Key, Total = g.Sum(x => x.Amount) })
            .ToDictionary(x => x.SalesmanId, x => x.Total);

        return salesmen.Select(s => new FinalSalarySummary
        {
            SalesmanId = s.SalesmanId,
            Name = s.Name,
            Code = s.Code,
            FixedSalary = salaryMap.GetValueOrDefault(s.SalesmanId, 0m),
            Commission = commissionMap.GetValueOrDefault(s.SalesmanId, 0m),
            Advances = advanceMap.GetValueOrDefault(s.SalesmanId, 0m)
        }).ToList();
    }

    public FinalSalarySummary GetFinalSalarySummary(int salesmanId, DateTime month)
    {
        var result = GetFinalSalarySummaries(month).FirstOrDefault(x => x.SalesmanId == salesmanId);
        if (result == null) throw new InvalidOperationException("Employee was not found.");
        return result;
    }

    public void RecordSalaryPayment(int salesmanId, DateTime month, string paidBy)
    {
        var payrollMonth = new DateTime(month.Year, month.Month, 1);
        var summary = GetFinalSalarySummary(salesmanId, payrollMonth);
        if (summary.FinalPayable < 0)
            throw new InvalidOperationException("Final payable salary cannot be negative.");

        using var db = new ShopDbContext();
        if (db.SalaryPayments.Any(x => x.SalesmanId == salesmanId && x.PayrollMonth == payrollMonth))
            throw new InvalidOperationException("Salary for this salesman and month has already been recorded as paid.");

        db.SalaryPayments.Add(new SalaryPayment
        {
            SalesmanId = salesmanId, PayrollMonth = payrollMonth, PaidAt = DateTime.Now,
            FixedSalary = summary.FixedSalary, Commission = summary.Commission,
            Advances = summary.Advances, AmountPaid = summary.FinalPayable,
            PaidBy = string.IsNullOrWhiteSpace(paidBy) ? "Admin" : paidBy.Trim()
        });
        db.SaveChanges();
    }

    public List<SalaryPaymentHistoryRow> GetSalaryPayments(DateTime? from = null, DateTime? to = null)
    {
        using var db = new ShopDbContext();
        var query = db.SalaryPayments.AsNoTracking().Include(x => x.Salesman).AsQueryable();
        if (from.HasValue) query = query.Where(x => x.PaidAt >= from.Value);
        if (to.HasValue) query = query.Where(x => x.PaidAt < to.Value);
        return query.OrderByDescending(x => x.PaidAt).Select(x => new SalaryPaymentHistoryRow
        {
            Salesman = x.Salesman!.Name, Code = x.Salesman.Code, PayrollMonth = x.PayrollMonth,
            PaidAt = x.PaidAt, FixedSalary = x.FixedSalary, Commission = x.Commission,
            Advances = x.Advances, AmountPaid = x.AmountPaid, PaidBy = x.PaidBy
        }).ToList();
    }

}
