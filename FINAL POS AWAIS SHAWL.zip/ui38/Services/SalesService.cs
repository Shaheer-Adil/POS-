using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Services;

public class SaleScanResult
{
    public int InventoryUnitId { get; set; }
    public int ProductId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string ProductCode { get; set; } = string.Empty;
    public decimal PurchasePrice { get; set; }
    public decimal SalePrice { get; set; }
    public string Status { get; set; } = string.Empty;
}

public class SaleCartItem
{
    public int InventoryUnitId { get; set; }
    public int ProductId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public decimal PurchasePrice { get; set; }
    public decimal SalePrice { get; set; }
}

public class CreditSaleInfo
{
    public string CustomerName { get; set; } = string.Empty;
    public string PhoneNumber { get; set; } = string.Empty;
    public decimal AmountPaid { get; set; }
}

public class SaleResult
{
    public int SaleId { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
    public decimal TotalAmount { get; set; }
    public string SalesmanName { get; set; } = string.Empty;
    public string SalesmanCode { get; set; } = string.Empty;
    public decimal TotalCommission { get; set; }
}

public class SalesService
{
    public SaleScanResult? ScanUnit(string unitCode)
    {
        if (string.IsNullOrWhiteSpace(unitCode))
            return null;

        using var db = new ShopDbContext();

        return db.InventoryUnits
            .AsNoTracking()
            .Include(x => x.Product)
            .Where(x => x.UnitCode == unitCode.Trim())
            .Select(x => new SaleScanResult
            {
                InventoryUnitId = x.InventoryUnitId,
                ProductId = x.ProductId,
                UnitCode = x.UnitCode,
                ProductName = x.Product!.ProductName,
                ProductCode = x.Product.ProductCode,
                PurchasePrice = x.PurchasePrice,
                SalePrice = x.SalePrice,
                Status = x.Status
            })
            .SingleOrDefault();
    }

    public List<SaleScanResult> SearchInStock(string searchText)
    {
        if (string.IsNullOrWhiteSpace(searchText))
            return new List<SaleScanResult>();

        var text = searchText.Trim();

        using var db = new ShopDbContext();

        return db.InventoryUnits
            .AsNoTracking()
            .Include(x => x.Product)
            .Where(x =>
                x.Status == "InStock" &&
                (x.UnitCode.Contains(text) ||
                 x.Product!.ProductName.Contains(text) ||
                 x.Product.ProductCode.Contains(text)))
            .OrderBy(x => x.Product!.ProductName)
            .ThenBy(x => x.UnitCode)
            .Select(x => new SaleScanResult
            {
                InventoryUnitId = x.InventoryUnitId,
                ProductId = x.ProductId,
                UnitCode = x.UnitCode,
                ProductName = x.Product!.ProductName,
                ProductCode = x.Product.ProductCode,
                PurchasePrice = x.PurchasePrice,
                SalePrice = x.SalePrice,
                Status = x.Status
            })
            .Take(100)
            .ToList();
    }

    public SaleResult CompleteSale(IReadOnlyCollection<SaleCartItem> cart, string soldBy, string salesmanCode, CreditSaleInfo? creditInfo = null)
    {
        if (cart.Count == 0)
            throw new InvalidOperationException("The bill is empty.");

        using var db = new ShopDbContext();
        using var transaction = db.Database.BeginTransaction();

        var ids = cart.Select(x => x.InventoryUnitId).Distinct().ToArray();
        if (ids.Length != cart.Count)
            throw new InvalidOperationException("The same tagged item cannot be added twice to one bill.");

        var units = db.InventoryUnits
            .Include(x => x.Product)
            .Where(x => ids.Contains(x.InventoryUnitId))
            .ToList();

        if (units.Count != cart.Count)
            throw new InvalidOperationException("One or more scanned inventory units no longer exist.");

        Salesman? salesman = null;
        var normalizedCode = (salesmanCode ?? string.Empty).Trim();
        if (!string.IsNullOrWhiteSpace(normalizedCode))
        {
            salesman = db.Salesmen.SingleOrDefault(x => x.Code == normalizedCode && x.IsActive);
            if (salesman == null)
                throw new InvalidOperationException("The salesman code is invalid or the salesman is inactive.");
        }

        Dictionary<int, decimal> commissionMap = new();
        if (salesman != null)
        {
            var productIds = units.Select(x => x.ProductId).Distinct().ToArray();
            commissionMap = db.SalesmanCommissions.AsNoTracking()
                .Where(x => x.SalesmanId == salesman.SalesmanId && productIds.Contains(x.ProductId))
                .ToDictionary(x => x.ProductId, x => x.Percentage);
        }

        decimal totalCommission = 0;
        foreach (var cartItem in cart)
        {
            var unit = units.Single(x => x.InventoryUnitId == cartItem.InventoryUnitId);

            if (!string.Equals(unit.Status, "InStock", StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException(
                    $"Unit {unit.UnitCode} is already {unit.Status} and cannot be sold again.");

            if (cartItem.SalePrice < unit.PurchasePrice)
                throw new InvalidOperationException(
                    $"Sale price for {unit.UnitCode} cannot be lower than its purchase price.");

            unit.SalePrice = cartItem.SalePrice;
            unit.Status = "Sold";

            var percentage = salesman == null ? 0m : commissionMap.GetValueOrDefault(unit.ProductId, 0m);
            totalCommission += Math.Round(cartItem.SalePrice * percentage / 100m, 2, MidpointRounding.AwayFromZero);
        }

        var now = DateTime.Now;
        var invoice = new Sale
        {
            InvoiceNumber = $"INV-{now:yyyyMMddHHmmssfff}",
            TotalAmount = cart.Sum(x => x.SalePrice),
            SaleDate = now,
            SoldBy = string.IsNullOrWhiteSpace(soldBy) ? "Staff" : soldBy,
            SalesmanId = salesman?.SalesmanId,
            SalesmanCode = salesman?.Code ?? string.Empty,
            SalesmanName = salesman?.Name ?? string.Empty,
            TotalCommission = totalCommission
        };

        db.Sales.Add(invoice);
        db.SaveChanges();

        foreach (var item in cart)
        {
            var unit = units.Single(x => x.InventoryUnitId == item.InventoryUnitId);
            var percentage = salesman == null ? 0m : commissionMap.GetValueOrDefault(unit.ProductId, 0m);
            var commissionAmount = Math.Round(item.SalePrice * percentage / 100m, 2, MidpointRounding.AwayFromZero);

            db.SaleItems.Add(new SaleItem
            {
                SaleId = invoice.SaleId,
                InventoryUnitId = unit.InventoryUnitId,
                UnitCode = unit.UnitCode,
                ProductName = unit.Product!.ProductName,
                PurchasePrice = unit.PurchasePrice,
                SalePrice = item.SalePrice,
                CommissionPercentage = percentage,
                CommissionAmount = commissionAmount
            });
        }

        db.SaveChanges();
        if (creditInfo != null)
        {
            if (creditInfo.AmountPaid < 0 || creditInfo.AmountPaid >= invoice.TotalAmount)
                throw new InvalidOperationException("Initial payment for a credit sale must be less than the bill total.");
            if (string.IsNullOrWhiteSpace(creditInfo.CustomerName))
                throw new InvalidOperationException("Customer name is required for a credit sale.");

            var phone = creditInfo.PhoneNumber?.Trim() ?? string.Empty;
            var account = !string.IsNullOrWhiteSpace(phone)
                ? db.CreditAccounts.FirstOrDefault(x => x.PhoneNumber == phone)
                : null;

            if (account == null)
            {
                account = new CreditAccount
                {
                    CustomerName = creditInfo.CustomerName.Trim(),
                    PhoneNumber = phone,
                    CreatedAt = now
                };
                db.CreditAccounts.Add(account);
                db.SaveChanges();
            }
            else
            {
                account.CustomerName = creditInfo.CustomerName.Trim();
            }

            db.CreditTransactions.Add(new CreditTransaction
            {
                CreditAccountId = account.CreditAccountId,
                SaleId = invoice.SaleId,
                TransactionType = "CreditSale",
                Amount = invoice.TotalAmount,
                TransactionDate = now,
                InvoiceNumber = invoice.InvoiceNumber,
                Notes = $"Credit sale recorded by {soldBy}"
            });

            if (creditInfo.AmountPaid > 0)
            {
                db.CreditTransactions.Add(new CreditTransaction
                {
                    CreditAccountId = account.CreditAccountId,
                    SaleId = invoice.SaleId,
                    TransactionType = "Payment",
                    Amount = creditInfo.AmountPaid,
                    TransactionDate = now,
                    InvoiceNumber = invoice.InvoiceNumber,
                    Notes = $"Initial payment received by {soldBy}"
                });
            }
        }

        db.SaveChanges();
        transaction.Commit();

        return new SaleResult
        {
            SaleId = invoice.SaleId,
            InvoiceNumber = invoice.InvoiceNumber,
            TotalAmount = invoice.TotalAmount,
            SalesmanName = invoice.SalesmanName,
            SalesmanCode = invoice.SalesmanCode,
            TotalCommission = invoice.TotalCommission
        };
    }
}
