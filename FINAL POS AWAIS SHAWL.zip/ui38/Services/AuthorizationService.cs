using System;
using System.Windows.Forms;

namespace ShopManagementSystem.Services;

/// <summary>
/// Centralized UI authorization checks for Step 23.
/// Dashboard visibility is not the only protection: each sensitive form
/// also checks the current session so it cannot be opened directly.
/// </summary>
public static class AuthorizationService
{
    public static bool IsAdmin => Session.IsAdmin;

    public static bool IsStaff =>
        Session.CurrentUser != null &&
        string.Equals(Session.CurrentUser.Role, "Staff", StringComparison.OrdinalIgnoreCase);

    public static bool HasKnownRole => IsAdmin || IsStaff;

    public static bool RequireAdmin(Form form, string feature)
    {
        if (IsAdmin)
            return true;

        form.Shown += (_, _) =>
        {
            MessageBox.Show(
                $"{feature} is restricted to administrators.",
                "Admin Access Required",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            form.Close();
        };
        return false;
    }
}
