using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Services;

public class ExchangeOriginalResult
{
    public int SaleItemId { get; set; }
    public int InventoryUnitId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string ProductCode { get; set; } = string.Empty;
    public decimal OriginalSalePrice { get; set; }
    public decimal PurchasePrice { get; set; }
    public DateTime SaleDate { get; set; }
    public string InvoiceNumber { get; set; } = string.Empty;
}

public class ExchangeReplacementResult
{
    public int InventoryUnitId { get; set; }
    public string UnitCode { get; set; } = string.Empty;
    public string ProductName { get; set; } = string.Empty;
    public string ProductCode { get; set; } = string.Empty;
    public decimal SalePrice { get; set; }
    public decimal PurchasePrice { get; set; }
    public string Status { get; set; } = string.Empty;
}

public class ExchangeResult
{
    public string OriginalUnitCode { get; set; } = string.Empty;
    public string ReplacementUnitCode { get; set; } = string.Empty;
    public decimal OriginalSalePrice { get; set; }
    public decimal ReplacementSalePrice { get; set; }
    public decimal PriceDifference { get; set; }
    public string Message { get; set; } = string.Empty;
}

public class ExchangeService
{
    public ExchangeOriginalResult? FindOriginal(string unitCode)
    {
        if (string.IsNullOrWhiteSpace(unitCode))
            return null;

        using var db = new ShopDbContext();

        return db.SaleItems
            .AsNoTracking()
            .Include(x => x.Sale)
            .Include(x => x.InventoryUnit)
            .ThenInclude(x => x!.Product)
            .Where(x =>
                x.UnitCode == unitCode.Trim() &&
                x.InventoryUnit!.Status == "Sold" &&
                !db.ProductReturns.Any(r => r.InventoryUnitId == x.InventoryUnitId) &&
                !db.ProductExchanges.Any(e => e.OriginalInventoryUnitId == x.InventoryUnitId))
            .Select(x => new ExchangeOriginalResult
            {
                SaleItemId = x.SaleItemId,
                InventoryUnitId = x.InventoryUnitId,
                UnitCode = x.UnitCode,
                ProductName = x.ProductName,
                ProductCode = x.InventoryUnit!.Product!.ProductCode,
                OriginalSalePrice = x.SalePrice,
                PurchasePrice = x.PurchasePrice,
                SaleDate = x.Sale!.SaleDate,
                InvoiceNumber = x.Sale.InvoiceNumber
            })
            .SingleOrDefault();
    }

    public List<ExchangeOriginalResult> SearchOriginals(string searchText)
    {
        if (string.IsNullOrWhiteSpace(searchText))
            return new List<ExchangeOriginalResult>();

        var text = searchText.Trim();

        using var db = new ShopDbContext();

        return db.SaleItems
            .AsNoTracking()
            .Include(x => x.Sale)
            .Include(x => x.InventoryUnit)
            .ThenInclude(x => x!.Product)
            .Where(x =>
                x.InventoryUnit!.Status == "Sold" &&
                !db.ProductReturns.Any(r => r.InventoryUnitId == x.InventoryUnitId) &&
                !db.ProductExchanges.Any(e => e.OriginalInventoryUnitId == x.InventoryUnitId) &&
                (x.UnitCode.Contains(text) ||
                 x.ProductName.Contains(text) ||
                 x.InventoryUnit.Product!.ProductCode.Contains(text)))
            .OrderByDescending(x => x.Sale!.SaleDate)
            .Select(x => new ExchangeOriginalResult
            {
                SaleItemId = x.SaleItemId,
                InventoryUnitId = x.InventoryUnitId,
                UnitCode = x.UnitCode,
                ProductName = x.ProductName,
                ProductCode = x.InventoryUnit!.Product!.ProductCode,
                OriginalSalePrice = x.SalePrice,
                PurchasePrice = x.PurchasePrice,
                SaleDate = x.Sale!.SaleDate,
                InvoiceNumber = x.Sale.InvoiceNumber
            })
            .Take(100)
            .ToList();
    }

    public List<ExchangeReplacementResult> SearchAvailableReplacement(string searchText)
    {
        if (string.IsNullOrWhiteSpace(searchText))
            return new List<ExchangeReplacementResult>();

        var text = searchText.Trim();

        using var db = new ShopDbContext();

        return db.InventoryUnits
            .AsNoTracking()
            .Include(x => x.Product)
            .Where(x =>
                x.Status == "InStock" &&
                (x.UnitCode.Contains(text) ||
                 x.Product!.ProductName.Contains(text) ||
                 x.Product.ProductCode.Contains(text)))
            .OrderBy(x => x.Product!.ProductName)
            .ThenBy(x => x.UnitCode)
            .Select(x => new ExchangeReplacementResult
            {
                InventoryUnitId = x.InventoryUnitId,
                UnitCode = x.UnitCode,
                ProductName = x.Product!.ProductName,
                ProductCode = x.Product.ProductCode,
                SalePrice = x.SalePrice,
                PurchasePrice = x.PurchasePrice,
                Status = x.Status
            })
            .Take(100)
            .ToList();
    }

    public ExchangeResult CompleteExchange(
        ExchangeOriginalResult original,
        ExchangeReplacementResult replacement,
        decimal replacementSalePrice,
        string exchangedBy,
        string reason)
    {
        using var db = new ShopDbContext();
        using var transaction = db.Database.BeginTransaction();

        var originalUnit = db.InventoryUnits
            .SingleOrDefault(x => x.InventoryUnitId == original.InventoryUnitId);

        var replacementUnit = db.InventoryUnits
            .SingleOrDefault(x => x.InventoryUnitId == replacement.InventoryUnitId);

        if (originalUnit == null || replacementUnit == null)
            throw new InvalidOperationException("One of the selected physical units no longer exists.");

        if (originalUnit.InventoryUnitId == replacementUnit.InventoryUnitId)
            throw new InvalidOperationException("The original and replacement unit cannot be the same physical item.");

        if (!string.Equals(originalUnit.Status, "Sold", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException(
                $"The original unit {originalUnit.UnitCode} is no longer marked as Sold.");

        if (!string.Equals(replacementUnit.Status, "InStock", StringComparison.OrdinalIgnoreCase))
            throw new InvalidOperationException(
                $"The replacement unit {replacementUnit.UnitCode} is no longer available in stock.");

        if (replacementSalePrice < replacementUnit.PurchasePrice)
            throw new InvalidOperationException(
                "The replacement sale price cannot be lower than its purchase price.");

        // The original returned unit becomes available again.
        originalUnit.Status = "InStock";

        // The replacement physical unit becomes sold.
        replacementUnit.SalePrice = replacementSalePrice;
        replacementUnit.Status = "Sold";

        var difference = replacementSalePrice - original.OriginalSalePrice;

        db.ProductExchanges.Add(new ProductExchange
        {
            OriginalSaleItemId = original.SaleItemId,
            OriginalInventoryUnitId = originalUnit.InventoryUnitId,
            OriginalUnitCode = originalUnit.UnitCode,
            OriginalSalePrice = original.OriginalSalePrice,

            ReplacementInventoryUnitId = replacementUnit.InventoryUnitId,
            ReplacementUnitCode = replacementUnit.UnitCode,
            ReplacementSalePrice = replacementSalePrice,

            PriceDifference = difference,
            ExchangeDate = DateTime.Now,
            ExchangedBy = string.IsNullOrWhiteSpace(exchangedBy) ? "Staff" : exchangedBy,
            Reason = string.IsNullOrWhiteSpace(reason) ? "Customer exchange" : reason.Trim()
        });

        db.SaveChanges();
        transaction.Commit();

        return new ExchangeResult
        {
            OriginalUnitCode = originalUnit.UnitCode,
            ReplacementUnitCode = replacementUnit.UnitCode,
            OriginalSalePrice = original.OriginalSalePrice,
            ReplacementSalePrice = replacementSalePrice,
            PriceDifference = difference,
            Message = difference > 0
                ? $"Customer pays Rs. {difference:N0} additional."
                : difference < 0
                    ? $"Customer receives Rs. {Math.Abs(difference):N0} difference/refund."
                    : "No price difference."
        };
    }
}
