UI Fix 35

- Redesigned the login screen to a professional shop-management style.
- Reduced the oversized login window to a practical 920x620 layout.
- Kept the "Awais Shall" title and centered it in the professional header.
- Added restrained blue/white colors, a login card, clear labels, and centered controls.
- Preserved existing Admin/Staff authentication behavior.
