using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Windows.Forms;
using QRCoder;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class TagPrintForm : Form
{
    private readonly List<InventoryTag> tags;
    private readonly PrintDocument printDocument = new();
    private readonly PrintPreviewDialog previewDialog = new();
    private int printedIndex;

    private const int Columns = 3;
    private const int Rows = 8;
    private const int Margin = 35;

    public TagPrintForm(IEnumerable<InventoryTag> tags)
    {
        this.tags = tags.ToList();

        Text = "QR Tag Printing";
        StartPosition = FormStartPosition.CenterScreen;
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(850, 620);
        Size = new Size(1000, 720);

        Controls.Add(new Label
        {
            Text = $"QR TAGS — {this.tags.Count:N0} sticker(s)",
            Dock = DockStyle.Top,
            Height = 60,
            Padding = new Padding(20),
            Font = new Font("Segoe UI", 16, FontStyle.Bold)
        });

        Controls.Add(new Label
        {
            Text = "Each QR contains the exact inventory unit code. Print the sheet and attach one tag to each physical item.",
            Dock = DockStyle.Top,
            Height = 55,
            Padding = new Padding(20, 0, 20, 10),
            Font = new Font("Segoe UI", 10)
        });

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 65,
            Padding = new Padding(15),
            FlowDirection = FlowDirection.RightToLeft
        };

        var close = new Button { Text = "CLOSE", Width = 110, Height = 38 };
        close.Click += (_, _) => Close();

        var preview = new Button { Text = "PRINT PREVIEW", Width = 150, Height = 38 };
        preview.Click += (_, _) => ShowPreview();

        buttons.Controls.Add(close);
        buttons.Controls.Add(preview);
        Controls.Add(buttons);

        printDocument.BeginPrint += (_, _) => printedIndex = 0;
        printDocument.PrintPage += PrintPage;

        previewDialog.Document = printDocument;
        previewDialog.UseAntiAlias = true;
        previewDialog.WindowState = FormWindowState.Maximized;
    }

    private void ShowPreview()
    {
        if (tags.Count == 0)
        {
            MessageBox.Show("There are no tags to print.", "No Tags",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        printedIndex = 0;
        previewDialog.ShowDialog(this);
    }

    private void PrintPage(object? sender, PrintPageEventArgs e)
    {
        var page = e.PageBounds;
        var usableWidth = page.Width - Margin * 2;
        var usableHeight = page.Height - Margin * 2;
        var cellWidth = usableWidth / Columns;
        var cellHeight = usableHeight / Rows;

        using var borderPen = new Pen(Color.Gray, 1);
        using var titleFont = new Font("Segoe UI", 8, FontStyle.Bold);
        using var smallFont = new Font("Segoe UI", 6.5f);
        using var priceFont = new Font("Segoe UI", 8, FontStyle.Bold);

        for (int row = 0; row < Rows && printedIndex < tags.Count; row++)
        {
            for (int col = 0; col < Columns && printedIndex < tags.Count; col++)
            {
                var tag = tags[printedIndex++];
                var x = Margin + col * cellWidth;
                var y = Margin + row * cellHeight;
                var rect = new Rectangle(x + 2, y + 2, cellWidth - 4, cellHeight - 4);

                e.Graphics.DrawRectangle(borderPen, rect);

                var qrSize = Math.Min(82, Math.Min(rect.Width / 3, rect.Height - 28));
                var qrRect = new Rectangle(rect.X + 8, rect.Y + 8, qrSize, qrSize);

                using var qr = CreateQrBitmap(tag.UnitCode);
                e.Graphics.DrawImage(qr, qrRect);

                var textX = qrRect.Right + 8;
                var textWidth = Math.Max(40, rect.Right - textX - 7);

                e.Graphics.DrawString(tag.ProductName, titleFont, Brushes.Black,
                    new RectangleF(textX, rect.Y + 8, textWidth, 28));
                e.Graphics.DrawString($"Code: {tag.UnitCode}", smallFont, Brushes.Black,
                    new RectangleF(textX, rect.Y + 38, textWidth, 32));
                e.Graphics.DrawString($"Price: Rs. {tag.SalePrice:N0}", priceFont, Brushes.Black,
                    new RectangleF(textX, rect.Y + 72, textWidth, 24));
            }
        }

        e.HasMorePages = printedIndex < tags.Count;
    }

    private static Bitmap CreateQrBitmap(string content)
    {
        using var generator = new QRCodeGenerator();
        using var data = generator.CreateQrCode(content, QRCodeGenerator.ECCLevel.Q);
        var qr = new PngByteQRCode(data);
        var bytes = qr.GetGraphic(10);

        using var ms = new MemoryStream(bytes);
        using var image = Image.FromStream(ms);
        return new Bitmap(image);
    }
}
