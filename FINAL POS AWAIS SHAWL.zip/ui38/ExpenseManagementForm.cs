using System;
using System.Drawing;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class ExpenseManagementForm : Form
{
    private readonly ExpenseService service = new();
    private readonly TextBox categoryBox = new();
    private readonly NumericUpDown amountBox = new();
    private readonly DateTimePicker datePicker = new();
    private readonly DateTimePicker timePicker = new();
    private readonly TextBox descriptionBox = new();
    private readonly DataGridView grid = new();

    private readonly Label salaryTotal = new();
    private readonly Label electricityTotal = new();
    private readonly Label otherTotal = new();
    private readonly Label grandTotal = new();

    private readonly DateTimePicker fromPicker = new();
    private readonly DateTimePicker toPicker = new();

    public ExpenseManagementForm()
    {
        if (!Session.IsAdmin)
        {
            Shown += (_, _) =>
            {
                MessageBox.Show("Only an administrator can manage expenses.",
                    "Admin Access Required", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                Close();
            };
            return;
        }

        Text = "Admin - Expense Management";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(1050, 700);
        Size = new Size(1250, 800);

        BuildUi();
        SetDefaultDates();
        LoadExpenses();
            BackButtonHelper.AddBackButton(this);
}

    private void BuildUi()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(18),
            ColumnCount = 1,
            RowCount = 4
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 65));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 105));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 105));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        root.Controls.Add(new Label
        {
            Text = "EXPENSE MANAGEMENT  •  ADMIN ONLY",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 19, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 0);

        root.Controls.Add(BuildEntryPanel(), 0, 1);
        root.Controls.Add(BuildSummaryPanel(), 0, 2);

        ConfigureGrid();
        root.Controls.Add(grid, 0, 3);
        Controls.Add(root);
    }

    private Control BuildEntryPanel()
    {
        var p = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 10,
            RowCount = 2,
            Padding = new Padding(0)
        };

        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 105));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 95));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 60));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 14));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 20));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 130));

        p.Controls.Add(MakeLabel("CATEGORY"), 0, 0);
        categoryBox.Dock = DockStyle.Fill;
        categoryBox.PlaceholderText = "Enter category";
        p.Controls.Add(categoryBox, 1, 0);

        p.Controls.Add(MakeLabel("AMOUNT"), 2, 0);
        amountBox.Dock = DockStyle.Fill;
        amountBox.DecimalPlaces = 0;
        amountBox.Maximum = 1000000000;
        amountBox.ThousandsSeparator = true;
        amountBox.Text = string.Empty;
        amountBox.Enter += (_, _) => { if (amountBox.Value == 0) amountBox.Text = string.Empty; };
        amountBox.MouseDown += (_, _) => { if (amountBox.Value == 0) amountBox.Text = string.Empty; };
        p.Controls.Add(amountBox, 3, 0);

        p.Controls.Add(MakeLabel("DATE"), 4, 0);
        datePicker.Dock = DockStyle.Fill;
        datePicker.Format = DateTimePickerFormat.Short;
        p.Controls.Add(datePicker, 5, 0);

        p.Controls.Add(MakeLabel("TIME"), 6, 0);
        timePicker.Dock = DockStyle.Fill;
        timePicker.Format = DateTimePickerFormat.Time;
        timePicker.ShowUpDown = true;
        p.Controls.Add(timePicker, 7, 0);

        descriptionBox.Dock = DockStyle.Fill;
        descriptionBox.PlaceholderText = "Description / note (optional)";
        p.Controls.Add(descriptionBox, 8, 0);

        var add = new Button
        {
            Text = "ADD EXPENSE",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };
        add.Click += (_, _) => AddExpense();
        p.Controls.Add(add, 9, 0);

        var fromLabel = MakeLabel("FROM");
        fromLabel.Margin = new Padding(0);
        p.Controls.Add(fromLabel, 0, 1);
        fromPicker.Dock = DockStyle.Fill;
        fromPicker.Margin = new Padding(0);
        fromPicker.Format = DateTimePickerFormat.Short;
        p.Controls.Add(fromPicker, 1, 1);

        var toLabel = MakeLabel("TO");
        toLabel.Margin = new Padding(0);
        p.Controls.Add(toLabel, 2, 1);
        toPicker.Dock = DockStyle.Fill;
        toPicker.Margin = new Padding(0);
        toPicker.Format = DateTimePickerFormat.Short;
        p.Controls.Add(toPicker, 3, 1);

        var view = new Button { Text = "VIEW PERIOD", Dock = DockStyle.Fill };
        view.Click += (_, _) => LoadExpenses();
        p.Controls.Add(view, 4, 1);
        p.SetColumnSpan(view, 2);

        var delete = new Button { Text = "DELETE SELECTED", Dock = DockStyle.Fill };
        delete.Click += (_, _) => DeleteSelected();
        p.Controls.Add(delete, 6, 1);
        p.SetColumnSpan(delete, 2);

        var note = new Label
        {
            Text = "Categories: Staff Salaries, Electricity Bill, Other. All records are stored with date/time and can be reviewed by period.",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 8),
            TextAlign = ContentAlignment.MiddleLeft
        };
        p.Controls.Add(note, 8, 1);
        p.SetColumnSpan(note, 2);

        return p;
    }

    private Control BuildSummaryPanel()
    {
        var p = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 4,
            RowCount = 2
        };

        for (var i = 0; i < 4; i++)
            p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));

        p.Controls.Add(MakeSummaryCard("STAFF SALARIES", salaryTotal), 0, 0);
        p.Controls.Add(MakeSummaryCard("ELECTRICITY", electricityTotal), 1, 0);
        p.Controls.Add(MakeSummaryCard("OTHER", otherTotal), 2, 0);
        p.Controls.Add(MakeSummaryCard("TOTAL EXPENSES", grandTotal), 3, 0);

        var period = new Label
        {
            Text = "Expenses recorded here are deducted from the shop's earnings when the Profit Report calculates final net profit.",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 9, FontStyle.Bold)
        };
        p.Controls.Add(period, 0, 1);
        p.SetColumnSpan(period, 4);

        return p;
    }

    private static Panel MakeSummaryCard(string title, Label value)
    {
        var panel = new Panel
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(4),
            BorderStyle = BorderStyle.FixedSingle,
            Padding = new Padding(8)
        };

        panel.Controls.Add(new Label
        {
            Text = title,
            Dock = DockStyle.Top,
            Height = 22,
            Font = new Font("Segoe UI", 8, FontStyle.Bold)
        });

        value.Dock = DockStyle.Fill;
        value.Font = new Font("Segoe UI", 12, FontStyle.Bold);
        value.TextAlign = ContentAlignment.MiddleLeft;
        panel.Controls.Add(value);
        return panel;
    }

    private void SetDefaultDates()
    {
        var today = DateTime.Today;
        fromPicker.Value = new DateTime(today.Year, today.Month, 1);
        toPicker.Value = today;
        datePicker.Value = today;
        timePicker.Value = DateTime.Now;
    }

    private void AddExpense()
    {
        try
        {
            var category = categoryBox.Text.Trim();
            if (string.IsNullOrWhiteSpace(category))
                throw new ArgumentException("Please enter an expense category.");

            var now = DateTime.Now;
            service.AddExpense(
                category,
                amountBox.Value,
                now,
                descriptionBox.Text,
                Session.CurrentUser?.Username ?? "Admin");

            MessageBox.Show("Expense recorded successfully.",
                "Expense Added", MessageBoxButtons.OK, MessageBoxIcon.Information);

            amountBox.Value = 0; amountBox.Text = string.Empty;
            categoryBox.Clear();
            datePicker.Value = DateTime.Now;
            timePicker.Value = DateTime.Now;
            descriptionBox.Clear();
            LoadExpenses();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Could not add the expense.\r\n\r\n" + ex.Message,
                "Expense Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void LoadExpenses()
    {
        if (toPicker.Value.Date < fromPicker.Value.Date)
        {
            MessageBox.Show("The end date cannot be earlier than the start date.",
                "Invalid Dates", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var summary = service.GetSummary(fromPicker.Value.Date, toPicker.Value.Date);
        salaryTotal.Text = Money(summary.StaffSalaries);
        electricityTotal.Text = Money(summary.Electricity);
        otherTotal.Text = Money(summary.Other);
        grandTotal.Text = Money(summary.Total);

        grid.Rows.Clear();
        foreach (var row in service.GetRecords(fromPicker.Value.Date, toPicker.Value.Date))
        {
            var index = grid.Rows.Add(
                row.Category,
                row.ExpenseDate.ToString("dd-MMM-yyyy"),
                row.ExpenseDate.ToString("hh:mm tt"),
                row.Amount.ToString("#,##0.##"),
                row.Description,
                row.RecordedBy);

            grid.Rows[index].Tag = row.ExpenseId;
        }
    }

    private void DeleteSelected()
    {
        if (grid.SelectedRows.Count == 0)
        {
            MessageBox.Show("Select an expense record first.",
                "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (MessageBox.Show("Delete the selected expense record?",
                "Confirm Delete", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) != DialogResult.Yes)
            return;

        var id = Convert.ToInt32(grid.SelectedRows[0].Tag);
        service.DeleteExpense(id);
        LoadExpenses();
    }

    private void ConfigureGrid()
    {
        grid.Dock = DockStyle.Fill;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.ReadOnly = true;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.RowHeadersVisible = false;

        grid.Columns.Add("Category", "CATEGORY");
        grid.Columns.Add("Date", "DATE");
        grid.Columns.Add("Time", "TIME");
        grid.Columns.Add("Amount", "AMOUNT");
        grid.Columns.Add("Description", "DESCRIPTION");
        grid.Columns.Add("RecordedBy", "RECORDED BY");
    }

    private static Label MakeLabel(string text) => new()
    {
        Text = text,
        Dock = DockStyle.Fill,
        TextAlign = ContentAlignment.MiddleLeft,
        Font = new Font("Segoe UI", 8, FontStyle.Bold)
    };

    private static string Money(decimal value) => $"Rs. {value:#,##0.##}";
}
