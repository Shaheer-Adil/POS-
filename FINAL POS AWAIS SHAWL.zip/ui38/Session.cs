using ShopManagementSystem.Models;

namespace ShopManagementSystem;

public static class Session
{
    public static User? CurrentUser { get; set; }

    public static bool IsAdmin =>
        CurrentUser != null &&
        CurrentUser.Role.Equals("Admin", System.StringComparison.OrdinalIgnoreCase);

    public static bool IsStaff =>
        CurrentUser != null &&
        CurrentUser.Role.Equals("Staff", System.StringComparison.OrdinalIgnoreCase);

    public static bool HasKnownRole => IsAdmin || IsStaff;

    public static void Clear()
    {
        CurrentUser = null;
    }
}
