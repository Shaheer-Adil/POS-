# UI Fix 33

## Sales & Billing
- Replaced the separate `PRINT LAST BILL` and `COMPLETE SALE` buttons with one `COMPLETE BILL` button.
- Clicking `COMPLETE BILL` completes the sale and immediately sends the completed bill to the default printer.
- The same behavior is used for Credit/Khata completion after the credit details are confirmed.
- The bill includes invoice number, date/time, processed-by user, salesman name/code when applicable, each product, unit/tag code, sale price, item count, total amount, payment type, and a thank-you footer.
- Purchase price and internal commission are not printed on the customer bill.


## UI Fix 33 Update
- Customer bills no longer print the salesman code.
- The salesman name remains on the bill.
- All other bill information and Complete Bill printing behavior remain unchanged.
