using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Data;

public class ShopDbContext : DbContext
{
    public DbSet<User> Users => Set<User>();
    public DbSet<Product> Products => Set<Product>();
    public DbSet<InventoryUnit> InventoryUnits => Set<InventoryUnit>();
    public DbSet<Sale> Sales => Set<Sale>();
    public DbSet<SaleItem> SaleItems => Set<SaleItem>();
    public DbSet<ProductReturn> ProductReturns => Set<ProductReturn>();
    public DbSet<ProductExchange> ProductExchanges => Set<ProductExchange>();
    public DbSet<CreditAccount> CreditAccounts => Set<CreditAccount>();
    public DbSet<CreditTransaction> CreditTransactions => Set<CreditTransaction>();
    public DbSet<Salesman> Salesmen => Set<Salesman>();
    public DbSet<SalesmanCommission> SalesmanCommissions => Set<SalesmanCommission>();
    public DbSet<StaffSalary> StaffSalaries => Set<StaffSalary>();
    public DbSet<SalaryAdvance> SalaryAdvances => Set<SalaryAdvance>();
    public DbSet<SalaryPayment> SalaryPayments => Set<SalaryPayment>();
    public DbSet<Expense> Expenses => Set<Expense>();

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            optionsBuilder.UseSqlServer(
                @"Server=(localdb)\MSSQLLocalDB;Database=ShopManagementDB;Trusted_Connection=True;TrustServerCertificate=True;MultipleActiveResultSets=True");
        }
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<User>(entity =>
        {
            entity.HasKey(x => x.UserId);
            entity.HasIndex(x => x.Username).IsUnique();
            entity.Property(x => x.Username).HasMaxLength(50).IsRequired();
            entity.Property(x => x.PasswordHash).HasMaxLength(255).IsRequired();
            entity.Property(x => x.Role).HasMaxLength(20).IsRequired();
            entity.Property(x => x.IsActive).IsRequired();
            entity.Property(x => x.CreatedAt).IsRequired();
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(x => x.ProductId);
            entity.HasIndex(x => x.ProductCode).IsUnique();
            entity.Property(x => x.ProductCode).HasMaxLength(30).IsRequired();
            entity.Property(x => x.ProductName).HasMaxLength(150).IsRequired();
            entity.Property(x => x.Category).HasMaxLength(100);
            entity.Property(x => x.PurchasePrice).HasColumnType("decimal(18,2)");
            entity.Property(x => x.SalePrice).HasColumnType("decimal(18,2)");
            entity.Property(x => x.Quantity).IsRequired();
            entity.Property(x => x.CreatedAt).IsRequired();
        });

        modelBuilder.Entity<InventoryUnit>(entity =>
        {
            entity.HasKey(x => x.InventoryUnitId);
            entity.HasIndex(x => x.UnitCode).IsUnique();
            entity.Property(x => x.UnitCode).HasMaxLength(40).IsRequired();
            entity.Property(x => x.PurchasePrice).HasColumnType("decimal(18,2)");
            entity.Property(x => x.SalePrice).HasColumnType("decimal(18,2)");
            entity.Property(x => x.Status).HasMaxLength(20).IsRequired();

            entity.HasOne(x => x.Product)
                  .WithMany(x => x.InventoryUnits)
                  .HasForeignKey(x => x.ProductId)
                  .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<Sale>(entity =>
        {
            entity.HasKey(x => x.SaleId);
            entity.HasIndex(x => x.InvoiceNumber).IsUnique();
            entity.Property(x => x.InvoiceNumber).HasMaxLength(40).IsRequired();
            entity.Property(x => x.TotalAmount).HasColumnType("decimal(18,2)");
            entity.Property(x => x.SoldBy).HasMaxLength(50).IsRequired();
            entity.Property(x => x.SalesmanCode).HasMaxLength(3).IsRequired();
            entity.Property(x => x.SalesmanName).HasMaxLength(100).IsRequired();
            entity.Property(x => x.TotalCommission).HasColumnType("decimal(18,2)");
            entity.HasIndex(x => x.SalesmanId);
            entity.Property(x => x.SaleDate).IsRequired();
        });

        modelBuilder.Entity<SaleItem>(entity =>
        {
            entity.HasKey(x => x.SaleItemId);
            entity.HasIndex(x => x.UnitCode);
            entity.Property(x => x.UnitCode).HasMaxLength(40).IsRequired();
            entity.Property(x => x.ProductName).HasMaxLength(150).IsRequired();
            entity.Property(x => x.PurchasePrice).HasColumnType("decimal(18,2)");
            entity.Property(x => x.SalePrice).HasColumnType("decimal(18,2)");
            entity.Property(x => x.CommissionPercentage).HasColumnType("decimal(5,2)");
            entity.Property(x => x.CommissionAmount).HasColumnType("decimal(18,2)");

            entity.HasOne(x => x.Sale)
                  .WithMany(x => x.Items)
                  .HasForeignKey(x => x.SaleId)
                  .OnDelete(DeleteBehavior.Cascade);

            entity.HasOne(x => x.InventoryUnit)
                  .WithMany()
                  .HasForeignKey(x => x.InventoryUnitId)
                  .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ProductReturn>(entity =>
        {
            entity.HasKey(x => x.ProductReturnId);
            entity.HasIndex(x => x.InventoryUnitId).IsUnique();
            entity.HasIndex(x => x.UnitCode);
            entity.Property(x => x.UnitCode).HasMaxLength(40).IsRequired();
            entity.Property(x => x.OriginalSalePrice).HasColumnType("decimal(18,2)");
            entity.Property(x => x.ReturnDate).IsRequired();
            entity.Property(x => x.ReturnedBy).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Reason).HasMaxLength(300);

            entity.HasOne(x => x.SaleItem)
                  .WithMany()
                  .HasForeignKey(x => x.SaleItemId)
                  .OnDelete(DeleteBehavior.Restrict);

            entity.HasOne(x => x.InventoryUnit)
                  .WithMany()
                  .HasForeignKey(x => x.InventoryUnitId)
                  .OnDelete(DeleteBehavior.Restrict);
        });

        modelBuilder.Entity<ProductExchange>(entity =>
        {
            entity.HasKey(x => x.ProductExchangeId);
            entity.HasIndex(x => x.OriginalInventoryUnitId);
            entity.HasIndex(x => x.ReplacementInventoryUnitId);
            entity.HasIndex(x => x.OriginalUnitCode);
            entity.HasIndex(x => x.ReplacementUnitCode);

            entity.Property(x => x.OriginalUnitCode).HasMaxLength(40).IsRequired();
            entity.Property(x => x.ReplacementUnitCode).HasMaxLength(40).IsRequired();
            entity.Property(x => x.OriginalSalePrice).HasColumnType("decimal(18,2)");
            entity.Property(x => x.ReplacementSalePrice).HasColumnType("decimal(18,2)");
            entity.Property(x => x.PriceDifference).HasColumnType("decimal(18,2)");
            entity.Property(x => x.ExchangeDate).IsRequired();
            entity.Property(x => x.ExchangedBy).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Reason).HasMaxLength(300);
        });
        modelBuilder.Entity<CreditAccount>(entity =>
        {
            entity.HasKey(x => x.CreditAccountId);
            entity.Property(x => x.CustomerName).HasMaxLength(150).IsRequired();
            entity.Property(x => x.PhoneNumber).HasMaxLength(30);
            entity.Property(x => x.CreatedAt).IsRequired();
            entity.HasIndex(x => x.PhoneNumber);
        });

        modelBuilder.Entity<Salesman>(entity =>
        {
            entity.HasKey(x => x.SalesmanId);
            entity.HasIndex(x => x.Code).IsUnique();
            entity.Property(x => x.Name).HasMaxLength(100).IsRequired();
            entity.Property(x => x.Code).HasMaxLength(3).IsRequired();
            entity.Property(x => x.IsActive).IsRequired();
            entity.Property(x => x.CreatedAt).IsRequired();
        });

        modelBuilder.Entity<StaffSalary>(entity =>
        {
            entity.HasKey(x => x.StaffSalaryId);
            entity.HasIndex(x => x.SalesmanId).IsUnique();
            entity.Property(x => x.MonthlySalary).HasColumnType("decimal(18,2)");
            entity.Property(x => x.UpdatedAt).IsRequired();
            entity.HasOne(x => x.Salesman).WithOne().HasForeignKey<StaffSalary>(x => x.SalesmanId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<SalaryAdvance>(entity =>
        {
            entity.HasKey(x => x.SalaryAdvanceId);
            entity.HasIndex(x => new { x.SalesmanId, x.PaidAt });
            entity.Property(x => x.Amount).HasColumnType("decimal(18,2)");
            entity.Property(x => x.PaidBy).HasMaxLength(50).IsRequired();
            entity.Property(x => x.Notes).HasMaxLength(300).IsRequired();
            entity.Property(x => x.PaidAt).IsRequired();
            entity.HasOne(x => x.Salesman).WithMany().HasForeignKey(x => x.SalesmanId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<SalaryPayment>(entity =>
        {
            entity.HasKey(x => x.SalaryPaymentId);
            entity.HasIndex(x => new { x.SalesmanId, x.PayrollMonth }).IsUnique();
            entity.Property(x => x.PayrollMonth).IsRequired();
            entity.Property(x => x.PaidAt).IsRequired();
            entity.Property(x => x.FixedSalary).HasColumnType("decimal(18,2)");
            entity.Property(x => x.Commission).HasColumnType("decimal(18,2)");
            entity.Property(x => x.Advances).HasColumnType("decimal(18,2)");
            entity.Property(x => x.AmountPaid).HasColumnType("decimal(18,2)");
            entity.Property(x => x.PaidBy).HasMaxLength(50).IsRequired();
            entity.HasOne(x => x.Salesman).WithMany().HasForeignKey(x => x.SalesmanId).OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<SalesmanCommission>(entity =>
        {
            entity.HasKey(x => x.SalesmanCommissionId);
            entity.HasIndex(x => new { x.SalesmanId, x.ProductId }).IsUnique();
            entity.Property(x => x.Percentage).HasColumnType("decimal(5,2)");
            entity.Property(x => x.UpdatedAt).IsRequired();
            entity.HasOne(x => x.Salesman).WithMany(x => x.Commissions).HasForeignKey(x => x.SalesmanId).OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(x => x.Product).WithMany().HasForeignKey(x => x.ProductId).OnDelete(DeleteBehavior.Restrict);
        });


        modelBuilder.Entity<Expense>(entity =>
        {
            entity.HasKey(x => x.ExpenseId);
            entity.Property(x => x.Category).HasMaxLength(40).IsRequired();
            entity.Property(x => x.Amount).HasColumnType("decimal(18,2)");
            entity.Property(x => x.ExpenseDate).IsRequired();
            entity.Property(x => x.Description).HasMaxLength(300).IsRequired();
            entity.Property(x => x.RecordedBy).HasMaxLength(50).IsRequired();
            entity.HasIndex(x => x.ExpenseDate);
            entity.HasIndex(x => x.Category);
        });

        modelBuilder.Entity<CreditTransaction>(entity =>
        {
            entity.HasKey(x => x.CreditTransactionId);
            entity.Property(x => x.TransactionType).HasMaxLength(20).IsRequired();
            entity.Property(x => x.Amount).HasColumnType("decimal(18,2)");
            entity.Property(x => x.InvoiceNumber).HasMaxLength(40);
            entity.Property(x => x.Notes).HasMaxLength(300);
            entity.Property(x => x.TransactionDate).IsRequired();
            entity.HasOne(x => x.CreditAccount)
                  .WithMany(x => x.Transactions)
                  .HasForeignKey(x => x.CreditAccountId)
                  .OnDelete(DeleteBehavior.Cascade);
            entity.HasOne(x => x.Sale)
                  .WithMany()
                  .HasForeignKey(x => x.SaleId)
                  .OnDelete(DeleteBehavior.Restrict);
            entity.HasIndex(x => x.CreditAccountId);
            entity.HasIndex(x => x.SaleId);
        });

    }
}
