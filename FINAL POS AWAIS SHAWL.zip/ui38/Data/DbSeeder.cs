using System;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Models;

namespace ShopManagementSystem.Data;

public static class DbSeeder
{
    public static void Initialize(ShopDbContext db)
    {
        db.Database.ExecuteSqlRaw(@"
IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Products
    (
        ProductId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Products PRIMARY KEY,
        ProductCode NVARCHAR(30) NOT NULL,
        ProductName NVARCHAR(150) NOT NULL,
        Category NVARCHAR(100) NOT NULL,
        PurchasePrice DECIMAL(18,2) NOT NULL,
        SalePrice DECIMAL(18,2) NOT NULL,
        Quantity INT NOT NULL,
        CreatedAt DATETIME2 NOT NULL
    );
    CREATE UNIQUE INDEX IX_Products_ProductCode ON dbo.Products(ProductCode);
END

IF OBJECT_ID(N'dbo.InventoryUnits', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.InventoryUnits
    (
        InventoryUnitId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_InventoryUnits PRIMARY KEY,
        ProductId INT NOT NULL,
        UnitCode NVARCHAR(40) NOT NULL,
        PurchasePrice DECIMAL(18,2) NOT NULL,
        SalePrice DECIMAL(18,2) NOT NULL,
        Status NVARCHAR(20) NOT NULL,
        AddedAt DATETIME2 NOT NULL,
        CONSTRAINT FK_InventoryUnits_Products_ProductId
            FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId)
    );
    CREATE UNIQUE INDEX IX_InventoryUnits_UnitCode ON dbo.InventoryUnits(UnitCode);
END

IF OBJECT_ID(N'dbo.Sales', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Sales
    (
        SaleId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Sales PRIMARY KEY,
        InvoiceNumber NVARCHAR(40) NOT NULL,
        TotalAmount DECIMAL(18,2) NOT NULL,
        SaleDate DATETIME2 NOT NULL,
        SoldBy NVARCHAR(50) NOT NULL
    );
    CREATE UNIQUE INDEX IX_Sales_InvoiceNumber ON dbo.Sales(InvoiceNumber);
END

IF COL_LENGTH(N'dbo.Sales', N'SalesmanId') IS NULL
    ALTER TABLE dbo.Sales ADD SalesmanId INT NULL;
IF COL_LENGTH(N'dbo.Sales', N'SalesmanCode') IS NULL
    ALTER TABLE dbo.Sales ADD SalesmanCode NVARCHAR(3) NOT NULL CONSTRAINT DF_Sales_SalesmanCode DEFAULT N'';
IF COL_LENGTH(N'dbo.Sales', N'SalesmanName') IS NULL
    ALTER TABLE dbo.Sales ADD SalesmanName NVARCHAR(100) NOT NULL CONSTRAINT DF_Sales_SalesmanName DEFAULT N'';
IF COL_LENGTH(N'dbo.Sales', N'TotalCommission') IS NULL
    ALTER TABLE dbo.Sales ADD TotalCommission DECIMAL(18,2) NOT NULL CONSTRAINT DF_Sales_TotalCommission DEFAULT 0;

IF OBJECT_ID(N'dbo.SaleItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SaleItems
    (
        SaleItemId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SaleItems PRIMARY KEY,
        SaleId INT NOT NULL,
        InventoryUnitId INT NOT NULL,
        UnitCode NVARCHAR(40) NOT NULL,
        ProductName NVARCHAR(150) NOT NULL,
        PurchasePrice DECIMAL(18,2) NOT NULL,
        SalePrice DECIMAL(18,2) NOT NULL,
        CONSTRAINT FK_SaleItems_Sales_SaleId
            FOREIGN KEY (SaleId) REFERENCES dbo.Sales(SaleId) ON DELETE CASCADE,
        CONSTRAINT FK_SaleItems_InventoryUnits_InventoryUnitId
            FOREIGN KEY (InventoryUnitId) REFERENCES dbo.InventoryUnits(InventoryUnitId)
    );
    CREATE INDEX IX_SaleItems_UnitCode ON dbo.SaleItems(UnitCode);
END

IF COL_LENGTH(N'dbo.SaleItems', N'CommissionPercentage') IS NULL
    ALTER TABLE dbo.SaleItems ADD CommissionPercentage DECIMAL(5,2) NOT NULL CONSTRAINT DF_SaleItems_CommissionPercentage DEFAULT 0;
IF COL_LENGTH(N'dbo.SaleItems', N'CommissionAmount') IS NULL
    ALTER TABLE dbo.SaleItems ADD CommissionAmount DECIMAL(18,2) NOT NULL CONSTRAINT DF_SaleItems_CommissionAmount DEFAULT 0;

IF OBJECT_ID(N'dbo.ProductReturns', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ProductReturns
    (
        ProductReturnId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_ProductReturns PRIMARY KEY,
        SaleItemId INT NOT NULL,
        InventoryUnitId INT NOT NULL,
        UnitCode NVARCHAR(40) NOT NULL,
        OriginalSalePrice DECIMAL(18,2) NOT NULL,
        ReturnDate DATETIME2 NOT NULL,
        ReturnedBy NVARCHAR(50) NOT NULL,
        Reason NVARCHAR(300) NOT NULL,
        CONSTRAINT FK_ProductReturns_SaleItems_SaleItemId
            FOREIGN KEY (SaleItemId) REFERENCES dbo.SaleItems(SaleItemId),
        CONSTRAINT FK_ProductReturns_InventoryUnits_InventoryUnitId
            FOREIGN KEY (InventoryUnitId) REFERENCES dbo.InventoryUnits(InventoryUnitId)
    );
    CREATE UNIQUE INDEX IX_ProductReturns_InventoryUnitId
        ON dbo.ProductReturns(InventoryUnitId);
    CREATE INDEX IX_ProductReturns_UnitCode
        ON dbo.ProductReturns(UnitCode);
END


IF OBJECT_ID(N'dbo.ProductExchanges', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.ProductExchanges
    (
        ProductExchangeId INT IDENTITY(1,1) NOT NULL
            CONSTRAINT PK_ProductExchanges PRIMARY KEY,
        OriginalSaleItemId INT NOT NULL,
        OriginalInventoryUnitId INT NOT NULL,
        OriginalUnitCode NVARCHAR(40) NOT NULL,
        OriginalSalePrice DECIMAL(18,2) NOT NULL,
        ReplacementInventoryUnitId INT NOT NULL,
        ReplacementUnitCode NVARCHAR(40) NOT NULL,
        ReplacementSalePrice DECIMAL(18,2) NOT NULL,
        PriceDifference DECIMAL(18,2) NOT NULL,
        ExchangeDate DATETIME2 NOT NULL,
        ExchangedBy NVARCHAR(50) NOT NULL,
        Reason NVARCHAR(300) NOT NULL
    );

    CREATE INDEX IX_ProductExchanges_OriginalInventoryUnitId
        ON dbo.ProductExchanges(OriginalInventoryUnitId);

    CREATE INDEX IX_ProductExchanges_ReplacementInventoryUnitId
        ON dbo.ProductExchanges(ReplacementInventoryUnitId);

    CREATE INDEX IX_ProductExchanges_OriginalUnitCode
        ON dbo.ProductExchanges(OriginalUnitCode);

    CREATE INDEX IX_ProductExchanges_ReplacementUnitCode
        ON dbo.ProductExchanges(ReplacementUnitCode);
END

IF OBJECT_ID(N'dbo.CreditAccounts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CreditAccounts
    (
        CreditAccountId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CreditAccounts PRIMARY KEY,
        CustomerName NVARCHAR(150) NOT NULL,
        PhoneNumber NVARCHAR(30) NOT NULL,
        CreatedAt DATETIME2 NOT NULL
    );
    CREATE INDEX IX_CreditAccounts_PhoneNumber ON dbo.CreditAccounts(PhoneNumber);
END

IF OBJECT_ID(N'dbo.CreditTransactions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CreditTransactions
    (
        CreditTransactionId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_CreditTransactions PRIMARY KEY,
        CreditAccountId INT NOT NULL,
        SaleId INT NULL,
        TransactionType NVARCHAR(20) NOT NULL,
        Amount DECIMAL(18,2) NOT NULL,
        TransactionDate DATETIME2 NOT NULL,
        InvoiceNumber NVARCHAR(40) NOT NULL,
        Notes NVARCHAR(300) NOT NULL,
        CONSTRAINT FK_CreditTransactions_CreditAccounts_CreditAccountId
            FOREIGN KEY (CreditAccountId) REFERENCES dbo.CreditAccounts(CreditAccountId) ON DELETE CASCADE,
        CONSTRAINT FK_CreditTransactions_Sales_SaleId
            FOREIGN KEY (SaleId) REFERENCES dbo.Sales(SaleId)
    );
    CREATE INDEX IX_CreditTransactions_CreditAccountId ON dbo.CreditTransactions(CreditAccountId);
    CREATE INDEX IX_CreditTransactions_SaleId ON dbo.CreditTransactions(SaleId);
END

IF OBJECT_ID(N'dbo.Salesmen', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Salesmen
    (
        SalesmanId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Salesmen PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Code NVARCHAR(3) NOT NULL,
        IsActive BIT NOT NULL,
        CreatedAt DATETIME2 NOT NULL
    );
    CREATE UNIQUE INDEX IX_Salesmen_Code ON dbo.Salesmen(Code);
END

IF OBJECT_ID(N'dbo.SalesmanCommissions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SalesmanCommissions
    (
        SalesmanCommissionId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SalesmanCommissions PRIMARY KEY,
        SalesmanId INT NOT NULL,
        ProductId INT NOT NULL,
        Percentage DECIMAL(5,2) NOT NULL,
        UpdatedAt DATETIME2 NOT NULL,
        CONSTRAINT FK_SalesmanCommissions_Salesmen_SalesmanId
            FOREIGN KEY (SalesmanId) REFERENCES dbo.Salesmen(SalesmanId) ON DELETE CASCADE,
        CONSTRAINT FK_SalesmanCommissions_Products_ProductId
            FOREIGN KEY (ProductId) REFERENCES dbo.Products(ProductId) ON DELETE NO ACTION
    );
    CREATE UNIQUE INDEX IX_SalesmanCommissions_Salesman_Product
        ON dbo.SalesmanCommissions(SalesmanId, ProductId);
END

IF OBJECT_ID(N'dbo.StaffSalaries', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.StaffSalaries
    (
        StaffSalaryId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_StaffSalaries PRIMARY KEY,
        SalesmanId INT NOT NULL,
        MonthlySalary DECIMAL(18,2) NOT NULL,
        UpdatedAt DATETIME2 NOT NULL,
        CONSTRAINT FK_StaffSalaries_Salesmen_SalesmanId FOREIGN KEY (SalesmanId) REFERENCES dbo.Salesmen(SalesmanId) ON DELETE CASCADE
    );
    CREATE UNIQUE INDEX IX_StaffSalaries_SalesmanId ON dbo.StaffSalaries(SalesmanId);
END

IF OBJECT_ID(N'dbo.SalaryAdvances', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SalaryAdvances
    (
        SalaryAdvanceId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SalaryAdvances PRIMARY KEY,
        SalesmanId INT NOT NULL,
        Amount DECIMAL(18,2) NOT NULL,
        PaidAt DATETIME2 NOT NULL,
        PaidBy NVARCHAR(50) NOT NULL,
        Notes NVARCHAR(300) NOT NULL,
        CONSTRAINT FK_SalaryAdvances_Salesmen_SalesmanId FOREIGN KEY (SalesmanId) REFERENCES dbo.Salesmen(SalesmanId) ON DELETE CASCADE
    );
    CREATE INDEX IX_SalaryAdvances_Salesman_PaidAt ON dbo.SalaryAdvances(SalesmanId, PaidAt);
END


IF OBJECT_ID(N'dbo.Expenses', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Expenses
    (
        ExpenseId INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Expenses PRIMARY KEY,
        Category NVARCHAR(40) NOT NULL,
        Amount DECIMAL(18,2) NOT NULL,
        ExpenseDate DATETIME2 NOT NULL,
        Description NVARCHAR(300) NOT NULL,
        RecordedBy NVARCHAR(50) NOT NULL
    );
    CREATE INDEX IX_Expenses_ExpenseDate ON dbo.Expenses(ExpenseDate);
    CREATE INDEX IX_Expenses_Category ON dbo.Expenses(Category);
END

");

        // UI Fix 38: Set the administrator login credentials to bashir / bashir.
        // Update an existing admin account so the change also applies to an existing database.
        var adminUser = db.Users.FirstOrDefault(x => x.Role == "Admin");
        if (adminUser == null)
        {
            adminUser = new User
            {
                Username = "bashir",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("bashir"),
                Role = "Admin",
                IsActive = true,
                CreatedAt = DateTime.Now
            };
            db.Users.Add(adminUser);
        }
        else
        {
            adminUser.Username = "bashir";
            adminUser.PasswordHash = BCrypt.Net.BCrypt.HashPassword("bashir");
            adminUser.IsActive = true;
        }

        // Keep the default staff account when the database is newly created.
        if (!db.Users.Any(x => x.Role == "Staff"))
        {
            db.Users.Add(new User
            {
                Username = "staff",
                PasswordHash = BCrypt.Net.BCrypt.HashPassword("staff123"),
                Role = "Staff",
                IsActive = true,
                CreatedAt = DateTime.Now
            });
        }

        db.SaveChanges();
    }
}