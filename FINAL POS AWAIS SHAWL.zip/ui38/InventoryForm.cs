using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class InventoryForm : Form
{
    private readonly TextBox searchBox = new();
    private readonly DataGridView grid = new();
    private readonly Label countLabel = new();
    private readonly ProductService service = new();
    private InventoryGroupRow[] groups = Array.Empty<InventoryGroupRow>();

    public InventoryForm()
    {
        Text = "Inventory";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(900, 600);
        Size = new Size(1200, 720);

        var top = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 115,
            Padding = new Padding(20),
            ColumnCount = 6,
            RowCount = 2
        };
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 120));
        top.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 110));

        top.Controls.Add(new Label
        {
            Text = "SEARCH",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        }, 0, 0);

        searchBox.Dock = DockStyle.Fill;
        searchBox.KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.Enter)
            {
                LoadInventory();
                e.SuppressKeyPress = true;
            }
        };
        top.Controls.Add(searchBox, 1, 0);

        var searchButton = new Button { Text = "SEARCH", Dock = DockStyle.Fill };
        searchButton.Click += (_, _) => LoadInventory();
        top.Controls.Add(searchButton, 2, 0);

        var refresh = new Button { Text = "REFRESH", Dock = DockStyle.Fill };
        refresh.Click += (_, _) =>
        {
            searchBox.Clear();
            LoadInventory();
        };
        top.Controls.Add(refresh, 3, 0);

        var print = new Button { Text = "PRINT TAG", Dock = DockStyle.Fill };
        print.Click += (_, _) => PrintSelectedTag();
        top.Controls.Add(print, 4, 0);

        countLabel.Dock = DockStyle.Fill;
        countLabel.TextAlign = ContentAlignment.MiddleLeft;
        top.Controls.Add(countLabel, 0, 1);
        top.SetColumnSpan(countLabel, 6);

        ConfigureGrid();
        Controls.Add(grid);
        Controls.Add(CreateBottomBar());
        Controls.Add(top);

        Shown += (_, _) => LoadInventory();
        BackButtonHelper.AddBackButton(this);
    }

    private Control CreateBottomBar()
    {
        var bottom = new Panel
        {
            Dock = DockStyle.Bottom,
            Height = 62,
            Padding = new Padding(10)
        };

        var delete = new Button
        {
            Text = "DELETE",
            Width = 180,
            Height = 40,
            Anchor = AnchorStyles.Right | AnchorStyles.Bottom
        };
        delete.Click += (_, _) => DeleteSelected();

        var recentlyDeleted = new Button
        {
            Text = "RECENTLY DELETED",
            Width = 180,
            Height = 40,
            Anchor = AnchorStyles.Right | AnchorStyles.Bottom
        };
        recentlyDeleted.Click += (_, _) =>
        {
            using var form = new RecentlyDeletedForm();
            form.ShowDialog(this);
            LoadInventory();
        };

        void PositionBottomButtons()
        {
            recentlyDeleted.Left = bottom.ClientSize.Width - recentlyDeleted.Width - 10;
            recentlyDeleted.Top = bottom.ClientSize.Height - recentlyDeleted.Height - 10;
            delete.Left = recentlyDeleted.Left - delete.Width - 10;
            delete.Top = recentlyDeleted.Top;
        }

        bottom.Resize += (_, _) => PositionBottomButtons();
        bottom.Controls.Add(delete);
        bottom.Controls.Add(recentlyDeleted);
        PositionBottomButtons();
        return bottom;
    }

    private void ConfigureGrid()
    {
        grid.Dock = DockStyle.Fill;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AutoGenerateColumns = false;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = false;
        grid.RowHeadersVisible = false;
        grid.AllowUserToResizeRows = false;

        grid.Columns.Add(new DataGridViewButtonColumn
        {
            Name = "Expand",
            HeaderText = "",
            Text = "▼",
            UseColumnTextForButtonValue = true,
            FillWeight = 45,
            FlatStyle = FlatStyle.System
        });

        AddColumn("Product", 125);
        AddColumn("Product Code", 100);
        AddColumn("Category", 100);

        if (Session.IsAdmin)
            AddColumn("Purchase Price", 95);

        AddColumn("Quantity", 75);
        AddColumn("Sale Price", 90);
        AddColumn("Status", 90);
        AddColumn("Unit / Tag", 115);
        AddColumn("Added At", 110);

        grid.CellContentClick += Grid_CellContentClick;
        grid.CellDoubleClick += (_, e) =>
        {
            if (e.RowIndex >= 0)
                ToggleGroup(e.RowIndex);
        };
    }

    private void AddColumn(string header, float fillWeight)
    {
        grid.Columns.Add(new DataGridViewTextBoxColumn
        {
            HeaderText = header,
            FillWeight = fillWeight
        });
    }

    private void Grid_CellContentClick(object? sender, DataGridViewCellEventArgs e)
    {
        if (e.RowIndex < 0 || e.ColumnIndex != 0)
            return;

        ToggleGroup(e.RowIndex);
    }

    private void ToggleGroup(int rowIndex)
    {
        if (rowIndex < 0 || rowIndex >= grid.Rows.Count)
            return;

        if (grid.Rows[rowIndex].Tag is not InventoryGroupRow group)
            return;

        group.Expanded = !group.Expanded;
        BindRows();
    }

    private void BindRows()
    {
        grid.Rows.Clear();

        foreach (var group in groups)
        {
            var groupValues = new System.Collections.Generic.List<object>
            {
                group.Expanded ? "▲" : "▼",
                group.ProductName,
                group.ProductCode,
                group.Category
            };

            if (Session.IsAdmin)
                groupValues.Add(group.PurchasePrice.HasValue
                    ? $"Rs. {group.PurchasePrice.Value:N0}"
                    : "Multiple");

            groupValues.Add(group.Quantity.ToString("N0"));
            groupValues.Add(group.SalePrice.HasValue
                ? $"Rs. {group.SalePrice.Value:N0}"
                : "Multiple");
            groupValues.Add(group.Status);
            groupValues.Add(group.Expanded ? "Hide units" : "View units");
            groupValues.Add("");

            var groupRowIndex = grid.Rows.Add(groupValues.ToArray());
            grid.Rows[groupRowIndex].Tag = group;
            grid.Rows[groupRowIndex].DefaultCellStyle.Font = new Font(grid.Font, FontStyle.Bold);

            if (!group.Expanded)
                continue;

            foreach (var unit in group.Units)
            {
                var unitValues = new System.Collections.Generic.List<object>
                {
                    "•",
                    "   ↳ " + unit.ProductName,
                    unit.ProductCode,
                    unit.Category
                };

                if (Session.IsAdmin)
                    unitValues.Add($"Rs. {unit.PurchasePrice:N0}");

                unitValues.Add("—");
                unitValues.Add($"Rs. {unit.SalePrice:N0}");
                unitValues.Add(unit.Status);
                unitValues.Add(unit.UnitCode);
                unitValues.Add(unit.AddedAt.ToString("dd-MMM-yyyy HH:mm"));

                var detailRowIndex = grid.Rows.Add(unitValues.ToArray());
                grid.Rows[detailRowIndex].Tag = unit;
                grid.Rows[detailRowIndex].DefaultCellStyle.Font =
                    new Font(grid.Font, FontStyle.Regular);
                grid.Rows[detailRowIndex].DefaultCellStyle.BackColor =
                    SystemColors.ControlLightLight;
            }
        }
    }

    private void DeleteSelected()
    {
        try
        {
            if (grid.CurrentRow?.Tag is InventoryDetailRow detail)
            {
                if (!string.Equals(detail.Status, "InStock", StringComparison.OrdinalIgnoreCase))
                {
                    MessageBox.Show(
                        "Only an in-stock inventory item can be deleted.",
                        "Cannot Delete",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return;
                }

                var confirm = MessageBox.Show(
                    $"Delete this inventory item?\n\nProduct: {detail.ProductName}\nUnit: {detail.UnitCode}\n\nYou can recover it later from Recently Deleted.",
                    "Confirm Delete",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm != DialogResult.Yes)
                    return;

                service.DeleteInventoryUnit(detail.InventoryUnitId);
                LoadInventory();
                MessageBox.Show(
                    "The selected inventory item was moved to Recently Deleted.",
                    "Deleted",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            if (grid.CurrentRow?.Tag is InventoryGroupRow group)
            {
                if (group.Quantity <= 0)
                {
                    MessageBox.Show(
                        "There are no in-stock units available to delete for this product.",
                        "Cannot Delete",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information);
                    return;
                }

                var confirm = MessageBox.Show(
                    $"Delete all {group.Quantity:N0} in-stock units for this product?\n\nProduct: {group.ProductName}\nProduct Code: {group.ProductCode}\n\nAll of these units will be moved to Recently Deleted and can be recovered later.",
                    "Delete Entire Inventory Group",
                    MessageBoxButtons.YesNo,
                    MessageBoxIcon.Warning);

                if (confirm != DialogResult.Yes)
                    return;

                var deleted = service.DeleteInventoryGroup(group.ProductId);
                LoadInventory();
                MessageBox.Show(
                    $"{deleted:N0} inventory unit(s) were moved to Recently Deleted.",
                    "Deleted",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information);
                return;
            }

            MessageBox.Show(
                "Select a product or an individual inventory unit first.",
                "Select Inventory",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Could not delete the selected inventory item.\n\n" + ex.Message,
                "Delete Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private void PrintSelectedTag()
    {
        if (grid.CurrentRow?.Tag is not InventoryDetailRow detail)
        {
            MessageBox.Show(
                "Expand a product and select an individual unit before printing its tag.",
                "Select a Unit",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        var tag = service.GetTag(detail.UnitCode);
        if (tag == null)
        {
            MessageBox.Show(
                "The selected inventory unit could not be found.",
                "Tag Not Found",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        using var form = new TagPrintForm(new[] { tag });
        form.ShowDialog(this);
    }

    private void LoadInventory()
    {
        try
        {
            groups = service.GetInventoryGroups(searchBox.Text);
            foreach (var group in groups)
                group.Expanded = false;

            BindRows();

            var totalAvailable = groups.Sum(x => x.Quantity);
            countLabel.Text =
                $"Products displayed: {groups.Length:N0}    |    Available units: {totalAvailable:N0}";
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Could not load inventory.\n\n" + ex.Message,
                "Inventory Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
