using System;
using System.Drawing;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class DashboardForm : Form
{
    private readonly Font titleFont = new("Segoe UI", 21, FontStyle.Bold);
    private readonly Font cardFont = new("Segoe UI", 10, FontStyle.Bold);

    public DashboardForm()
    {
        Text = "Shop Management System - Dashboard";
        StartPosition = FormStartPosition.CenterScreen;
        WindowState = FormWindowState.Maximized;
        MinimumSize = new Size(1000, 650);
        Size = new Size(1250, 760);

        if (Session.IsAdmin)
            BuildAdminDashboard();
        else
            BuildStaffDashboard();
    }

    private void BuildAdminDashboard()
    {
        var sidebar = CreateSidebar(
            "ADMIN",
            ("PROFIT REPORT", OpenProfitReport),
            ("KHATA MANAGEMENT", OpenCreditManagement),
            ("SALESMEN", OpenSalesmanManagement),
            ("SALARY MANAGEMENT", OpenUnifiedSalaryManagement),
            ("SALARY HISTORY", OpenSalaryHistory),
            ("EXPENSES", OpenExpenseManagement)
        );

        var content = CreateMainContent("Admin Dashboard", "Management and financial controls");
        var cards = CreateCardGrid(3);

        AddCard(cards, "PROFIT REPORT",
            "Daily, weekly and monthly profit information.",
            0, 0, OpenProfitReport);

        AddCard(cards, "KHATA MANAGEMENT",
            "View customer credit accounts and payment history.",
            1, 0, OpenCreditManagement);

        AddCard(cards, "SALESMEN",
            "Add salesman, automatic code, fixed salary and suit commission settings.",
            0, 1, OpenSalesmanManagement);

        AddCard(cards, "SALARY MANAGEMENT",
            "See every salesman salary, add advances and deduct them automatically.",
            1, 1, OpenUnifiedSalaryManagement);

        AddCard(cards, "SALARY HISTORY",
            "See all salaries that have actually been recorded as paid.",
            0, 2, OpenSalaryHistory);

        AddCard(cards, "EXPENSES",
            "Record electricity, salaries and other shop expenses.",
            1, 2, OpenExpenseManagement);


        content.Controls.Add(cards, 0, 1);
        Controls.Add(content);
        Controls.Add(sidebar);
    }

    private void BuildStaffDashboard()
    {
        var sidebar = CreateSidebar(
            "STAFF",
            ("PRODUCT ENTRY", OpenProductEntry),
            ("INVENTORY", OpenInventory),
            ("SALES", OpenSales),
            ("RETURNS", OpenReturns),
            ("EXCHANGE", OpenExchange),
            ("KHATA / CREDIT", OpenCreditManagement)
        );

        var content = CreateMainContent("Staff Dashboard", "Daily shop operations");
        var cards = CreateCardGrid(4);

        AddCard(cards, "PRODUCT ENTRY",
            "Enter products, quantities and prices, generate QR tags and add stock to inventory.",
            0, 0, OpenProductEntry);

        AddCard(cards, "INVENTORY",
            "View grouped stock quantities and individual tagged units.",
            1, 0, OpenInventory);

        AddCard(cards, "SALES",
            "Scan, search and sell products with customer-specific pricing.",
            2, 0, OpenSales);

        AddCard(cards, "RETURNS",
            "Process tagged product returns and update inventory.",
            0, 1, OpenReturns);

        AddCard(cards, "EXCHANGE",
            "Exchange products while keeping inventory synchronized.",
            1, 1, OpenExchange);

        AddCard(cards, "KHATA / CREDIT",
            "Manage permitted customer credit information and payments.",
            0, 2, OpenCreditManagement);

        content.Controls.Add(cards, 0, 1);
        Controls.Add(content);
        Controls.Add(sidebar);
    }

    private Panel CreateSidebar(string role, params (string Text, Action Action)[] items)
    {
        var sidebar = new Panel
        {
            Dock = DockStyle.Left,
            Width = 235,
            Padding = new Padding(15),
            BackColor = Color.FromArgb(31, 78, 121)
        };

        var menu = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            Padding = new Padding(0, 0, 0, 60),
            BackColor = Color.FromArgb(31, 78, 121)
        };

        menu.Controls.Add(new Label
        {
            Text = $"Awais Shawl\r\n\r\n{role}",
            Height = 115,
            Width = 200,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Brush Script MT", 20, FontStyle.Regular),
            ForeColor = Color.White,
            BackColor = Color.Transparent
        });

        // Keep the logout control separate from the scrollable menu so it is
        // always anchored at the bottom-left of the sidebar.
        var logout = new Button
        {
            Text = "LOGOUT",
            Dock = DockStyle.Bottom,
            Width = 200,
            Height = 45,
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            BackColor = Color.FromArgb(20, 62, 99),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat
        };
        logout.FlatAppearance.BorderColor = Color.FromArgb(120, 175, 220);
        logout.FlatAppearance.BorderSize = 1;
        logout.Click += (_, _) => Close();

        sidebar.Controls.Add(menu);
        sidebar.Controls.Add(logout);
        return sidebar;
    }

    private TableLayoutPanel CreateMainContent(string titleText, string subtitleText)
    {
        var content = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(30),
            ColumnCount = 1,
            RowCount = 2
        };

        content.RowStyles.Add(new RowStyle(SizeType.Absolute, 105));
        content.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var header = new Panel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(5)
        };

        var heading = new Label
        {
            Text = $"Welcome, {Session.CurrentUser?.Username}",
            Dock = DockStyle.Top,
            Height = 48,
            Font = titleFont,
            TextAlign = ContentAlignment.MiddleLeft
        };

        var subtitle = new Label
        {
            Text = subtitleText,
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 10),
            TextAlign = ContentAlignment.MiddleLeft
        };

        header.Controls.Add(subtitle);
        header.Controls.Add(heading);
        content.Controls.Add(header, 0, 0);

        return content;
    }

    private static TableLayoutPanel CreateCardGrid(int rows)
    {
        var grid = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = rows,
            // Admin dashboard: slightly more outer inset keeps the cards 15px
            // smaller while allowing the space between adjacent cards to be reduced.
            Padding = Session.IsAdmin ? new Padding(37) : new Padding(4)
        };

        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));

        for (var i = 0; i < rows; i++)
            grid.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / rows));

        return grid;
    }

    private static void AddButton(FlowLayoutPanel panel, string text, Action action)
    {
        var button = new Button
        {
            Text = text,
            Width = 200,
            Height = 45,
            Margin = new Padding(0, 5, 0, 5),
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            BackColor = Color.FromArgb(31, 78, 121),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat
        };
        button.FlatAppearance.BorderColor = Color.FromArgb(120, 175, 220);
        button.FlatAppearance.BorderSize = 1;
        button.Click += (_, _) => action();
        panel.Controls.Add(button);
    }

    private void AddCard(TableLayoutPanel panel, string title, string description,
        int column, int row, Action action)
    {
        var button = new Button
        {
            Text = $"{title}\r\n\r\n{description}",
            Dock = DockStyle.Fill,
            // UI Fix 27: admin dashboard cards are 25px smaller and adjacent gaps are 15px tighter.
            Margin = Session.IsAdmin
                ? new Padding(32, 32, 33, 33)
                : new Padding(32, 32, 33, 33),
            Font = cardFont,
            TextAlign = ContentAlignment.MiddleCenter,
            UseCompatibleTextRendering = true
        };
        button.Click += (_, _) => action();
        panel.Controls.Add(button, column, row);
    }

    private static void OpenProductEntry()
    {
        if (!AuthorizationService.HasKnownRole)
        {
            MessageBox.Show(
                "Please log in with a valid Staff or Admin account.",
                "Access Required",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        using var form = new ProductEntryForm();
        form.ShowDialog();
    }

    private static void OpenInventory()
    {
        using var form = new InventoryForm();
        form.ShowDialog();
    }

    private static void OpenSales()
    {
        using var form = new SalesForm();
        form.ShowDialog();
    }

    private static void OpenReturns()
    {
        using var form = new ReturnForm();
        form.ShowDialog();
    }

    private static void OpenExchange()
    {
        using var form = new ExchangeForm();
        form.ShowDialog();
    }

    private static void OpenCreditManagement()
    {
        using var form = new CreditManagementForm();
        form.ShowDialog();
    }

    private static void OpenSalesmanManagement()
    {
        using var form = new SalesmanManagementForm();
        form.ShowDialog();
    }

    private static void OpenExpenseManagement()
    {
        if (!Session.IsAdmin)
        {
            MessageBox.Show("Expense management is restricted to administrators.",
                "Admin Access Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        using var form = new ExpenseManagementForm();
        form.ShowDialog();
    }

    private static void OpenUnifiedSalaryManagement()
    {
        if (!Session.IsAdmin)
        {
            MessageBox.Show(
                "Salary management is restricted to administrators.",
                "Admin Access Required",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        using var form = new UnifiedSalaryManagementForm();
        form.ShowDialog();
    }

    private static void OpenSalaryManagement()
    {
        if (!Session.IsAdmin)
        {
            MessageBox.Show("Salary management is restricted to administrators.", "Admin Access Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var form = new SalaryManagementForm();
        form.ShowDialog();
    }

    private static void OpenSalaryAdvances()
    {
        if (!Session.IsAdmin)
        {
            MessageBox.Show("Salary advances are restricted to administrators.", "Admin Access Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var form = new SalaryAdvanceForm();
        form.ShowDialog();
    }

    private static void OpenFinalSalaryCalculation()
    {
        if (!Session.IsAdmin)
        {
            MessageBox.Show("Final salary calculation is restricted to administrators.", "Admin Access Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var form = new FinalSalaryCalculationForm();
        form.ShowDialog();
    }

    private static void OpenSalaryHistory()
    {
        if (!Session.IsAdmin)
        {
            MessageBox.Show("Salary history is restricted to administrators.", "Admin Access Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }
        using var form = new SalaryHistoryForm();
        form.ShowDialog();
    }

    private static void OpenProfitReport()
    {
        if (!Session.IsAdmin)
        {
            MessageBox.Show(
                "Profit reports are restricted to administrators.",
                "Admin Access Required",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        using var form = new ProfitReportForm();
        form.ShowDialog();
    }

    private static void ComingSoon(string module)
    {
        MessageBox.Show(
            $"{module} is reserved for the next development step.\r\n\r\nStep 11 has redesigned the Admin dashboard; this module will be connected later without changing the dashboard structure.",
            module,
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
    }
}
