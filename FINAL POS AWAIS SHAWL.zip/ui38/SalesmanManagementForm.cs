using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

/// <summary>
/// Step 30: one simple place for salesman registration, fixed salary and suit commission setup.
/// </summary>
public class SalesmanManagementForm : Form
{
    private readonly SalesmanService salesmanService = new();
    private readonly SalaryService salaryService = new();
    private readonly TextBox nameBox = new();
    private readonly Label codePreview = new();
    private readonly Label datePreview = new();
    private readonly NumericUpDown salaryBox = new();
    private readonly ComboBox salesmanCombo = new();
    private readonly ComboBox productCombo = new();
    private readonly NumericUpDown percentageBox = new();
    private readonly CheckBox selectAllBox = new();
    private readonly Label selectedCode = new();
    private readonly DataGridView grid = new();

    public SalesmanManagementForm()
    {
        if (!AuthorizationService.RequireAdmin(this, "Salesman management")) return;
        Text = "Salesmen";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1180, 780);
        MinimumSize = new Size(1000, 680);
        BuildUi();
        LoadData();
        BackButtonHelper.AddBackButton(this);
    }

    private void BuildUi()
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(18), ColumnCount = 1, RowCount = 4 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 145));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 205));
        root.Controls.Add(Header("SALESMAN"), 0, 0);
        root.Controls.Add(BuildRegistrationPanel(), 0, 1);
        ConfigureGrid(); root.Controls.Add(grid, 0, 2);
        root.Controls.Add(BuildSettingsPanel(), 0, 3);
        Controls.Add(root);
    }

    private static Label Header(string text) => new()
    {
        Text = text, Dock = DockStyle.Fill, Font = new Font("Segoe UI", 16, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft
    };

    private Control BuildRegistrationPanel()
    {
        var p = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 5, RowCount = 2, Padding = new Padding(0, 4, 0, 4) };
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 105));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25));
        p.Controls.Add(LabelOf("NAME"), 0, 0);
        nameBox.Dock = DockStyle.Fill; nameBox.PlaceholderText = "Salesman name"; p.Controls.Add(nameBox, 1, 0);

        // Keep both action buttons exactly the same size as the SAVE SETTINGS button.
        // Place them directly after the NAME field so their left edge follows the name placeholder field.
        var add = new Button { Text = "ADD", Size = new Size(150, 32), Anchor = AnchorStyles.None, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        add.Click += (_, _) => AddSalesman(); p.Controls.Add(add, 2, 0);

        var delete = new Button { Text = "DELETE", Size = new Size(150, 32), Anchor = AnchorStyles.None, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        delete.Click += (_, _) => DeleteSelectedSalesman(); p.Controls.Add(delete, 3, 0);

        // Show the generated/current code directly below NAME.
        p.Controls.Add(LabelOf("CODE"), 0, 1);
        codePreview.Dock = DockStyle.Fill; codePreview.Font = new Font("Segoe UI", 11, FontStyle.Bold); codePreview.TextAlign = ContentAlignment.MiddleLeft; p.Controls.Add(codePreview, 1, 1);

        var datePanel = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2, Margin = new Padding(0) };
        datePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 45));
        datePanel.RowStyles.Add(new RowStyle(SizeType.Percent, 55));
        var dateLabel = LabelOf("DATE");
        dateLabel.TextAlign = ContentAlignment.BottomRight;
        datePanel.Controls.Add(dateLabel, 0, 0);
        datePreview.Dock = DockStyle.Fill; datePreview.TextAlign = ContentAlignment.TopRight;
        datePanel.Controls.Add(datePreview, 0, 1);
        p.Controls.Add(datePanel, 4, 0); p.SetRowSpan(datePanel, 2);
        return p;
    }

    private Control BuildSettingsPanel()
    {
        var group = new GroupBox { Text = "SELECT SALESMAN → SET SALARY → SET SUIT COMMISSION", Dock = DockStyle.Fill, Padding = new Padding(12) };
        var p = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 6, RowCount = 3 };
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 95));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 80));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 27));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
        p.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 30));

        p.Controls.Add(LabelOf("SALESMAN"), 0, 0);
        salesmanCombo.Dock = DockStyle.Fill; salesmanCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        salesmanCombo.SelectedIndexChanged += (_, _) => UpdateSelected(); p.Controls.Add(salesmanCombo, 1, 0);
        p.Controls.Add(LabelOf("CODE"), 2, 0); selectedCode.Dock = DockStyle.Fill; selectedCode.Font = new Font("Segoe UI", 10, FontStyle.Bold); p.Controls.Add(selectedCode, 3, 0);
        p.Controls.Add(LabelOf("SALARY"), 4, 0);
        salaryBox.Dock = DockStyle.Fill; salaryBox.DecimalPlaces = 0; salaryBox.Maximum = 100000000; salaryBox.ThousandsSeparator = true; salaryBox.Text = string.Empty; salaryBox.Enter += (_, _) => { if (salaryBox.Value == 0) salaryBox.Text = string.Empty; }; salaryBox.MouseDown += (_, _) => { if (salaryBox.Value == 0) salaryBox.Text = string.Empty; }; p.Controls.Add(salaryBox, 5, 0);

        p.Controls.Add(LabelOf("SUIT / ITEM"), 0, 1);
        productCombo.Dock = DockStyle.Fill; productCombo.DropDownStyle = ComboBoxStyle.DropDownList; p.Controls.Add(productCombo, 1, 1);
        p.Controls.Add(LabelOf("COMMISSION %"), 2, 1);
        percentageBox.Dock = DockStyle.Fill; percentageBox.DecimalPlaces = 2; percentageBox.Increment = .5m; percentageBox.Maximum = 100; percentageBox.Text = string.Empty; percentageBox.Enter += (_, _) => { if (percentageBox.Value == 0) percentageBox.Text = string.Empty; }; percentageBox.MouseDown += (_, _) => { if (percentageBox.Value == 0) percentageBox.Text = string.Empty; }; p.Controls.Add(percentageBox, 3, 1);
        selectAllBox.Text = "SELECT ALL ITEMS"; selectAllBox.Dock = DockStyle.Fill; selectAllBox.TextAlign = ContentAlignment.MiddleLeft; p.Controls.Add(selectAllBox, 4, 1);
        var save = new Button { Text = "SAVE SETTINGS", Size = new Size(150, 32), Anchor = AnchorStyles.Right, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
        save.Click += (_, _) => SaveSettings(); p.Controls.Add(save, 5, 1);

        var note = new Label { Text = "If Select All Items is checked, the entered percentage is applied to every current product. Otherwise it applies only to the selected suit/item.", Dock = DockStyle.Fill, AutoEllipsis = true, TextAlign = ContentAlignment.MiddleLeft };
        p.Controls.Add(note, 0, 2); p.SetColumnSpan(note, 6);
        group.Controls.Add(p); return group;
    }

    private void ConfigureGrid()
    {
        grid.Dock = DockStyle.Fill; grid.ReadOnly = true; grid.AllowUserToAddRows = false; grid.AutoGenerateColumns = false; grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill; grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; grid.MultiSelect = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Name", HeaderText = "SALESMAN" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Code", HeaderText = "CODE" });
        grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "Salary", HeaderText = "FIXED SALARY", DefaultCellStyle = new DataGridViewCellStyle { Format = "#,##0.##" } });
        grid.Columns.Add(new DataGridViewTextBoxColumn { DataPropertyName = "CreatedAt", HeaderText = "ADDED DATE / TIME", DefaultCellStyle = new DataGridViewCellStyle { Format = "dd-MMM-yyyy hh:mm tt" } });
        grid.Columns.Add(new DataGridViewCheckBoxColumn { DataPropertyName = "IsActive", HeaderText = "ACTIVE" });
    }

    private void LoadData()
    {
        using var db = new ShopDbContext();
        var salesmen = db.Salesmen.AsNoTracking().OrderBy(x => x.Name).ToList();
        var salaries = db.StaffSalaries.AsNoTracking().ToDictionary(x => x.SalesmanId, x => x.MonthlySalary);
        grid.DataSource = salesmen.Select(s => new { s.Name, s.Code, Salary = salaries.GetValueOrDefault(s.SalesmanId, 0m), s.CreatedAt, s.IsActive }).ToList();
        var active = salesmen.Where(x => x.IsActive).ToList();
        salesmanCombo.DataSource = active; salesmanCombo.DisplayMember = "Name"; salesmanCombo.ValueMember = "SalesmanId";
        productCombo.DataSource = db.Products.AsNoTracking().OrderBy(x => x.ProductName).ToList(); productCombo.DisplayMember = "ProductName"; productCombo.ValueMember = "ProductId";
        codePreview.Text = salesmanService.GenerateNextCode(); datePreview.Text = DateTime.Now.ToString("dd-MMM-yyyy hh:mm tt");
        UpdateSelected();
    }

    private void AddSalesman()
    {
        try
        {
            var s = salesmanService.AddSalesman(nameBox.Text);
            MessageBox.Show($"Salesman added successfully.\r\n\r\nName: {s.Name}\r\nCode: {s.Code}\r\nAdded: {s.CreatedAt:dd-MMM-yyyy hh:mm:ss tt}", "Salesman Added", MessageBoxButtons.OK, MessageBoxIcon.Information);
            nameBox.Clear(); LoadData();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Could Not Add Salesman", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }


    private void DeleteSelectedSalesman()
    {
        if (grid.CurrentRow == null)
        {
            MessageBox.Show("Select a salesman from the list first.", "Delete Salesman", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var code = grid.CurrentRow.Cells[1].Value?.ToString();
        var name = grid.CurrentRow.Cells[0].Value?.ToString();
        if (string.IsNullOrWhiteSpace(code))
        {
            MessageBox.Show("Could not identify the selected salesman.", "Delete Salesman", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var confirm = MessageBox.Show(
            $"Are you sure you want to delete salesman '{name}' (Code: {code})?\r\n\r\nThis will remove the salesman and related salary/commission records. Existing sales history will remain.",
            "Delete Salesman", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
        if (confirm != DialogResult.Yes) return;

        try
        {
            salesmanService.DeleteSalesmanByCode(code);
            MessageBox.Show("Salesman deleted successfully.", "Delete Salesman", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadData();
        }
        catch (Exception ex)
        {
            MessageBox.Show(ex.Message, "Could Not Delete Salesman", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        }
    }

    private void SaveSettings()
    {
        if (salesmanCombo.SelectedValue == null) { MessageBox.Show("Select a salesman first."); return; }
        try
        {
            var id = Convert.ToInt32(salesmanCombo.SelectedValue);
            salaryService.SetMonthlySalary(id, salaryBox.Value);
            if (selectAllBox.Checked)
            {
                using var db = new ShopDbContext();
                var products = db.Products.AsNoTracking().Select(x => x.ProductId).ToList();
                foreach (var productId in products) salesmanService.SetCommission(id, productId, percentageBox.Value);
            }
            else if (productCombo.SelectedValue != null)
            {
                salesmanService.SetCommission(id, Convert.ToInt32(productCombo.SelectedValue), percentageBox.Value);
            }
            MessageBox.Show("Salary and commission settings saved.", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);
            LoadData();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Could Not Save", MessageBoxButtons.OK, MessageBoxIcon.Warning); }
    }

    private void UpdateSelected()
    {
        if (salesmanCombo.SelectedItem is not Salesman s) { selectedCode.Text = "---"; return; }
        selectedCode.Text = s.Code;
        using var db = new ShopDbContext();
        salaryBox.Value = Math.Min(salaryBox.Maximum, db.StaffSalaries.AsNoTracking().Where(x => x.SalesmanId == s.SalesmanId).Select(x => (decimal?)x.MonthlySalary).FirstOrDefault() ?? 0m);
    }

    private static Label LabelOf(string text) => new() { Text = text, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) };
}
