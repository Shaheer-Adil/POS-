using System;
using System.Drawing;
using System.Windows.Forms;

namespace ShopManagementSystem;

public class CreditSaleDialog : Form
{
    private readonly TextBox nameBox = new();
    private readonly TextBox phoneBox = new();
    private readonly NumericUpDown paidBox = new();
    private readonly Label outstandingLabel = new();
    public string CustomerName => nameBox.Text.Trim();
    public string PhoneNumber => phoneBox.Text.Trim();
    public decimal AmountPaid => paidBox.Value;

    public CreditSaleDialog(decimal total)
    {
        Text = "Credit / Khata Sale";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(520, 360);
        Size = new Size(560, 390);
        var grid = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(25), ColumnCount = 2, RowCount = 6 };
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));
        grid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        AddRow(grid, "TOTAL BILL", new Label { Text = $"Rs. {total:N0}", Dock = DockStyle.Fill, Font = new Font("Segoe UI", 12, FontStyle.Bold) }, 0);
        nameBox.Dock = DockStyle.Fill; nameBox.PlaceholderText = "Customer name"; AddRow(grid, "CUSTOMER NAME *", nameBox, 1);
        phoneBox.Dock = DockStyle.Fill; phoneBox.PlaceholderText = "Phone number (recommended)"; AddRow(grid, "PHONE", phoneBox, 2);
        paidBox.Dock = DockStyle.Fill; paidBox.DecimalPlaces = 0; paidBox.Maximum = total; paidBox.ThousandsSeparator = true; paidBox.Text = string.Empty; paidBox.Enter += (_, _) => { if (paidBox.Value == 0) paidBox.Text = string.Empty; }; paidBox.MouseDown += (_, _) => { if (paidBox.Value == 0) paidBox.Text = string.Empty; }; paidBox.ValueChanged += (_, _) => UpdateOutstanding(total); AddRow(grid, "PAID NOW", paidBox, 3);
        outstandingLabel.Dock = DockStyle.Fill; outstandingLabel.Font = new Font("Segoe UI", 11, FontStyle.Bold); AddRow(grid, "OUTSTANDING", outstandingLabel, 4);
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.RightToLeft };
        var ok = new Button { Text = "SAVE CREDIT SALE", Width = 150, Height = 40 };
        ok.Click += (_, _) => { if (string.IsNullOrWhiteSpace(CustomerName)) { MessageBox.Show("Customer name is required.", "Missing Customer", MessageBoxButtons.OK, MessageBoxIcon.Warning); return; } if (AmountPaid >= total) { MessageBox.Show("This bill is fully paid. Use a normal cash sale instead.", "Not a Credit Sale", MessageBoxButtons.OK, MessageBoxIcon.Information); return; } DialogResult = DialogResult.OK; Close(); };
        var cancel = new Button { Text = "CANCEL", Width = 100, Height = 40 }; cancel.Click += (_, _) => { DialogResult = DialogResult.Cancel; Close(); };
        buttons.Controls.Add(ok); buttons.Controls.Add(cancel); grid.Controls.Add(buttons, 0, 5); grid.SetColumnSpan(buttons, 2);
        Controls.Add(grid); UpdateOutstanding(total);
    }
    private void UpdateOutstanding(decimal total) => outstandingLabel.Text = $"Rs. {total - paidBox.Value:N0}";
    private static void AddRow(TableLayoutPanel grid, string label, Control control, int row) { grid.RowStyles.Add(new RowStyle(SizeType.Absolute, 48)); grid.Controls.Add(new Label { Text = label, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) }, 0, row); grid.Controls.Add(control, 1, row); }
}
