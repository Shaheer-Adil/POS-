# UI Fix 39

Updated the software-wide numeric display formatting so trailing `.00` is removed from values shown in the UI, reports, messages, salary/expense/credit screens, and other monetary displays.

Examples:
- `500.00` -> `500`
- `1,250.00` -> `1,250`

Formatting now uses up to two decimal places without unnecessary trailing zeroes where decimal values are supported. Monetary input controls that previously displayed `.00` now display whole values.

No other functionality was intentionally changed.
