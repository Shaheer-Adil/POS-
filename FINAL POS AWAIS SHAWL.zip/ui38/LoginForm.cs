using System.Drawing;
using System.Drawing.Drawing2D;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class LoginForm : Form
{
    private readonly TextBox usernameBox = new();
    private readonly TextBox passwordBox = new();
    private readonly AuthenticationService authService = new();
    private readonly Button passwordToggle = new();

    public LoginForm()
    {
        Text = "Awais Shall - Login";
        StartPosition = FormStartPosition.CenterScreen;
        ClientSize = new Size(920, 620);
        MinimumSize = new Size(820, 560);
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        BackColor = Color.FromArgb(244, 247, 251);

        var header = new Panel
        {
            Dock = DockStyle.Top,
            Height = 145,
            BackColor = Color.FromArgb(31, 78, 121)
        };
        header.Paint += (s, e) =>
        {
            using var brush = new LinearGradientBrush(header.ClientRectangle,
                Color.FromArgb(31, 78, 121), Color.FromArgb(45, 112, 166), 0f);
            e.Graphics.FillRectangle(brush, header.ClientRectangle);
        };

        var title = new Label
        {
            Text = "Awais Shall",
            Dock = DockStyle.Top,
            Height = 88,
            TextAlign = ContentAlignment.BottomCenter,
            Font = new Font("Palatino Linotype", 32, FontStyle.Bold),
            ForeColor = Color.White,
            BackColor = Color.Transparent
        };
        var subtitle = new Label
        {
            Text = "SHOP MANAGEMENT SYSTEM",
            Dock = DockStyle.Top,
            Height = 45,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 10, FontStyle.Bold),
            ForeColor = Color.FromArgb(220, 235, 248),
            BackColor = Color.Transparent
        };
        header.Controls.Add(subtitle);
        header.Controls.Add(title);

        var card = new Panel
        {
            Size = new Size(540, 355),
            BackColor = Color.White,
            Anchor = AnchorStyles.None,
            BorderStyle = BorderStyle.FixedSingle
        };
        card.Paint += (s, e) =>
        {
            using var pen = new Pen(Color.FromArgb(220, 226, 233));
            e.Graphics.DrawRectangle(pen, 0, 0, card.Width - 1, card.Height - 1);
        };

        var cardTitle = new Label
        {
            Text = "Sign in to continue",
            Location = new Point(40, 25),
            Size = new Size(460, 58),
            TextAlign = ContentAlignment.MiddleCenter,
            AutoEllipsis = false,
            Font = new Font("Segoe UI Semibold", 18, FontStyle.Bold),
            ForeColor = Color.FromArgb(38, 50, 56)
        };
        card.Controls.Add(cardTitle);

        AddField(card, "Username", usernameBox, 100);
        AddField(card, "Password", passwordBox, 175);
        passwordBox.UseSystemPasswordChar = true;

        passwordToggle.Text = "👁";
        passwordToggle.Location = new Point(488, 175);
        passwordToggle.Size = new Size(42, 42);
        passwordToggle.FlatStyle = FlatStyle.Flat;
        passwordToggle.FlatAppearance.BorderSize = 0;
        passwordToggle.BackColor = Color.White;
        passwordToggle.ForeColor = Color.FromArgb(31, 78, 121);
        passwordToggle.Font = new Font("Segoe UI Emoji", 13, FontStyle.Regular);
        passwordToggle.Cursor = Cursors.Hand;
        passwordToggle.TabStop = false;
        passwordToggle.AccessibleName = "Show or hide password";
        passwordToggle.Click += (_, _) =>
        {
            passwordBox.UseSystemPasswordChar = !passwordBox.UseSystemPasswordChar;
            passwordToggle.Text = "👁";
            passwordBox.Focus();
        };
        card.Controls.Add(passwordToggle);

        var login = new Button
        {
            Text = "LOGIN",
            Location = new Point(135, 260),
            Size = new Size(270, 54),
            FlatStyle = FlatStyle.Flat,
            BackColor = Color.FromArgb(31, 78, 121),
            ForeColor = Color.White,
            Font = new Font("Segoe UI Semibold", 13, FontStyle.Bold),
            Cursor = Cursors.Hand
        };
        login.FlatAppearance.BorderSize = 0;
        login.Click += Login_Click;
        card.Controls.Add(login);

        var hint = new Label
        {
            Text = "Authorized Admin and Staff access only",
            Location = new Point(40, 325),
            Size = new Size(460, 25),
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 9),
            ForeColor = Color.FromArgb(120, 130, 140)
        };
        card.Controls.Add(hint);

        var content = new Panel { Dock = DockStyle.Fill, BackColor = Color.FromArgb(244, 247, 251) };
        content.Controls.Add(card);
        content.Resize += (s, e) =>
        {
            card.Left = (content.ClientSize.Width - card.Width) / 2;
            card.Top = Math.Max(25, (content.ClientSize.Height - card.Height) / 2);
        };

        Controls.Add(content);
        Controls.Add(header);
        AcceptButton = login;
    }

    private static void AddField(Control parent, string labelText, TextBox box, int top)
    {
        var label = new Label
        {
            Text = labelText,
            Location = new Point(55, top),
            Size = new Size(130, 42),
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI Semibold", 11, FontStyle.Bold),
            ForeColor = Color.FromArgb(65, 75, 85)
        };
        parent.Controls.Add(label);

        box.Location = new Point(185, top);
        box.Size = new Size(300, 42);
        box.Font = new Font("Segoe UI", 12);
        box.BorderStyle = BorderStyle.FixedSingle;
        box.Margin = new Padding(0);
        parent.Controls.Add(box);
    }

    private void Login_Click(object? sender, System.EventArgs e)
    {
        var username = usernameBox.Text.Trim();
        var password = passwordBox.Text;

        if (string.IsNullOrWhiteSpace(username) || string.IsNullOrEmpty(password))
        {
            MessageBox.Show("Please enter both username and password.", "Login Required",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        try
        {
            var user = authService.Authenticate(username, password);
            if (user == null)
            {
                MessageBox.Show("Invalid username or password, or the account is inactive.",
                    "Login Failed", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                passwordBox.Clear();
                passwordBox.Focus();
                return;
            }

            if (!string.Equals(user.Role, "Admin", System.StringComparison.OrdinalIgnoreCase) &&
                !string.Equals(user.Role, "Staff", System.StringComparison.OrdinalIgnoreCase))
            {
                MessageBox.Show("This account has an invalid role and cannot access the application.",
                    "Access Denied", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Session.CurrentUser = user;
            Hide();
            using var dashboard = new DashboardForm();
            dashboard.ShowDialog();
            Session.Clear();
            passwordBox.Clear();
            usernameBox.Clear();
            Show();
        }
        catch (System.Exception ex)
        {
            MessageBox.Show("An error occurred while checking your credentials.\n\n" + ex.Message,
                "Authentication Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }
}
