# UI Fix 30

## Inventory delete and recovery

- Added a **DELETE** button at the top-right of the Staff Inventory page.
- Selecting an individual inventory unit and pressing DELETE moves only that unit to `Deleted`.
- Selecting a product/group row and pressing DELETE moves all of that product's **InStock** inventory units to `Deleted`.
- Deleted inventory remains in the database as a soft delete so it can be recovered.
- Added **RECENTLY DELETED** at the bottom-right of the Inventory page.
- Recently Deleted shows deleted products/units and provides **RECOVER**.
- Recovering an individual unit restores only that unit.
- Recovering a product/group restores all deleted units for that product.
- Normal Inventory hides deleted units.
- Sales history and existing references are preserved because inventory rows are not physically removed.

No images were added or generated.
