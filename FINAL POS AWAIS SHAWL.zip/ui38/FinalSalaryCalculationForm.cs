using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

/// <summary>
/// Step 21 - Final Salary Calculation. Admin-only payroll calculation for a selected month.
/// </summary>
public class FinalSalaryCalculationForm : Form
{
    private readonly SalaryService service = new();
    private readonly DateTimePicker monthPicker = new();
    private readonly DataGridView salaryGrid = new();
    private readonly Label fixedTotalLabel = new();
    private readonly Label commissionTotalLabel = new();
    private readonly Label advanceTotalLabel = new();
    private readonly Label payableTotalLabel = new();
    private readonly Label selectedDetailLabel = new();

    public FinalSalaryCalculationForm()
    {
        if (!Session.IsAdmin)
        {
            MessageBox.Show("Final salary calculation is restricted to administrators.", "Admin Access Required", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Close();
            return;
        }

        Text = "Final Salary Calculation";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1220, 760);
        MinimumSize = new Size(1050, 650);
        BuildUi();
        monthPicker.Value = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
        LoadCalculations();
            BackButtonHelper.AddBackButton(this);
}

    private void BuildUi()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(18),
            ColumnCount = 1,
            RowCount = 5
        };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 55));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 105));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 72));

        root.Controls.Add(new Label
        {
            Text = "FINAL SALARY CALCULATION\r\nFixed Salary + Commission − Advances = Final Payable",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 15, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        }, 0, 0);

        var filter = new FlowLayoutPanel { Dock = DockStyle.Fill, WrapContents = false, Padding = new Padding(4) };
        filter.Controls.Add(new Label { Text = "PAYROLL MONTH", AutoSize = true, Margin = new Padding(5, 9, 8, 0), Font = new Font("Segoe UI", 9, FontStyle.Bold) });
        monthPicker.Format = DateTimePickerFormat.Custom;
        monthPicker.CustomFormat = "MMMM yyyy";
        monthPicker.ShowUpDown = true;
        monthPicker.Width = 170;
        monthPicker.ValueChanged += (_, _) => LoadCalculations();
        filter.Controls.Add(monthPicker);
        var refresh = new Button { Text = "REFRESH", Width = 100, Height = 30, Margin = new Padding(15, 3, 0, 0) };
        refresh.Click += (_, _) => LoadCalculations();
        filter.Controls.Add(refresh);
        root.Controls.Add(filter, 0, 1);

        var totals = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, Padding = new Padding(0, 6, 0, 6) };
        AddStat(totals, 0, "FIXED SALARIES", fixedTotalLabel);
        AddStat(totals, 1, "COMMISSION", commissionTotalLabel);
        AddStat(totals, 2, "ADVANCES", advanceTotalLabel);
        AddStat(totals, 3, "FINAL PAYABLE", payableTotalLabel);
        root.Controls.Add(totals, 0, 2);

        ConfigureGrid();
        salaryGrid.SelectionChanged += (_, _) => ShowSelectedDetail();
        root.Controls.Add(salaryGrid, 0, 3);

        selectedDetailLabel.Dock = DockStyle.Fill;
        selectedDetailLabel.BorderStyle = BorderStyle.FixedSingle;
        selectedDetailLabel.Padding = new Padding(10);
        selectedDetailLabel.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        selectedDetailLabel.Text = "Select an employee to see the final salary calculation.";
        root.Controls.Add(selectedDetailLabel, 0, 4);

        Controls.Add(root);
    }

    private static void AddStat(TableLayoutPanel panel, int col, string title, Label value)
    {
        var box = new Panel { Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(5), Padding = new Padding(8) };
        var titleLabel = new Label { Text = title, Dock = DockStyle.Top, Height = 23, Font = new Font("Segoe UI", 8, FontStyle.Bold) };
        value.Text = "Rs. 0";
        value.Dock = DockStyle.Fill;
        value.Font = new Font("Segoe UI", 12, FontStyle.Bold);
        value.TextAlign = ContentAlignment.MiddleLeft;
        box.Controls.Add(value);
        box.Controls.Add(titleLabel);
        panel.Controls.Add(box, col, 0);
    }

    private void ConfigureGrid()
    {
        salaryGrid.Dock = DockStyle.Fill;
        salaryGrid.ReadOnly = true;
        salaryGrid.AllowUserToAddRows = false;
        salaryGrid.AutoGenerateColumns = false;
        salaryGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        salaryGrid.MultiSelect = false;
        salaryGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        salaryGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Name", HeaderText = "EMPLOYEE", FillWeight = 22 });
        salaryGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Code", HeaderText = "CODE", FillWeight = 10 });
        salaryGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Fixed", HeaderText = "FIXED SALARY", FillWeight = 17 });
        salaryGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Commission", HeaderText = "COMMISSION", FillWeight = 17 });
        salaryGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Advances", HeaderText = "ADVANCES", FillWeight = 15 });
        salaryGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Payable", HeaderText = "FINAL PAYABLE", FillWeight = 19 });
    }

    private void LoadCalculations()
    {
        if (!Session.IsAdmin) return;
        try
        {
            var rows = service.GetFinalSalarySummaries(monthPicker.Value);
            salaryGrid.Rows.Clear();
            decimal fixedTotal = 0, commissionTotal = 0, advanceTotal = 0, payableTotal = 0;

            foreach (var row in rows)
            {
                fixedTotal += row.FixedSalary;
                commissionTotal += row.Commission;
                advanceTotal += row.Advances;
                payableTotal += row.FinalPayable;

                var index = salaryGrid.Rows.Add(
                    row.Name,
                    row.Code,
                    $"Rs. {row.FixedSalary:#,##0.##}",
                    $"Rs. {row.Commission:#,##0.##}",
                    $"Rs. {row.Advances:#,##0.##}",
                    $"Rs. {row.FinalPayable:#,##0.##}");
                salaryGrid.Rows[index].Tag = row;
            }

            fixedTotalLabel.Text = $"Rs. {fixedTotal:#,##0.##}";
            commissionTotalLabel.Text = $"Rs. {commissionTotal:#,##0.##}";
            advanceTotalLabel.Text = $"Rs. {advanceTotal:#,##0.##}";
            payableTotalLabel.Text = $"Rs. {payableTotal:#,##0.##}";
            ShowSelectedDetail();
        }
        catch (Exception ex)
        {
            MessageBox.Show("Could not calculate final salaries.\r\n\r\n" + ex.Message, "Final Salary Calculation", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    private void ShowSelectedDetail()
    {
        if (salaryGrid.SelectedRows.Count == 0 || salaryGrid.SelectedRows[0].Tag is not FinalSalarySummary row)
        {
            selectedDetailLabel.Text = "Select an employee to see the final salary calculation.";
            return;
        }

        selectedDetailLabel.Text =
            $"{row.Name} ({row.Code})   |   {monthPicker.Value:MMMM yyyy}\r\n" +
            $"Fixed Salary: Rs. {row.FixedSalary:#,##0.##}    +    Commission: Rs. {row.Commission:#,##0.##}    −    Advances: Rs. {row.Advances:#,##0.##}    =    FINAL PAYABLE: Rs. {row.FinalPayable:#,##0.##}";
    }
}
