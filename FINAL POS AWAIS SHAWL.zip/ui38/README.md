
## Step 20 — Salary History

Admin can select an active salesman/staff member and review salary history for a date range. The module shows monthly fixed salary, commission, advances, calculated remaining salary, and a permanent advance transaction list including date/time, amount, paid-by user, and notes.

# Shop Management System — Step 3

## Implemented in Step 3
- Product Entry form
- Product name
- Category
- Quantity
- Purchase price
- Default sale price
- Validation that sale price cannot be lower than purchase price
- Product master records
- Individual inventory-unit records for every quantity
- Unique product codes (`PRD-000001`, etc.)
- Unique physical unit/tag codes (`UNIT-000001-0001`, etc.)
- Inventory screen with search and refresh
- Inventory table with product/unit codes, prices, status and date
- Adaptive layout using Dock, Anchor/TableLayoutPanel/FlowLayoutPanel
- Dashboard cards and improved sizing behavior

## Important QR note
Step 3 generates unique unit/tag identifiers and stores them in the database.
Step 4 will turn those identifiers into QR images and implement printable sticker/tag sheets.

## Database compatibility
Step 2 used `EnsureCreated()`. Step 3 therefore safely creates the new Products and InventoryUnits tables with SQL if they do not already exist, without deleting the existing Users/database data.

## Test
1. Run the application.
2. Login with:
   - Admin: `admin` / `admin123`
   - Staff: `staff` / `staff123`
3. Open Product Entry.
4. Example:
   - Product: Shirt
   - Category: Clothing
   - Quantity: 50
   - Purchase Price: 1500
   - Sale Price: 2000
5. Click Add to Inventory.
6. Open Inventory.
7. You should see 50 individual units, each with a unique Unit/Tag Code.

## Step 4 implemented
- QR code generation using QRCoder
- QR content is the exact unique inventory unit code
- Automatic prompt to print tags after a new product batch is added
- Print Preview
- A4-style portrait sticker sheet
- 3 columns × 8 rows (24 tags per page)
- Multiple pages automatically supported
- Product name, unit code and default sale price printed on each tag
- Print a single selected tag from Inventory
- QR tags are linked to the exact inventory unit stored in SQL Server

## Step 5 updated — Sales, Billing & Secure Product Lookup
- Sales screen
- QR/tag scanner support
- Exact unit-number lookup
- Fallback search by product name or product code when QR is damaged/unreadable
- Search results show available physical units so staff can select the exact unit
- Double-click a search result to add it to the bill
- Staff cannot see purchase prices on the Sales screen or bill
- Admin can see purchase prices after Admin authentication
- Customer-specific sale price override
- Sale price cannot be lower than purchase price
- Duplicate physical-unit protection
- Automatic bill total
- Sale history preserves purchase price and actual customer sale price for admin reporting
- Sold units are marked `Sold`
- Final transaction re-checks stock status before completing a sale
- Responsive sales interface

### Important security behavior
**Staff login:**
- Can scan/search products
- Can see product name, unit number, and sale price
- Can create bills
- Cannot see purchase price

**Admin login:**
- Can do the above
- Can also see purchase price on the Sales screen and bill
- Future profit reports remain Admin-only

### Damaged QR workflow
If the QR/tag cannot be scanned:
1. Type the unit number, product code, or product name in `SCAN / SEARCH`.
2. Press Enter or click `SEARCH / ADD`.
3. If the search returns several available units, they appear in the `AVAILABLE MATCHES` list.
4. Select the exact physical unit and double-click it.
5. It is added to the bill normally.

## Step 6 implemented — Customer Returns

The return module now supports:

- Return by scanning the original QR/tag.
- Manual search by unit/tag number if the QR is damaged.
- Search by product name.
- Search by product code.
- Search results contain the exact physical inventory units that were previously sold.
- Staff cannot see purchase price.
- Admin can see purchase price.
- Original invoice is shown.
- Original customer sale price is shown.
- Optional return reason.
- Confirmation before changing stock.
- Exact physical unit is restored from `Sold` to `InStock`.
- A return record is stored permanently.
- Original customer sale price is preserved for audit/profit calculations.
- A physical unit cannot be returned twice.
- An unsold/in-stock unit cannot be returned through the return module.
- Return processing uses a database transaction to protect stock integrity.

### Return workflow

1. Open `RETURNS`.
2. Scan the returned product's QR/tag.
3. If the QR is damaged, enter the unit number.
4. If the unit number is unavailable, type the product name/code.
5. Select the exact sold unit from the results.
6. Optionally enter a return reason.
7. Click `PROCESS RETURN`.
8. Confirm.
9. The exact unit changes from `Sold` to `InStock`.
10. The original sale price remains stored in the return history.

### Important stock rule

A returned item is not treated as a brand-new product. The same physical inventory unit is restored. Its original unit code remains unchanged. This prevents stock duplication or mixing.

## Step 7 implemented — Product Exchange

The exchange module now supports:

- Scan the original customer's tagged product.
- Search the original product by unit/tag number if QR scanning fails.
- Search the original product by product name or product code.
- Only previously sold units that have not already been returned/exchanged can be selected as the original.
- Search replacement inventory by QR/tag number, product name, or product code.
- Only `InStock` physical units can be used as replacements.
- Select the exact replacement physical unit.
- Customer-specific replacement sale price.
- Replacement sale price cannot be lower than the replacement unit's purchase price.
- Calculate price difference automatically.
- If replacement price is higher, customer pays the difference.
- If replacement price is lower, the system shows the refund/difference.
- If prices are equal, no price difference exists.
- Original physical unit changes from `Sold` to `InStock`.
- Replacement physical unit changes from `InStock` to `Sold`.
- Original and replacement unit codes are permanently recorded together.
- Original sale price and replacement sale price are preserved.
- Optional exchange reason.
- Staff cannot see purchase price.
- Admin can see purchase price.
- Database transaction protects both stock changes as one operation.
- The same physical unit cannot be used as both original and replacement.
- The exchange is permanently auditable for future reports.

### Exchange stock flow

`Original SOLD unit → IN STOCK`

`Replacement IN STOCK unit → SOLD`

This keeps the exact physical stock units under control and prevents stock duplication.

### Price difference

`Replacement customer price - Original customer price`

- Positive → customer pays additional amount.
- Negative → customer receives the difference/refund.
- Zero → no difference.

## Next step

Step 8 — Daily, Weekly & Monthly Profit Reports (Admin-only):
- Daily profit
- Weekly profit
- Monthly profit
- Sales totals
- Purchase-cost totals
- Returns/exchanges adjustment
- Actual customer sale prices
- Admin-only access
- Staff cannot access reports


## Step 9 - Khata / Credit Management
- Sales can be completed as cash or credit/Khata.
- Credit sales record customer name, phone, bill amount, initial payment and outstanding balance.
- Staff can search customers, view Khata history, and record later payments.
- Purchase prices and profit information are not exposed in Khata management.
- Admin has the same Khata management access plus the existing admin-only purchase-price and profit-report permissions.

## Step 10 Update — Staff Inventory Grouping

Step 10 adds the Staff Inventory grouping and quantity display enhancement.

### What changed
- Identical products are grouped into a single main inventory row.
- Current available quantity is shown immediately without opening the row.
- An expand/collapse control shows the individual physical units and their existing QR/tag codes.
- Quantity remains visible when the group is expanded.
- Quantity is calculated from the existing `InventoryUnit.Status` values, so sales, returns and exchanges remain reflected automatically.
- Staff does not see purchase price or profit information.
- Admin can still see purchase price on this inventory screen.
- Existing Print Tag behavior works by selecting an expanded individual unit.
- Existing inventory search is preserved.

### Important
Open the project in Visual Studio and **Build/Rebuild** before running Step 10. The ZIP contains the previous build output from Step 9, so the executable should not be used directly without rebuilding the project.

No database schema change is required for Step 10.


## Step 12 – Enhanced Profit Report

Step 12 extends the existing Admin Profit Report without changing the original dashboard structure.

### Added
- **Stock Entered** for the selected Daily / Weekly / Monthly / Custom period.
  - Shows number of inventory units entered.
  - Shows their total purchase-cost value.
- **Stock Sold** for the selected period.
  - Shows number of units sold.
  - Shows their total sale value.
- **Current Stock** live snapshot.
  - Shows the number of currently `InStock` units.
  - Shows current stock purchase-cost value.
- Daily report table now includes:
  - Stock Entered quantity
  - Entry Value
  - Items Sold
  - Sold Stock Value
  - Sales
  - Cost
  - Gross Profit
  - Returns
  - Exchange Profit
  - Net Profit
- Existing profit, return and exchange calculations are preserved.
- Staff access to profit reports remains blocked.

### Step 12 calculation rule
- **Stock Entered** = inventory units whose `AddedAt` falls inside the selected date range.
- **Entry Value** = purchase price of those entered units.
- **Stock Sold** = sale items whose sale date falls inside the selected date range.
- **Sold Stock Value** = their sale price total.
- **Current Stock** = inventory units whose status is `InStock` at the time the report is opened.

The original UI/dashboard structure from Steps 1–11 is intentionally preserved.


## Step 13 – Salesman Codes & Commission Setup

- Admin-only Salesman & Codes module.
- Add salesman/staff name.
- Automatically assigns a unique 3-digit code from 001 to 999.
- Active/inactive status.
- Admin can define and update a commission percentage for each salesman for a selected product/suit.
- Commission percentages are restricted to 0–100%.
- Commission configuration is stored in the database for the later Sales/Salary workflow.
- Commission details are not printed on the customer bill.
- Staff users cannot access this module.

Two tables are created automatically on startup when missing:
- Salesmen
- SalesmanCommissions

Step 13 intentionally prepares the salesman master data and commission rules. The later Sales/Salary step will use these settings to attach the salesman code to a sale and calculate the earned amount.


## Step 14 — Salesman Code on Sales & Commission Recording
- Staff Sales screen now includes a 3-digit salesman-code field.
- Active salesman codes are verified before a Staff sale can be completed.
- Admin sales may leave the salesman code blank when appropriate.
- Verified salesman name and code are shown in the current bill header.
- Current sale date/time is shown in the bill header.
- The customer bill does not display commission percentage or commission amount.
- Each sold item uses the preconfigured Admin commission percentage for that salesman/product.
- Commission is calculated from the actual customer sale price.
- Commission percentage and amount are stored per SaleItem.
- Sale-level salesman name, code, ID and total commission are stored for historical reporting.
- Existing cash/Credit-Khata workflow remains unchanged.
- Existing Staff purchase-price security remains unchanged.
- Existing Admin-only purchase-price/profit permissions remain unchanged.
- Existing salesman management and commission configuration remain available to Admin.

### Step 14 database additions
Existing databases are upgraded without deleting existing sales/data. The following fields are added when missing:
- Sales.SalesmanId
- Sales.SalesmanCode
- Sales.SalesmanName
- Sales.TotalCommission
- SaleItems.CommissionPercentage
- SaleItems.CommissionAmount

## Step 15 – Salary Management & Salary Advances (Admin-only)

Step 15 adds the staff salary workflow using the salesman/staff records and commission data from Steps 13–14.

### Added
- Admin-only `SALARY MANAGEMENT` module.
- Assign/update a fixed monthly salary for each salesman/staff member.
- Current-month salesman commission is automatically read from completed sales.
- Current-month salary advances are automatically totaled.
- Remaining salary is calculated as: `Fixed Monthly Salary + Commission This Month - Advances This Month`.
- Admin can pay an advance before month-end.
- Each advance permanently records the staff member, amount, exact date/time, admin/user, and optional note.
- Advance history can be viewed for each selected staff member.
- An advance cannot exceed the staff member's current remaining salary.
- Existing salesman codes and per-product commission percentages remain unchanged.
- Commission is not shown on the customer bill; it contributes to staff salary calculation in the background.

### Database additions
- `StaffSalaries` — one fixed monthly salary record per salesman/staff member.
- `SalaryAdvances` — permanent advance-payment history.

Existing data is preserved; the new tables are created automatically if they do not already exist.


## Step 16 — Expense Management

Admin now has an Expenses module with three categories:
- Staff Salaries
- Electricity Bill
- Other

Each expense stores amount, date/time, description and the administrator who recorded it.
Expenses can be filtered by date range, reviewed, and deleted.

Profit Reports now subtract recorded expenses from the calculated shop profit:
Net Profit = Gross Profit - Return Adjustment + Exchange Profit - Expenses

Salary advances remain separately tracked in Salary Management and are not automatically inserted as a second expense, preventing accidental double-counting.


## Step 17 — Expenses Management

Step 17 adds the Admin-only Expenses module.

### Expense categories
- Staff Salaries
- Electricity Bill
- Other

### Expense record
Each record stores:
- Category
- Amount
- Description
- Date
- Time
- Recorded By

### Expense dashboard
The Admin can:
- Add an expense
- Select the expense date and time
- Filter expense history by a date range
- View category totals
- View total expenses for the selected period
- Delete a selected expense record

Expense data is stored in the `Expenses` table and is ready for the later Step 22 final profit integration.

### Step 17 changes from Step 16
- Added a dedicated expense time selector so records retain the actual entered date and time instead of always storing midnight.
- Fixed the malformed C# string in `ExpenseManagementForm.cs` that could prevent compilation.
- Kept the existing Steps 1–16 structure and functionality unchanged.


## Step 18 — Salary Management

Admin salary management is now available. Admin can select registered staff/salesmen, set their monthly fixed salary, and view a monthly salary dashboard showing fixed salary, commission earned, advances, and remaining salary. The existing salary advance/history support is retained for compatibility with the following roadmap steps.


## Step 19 — Salary Advance System
- Dedicated Admin salary-advance screen.
- Records employee, amount, date/time, admin user, and optional note.
- Current-month remaining balance is calculated from fixed salary + commission − advances.
- Advance cannot exceed the employee's available current salary balance.
- Every advance is permanently stored in SalaryAdvances and shown in history.


## STEP 21 — Final Salary Calculation

Admin-only payroll calculation for a selected month. The system combines fixed monthly salary, salesman commission, and salary advances using:

**Final Payable = Fixed Salary + Commission − Advances**

The Final Salary screen provides per-employee calculations and totals for the selected month.


## Step 24 — Security & Permissions Audit

The application uses role-based access control for the two supported roles: **Admin** and **Staff**.

### Admin-only modules
- Profit reports
- Salesman & commission management
- Product entry
- Expenses
- Salary management
- Salary advances
- Salary history
- Final salary calculation
- Purchase-cost visibility

### Staff modules
- Inventory and quantities
- Sales
- Returns
- Exchanges
- Permitted Khata/Credit operations

Staff users do not receive purchase prices, profit figures, commission percentages/amounts, salaries, salary advances, expenses, or admin financial reports.

Sensitive forms also perform an authorization check themselves; hiding a dashboard button is not treated as the only security boundary.

## Step 24 — Complete System Testing

The project now includes the final acceptance-test documentation under `Testing/`:

- `Testing/STEP24_SYSTEM_TEST_PLAN.md` — end-to-end test cases covering authentication, stock, sales, returns, exchanges, Khata, salesman commission, expenses, salaries, advances, profit and permissions.
- `Testing/FINAL_ACCEPTANCE_CHECKLIST.md` — printable PASS/FAIL acceptance checklist.

Step 24 is a validation stage rather than a new financial feature. Runtime PASS status must be confirmed on the target Windows computer because SQL Server, .NET, printer/QR hardware and database contents are environment-dependent.


## Post-Step-24 Correction — Staff Product Entry Restored

Product Entry and QR/tag generation are available to authenticated Staff users again. They were removed only from the Admin dashboard, as requested. Admin remains without a Product Entry dashboard option. Staff can use Product Entry to enter quantities/prices, generate QR tags, print tags, and add stock to inventory.


# Step 25 — Product Entry Input Cleanup + Multiple Same-Product Billing

Step 25 implements two requested changes while preserving the existing Step 24 structure and the existing per-physical-unit QR workflow.

## 1. Product Entry fields are now blank

The Product Entry form no longer displays `0.00`, `0`, or another pre-filled numeric value in the Quantity, Purchase Price, and Sale Price fields.

The fields are now normal editable text inputs with placeholders, so the workflow is simply:

1. Click the field.
2. Type the value.
3. Save the product.

Validation still prevents missing/invalid values, negative prices, and a sale price below the purchase price.

## 2. Multiple physical units of the same product can be added to one bill

The Sales screen now has a **SAME ITEM QUANTITY** control and an **ADD SAME ITEM** button.

Example:

- Inventory contains 50 Kurtas.
- Each Kurta already has its own unique automatically generated unit code, such as `UNIT-000123-0001`, `UNIT-000123-0002`, etc.
- Search for `Kurta`.
- Select one of the available Kurta physical units.
- Set `SAME ITEM QUANTITY` to `2`.
- Click `ADD SAME ITEM`.

The system selects two different available physical units of that same product and adds both to the bill. The same physical unit can never be duplicated in the same bill.

Each bill row therefore continues to represent one exact physical inventory unit and retains its own Unit Code/QR identity.

## QR / Unit-Code behavior

No change was made to the existing QR architecture. Product entry creates one `InventoryUnit` record per quantity, and each physical unit receives a unique `UnitCode`. The QR tag contains that exact `UnitCode`. This keeps scanning, returns, exchanges, stock tracking, and billing tied to the exact physical item.


## Step 27 — Exact Unit/Tag Price Tracking

Customer bills show the salesman name but not the salesman code. Each physical inventory unit's unique UnitCode/Tag Code is printed beside the product. SaleItem.SalePrice stores the actual price charged at the time of sale, including discounts. Return and exchange services use the historical SaleItem.SalePrice associated with the UnitCode rather than the current inventory SalePrice, so entering a lost tag/unit code can retrieve the exact historical transaction price.


## Step 29 — Unified Salary Management
The Admin Dashboard now has one Salary Management option. It combines monthly salary setup, commission/earnings summary, salary advances with permanent date/time history, and final monthly salary payable into one simple screen. The older separate salary dashboard options are removed from the Admin Dashboard.


## Final 3 UI Updates

- The Login page remains a normal fixed-size window.
- The Dashboard and standard application pages now open maximized.
- The Admin/Staff sidebar Logout button is anchored to the bottom-left of the sidebar instead of appearing at the top.
- The QR Tag Printing page also opens maximized.

## Final 4 – Profit Report Interface

- Reworked the Admin Profit Report to match the requested period-based financial report layout.
- Added Daily, Weekly, Monthly and Custom period selection with From/To dates and a View Report action.
- Added six summary cards: Report Period, Stock Entered, Stock Sold, Profit, Total Expenses and Net Profit.
- Added a daily period breakdown table with stock, sales, cost of goods and net profit values.
- Added a boxed period summary section showing Stock Entered, Stock Sold, Revenue, Cost of Goods, Profit from Sales, Returns, Exchange Profit, Commission, Fixed Salaries, Other Expenses, Total Expenses and Net Profit.
- The detailed report automatically updates for the selected period.
