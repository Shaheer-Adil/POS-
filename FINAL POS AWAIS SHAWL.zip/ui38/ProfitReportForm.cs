using System;
using System.Drawing;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class ProfitReportForm : Form
{
    private readonly ProfitReportService reportService = new();

    private readonly DateTimePicker startPicker = new();
    private readonly DateTimePicker endPicker = new();
    private readonly ComboBox periodCombo = new();

    private readonly Label periodLabel = new();
    private readonly Label enteredStockLabel = new();
    private readonly Label soldStockLabel = new();
    private readonly Label profitLabel = new();
    private readonly Label expensesLabel = new();
    private readonly Label netProfitLabel = new();

    private readonly Label detailStockEntered = new();
    private readonly Label detailStockSold = new();
    private readonly Label detailRevenue = new();
    private readonly Label detailCostOfGoods = new();
    private readonly Label detailProfitFromSales = new();
    private readonly Label detailReturns = new();
    private readonly Label detailExchangeProfit = new();
    private readonly Label detailCommission = new();
    private readonly Label detailFixedSalaries = new();
    private readonly Label detailOtherExpenses = new();
    private readonly Label detailTotalExpenses = new();
    private readonly Label detailNetProfit = new();

    private readonly DataGridView grid = new();
    private TableLayoutPanel? rootLayout;
    private Panel? dailySection;
    private Button? dailyToggle;
    private bool dailyReportExpanded;

    public ProfitReportForm()
    {
        if (!Session.IsAdmin)
        {
            Shown += (_, _) =>
            {
                MessageBox.Show(
                    "Only an administrator can view profit reports.",
                    "Admin Access Required",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning);
                Close();
            };
            return;
        }

        Text = "Admin - Profit Report";
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1050, 700);
        Size = new Size(1250, 820);
        BackColor = SystemColors.Control;

        BuildInterface();
        LoadDefaultPeriod();
        BackButtonHelper.AddBackButton(this);
    }

    private void BuildInterface()
    {
        var root = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(20, 10, 20, 18),
            ColumnCount = 1,
            RowCount = 4,
            BackColor = SystemColors.Control
        };

        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 65));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 215));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 40));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        rootLayout = root;
        root.Controls.Add(BuildFilters(), 0, 0);
        root.Controls.Add(BuildSummaryCards(), 0, 1);
        root.Controls.Add(BuildDailyGrid(), 0, 2);
        root.Controls.Add(BuildPeriodDetails(), 0, 3);

        Controls.Add(root);
    }

    private Control BuildFilters()
    {
        var filters = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 7,
            RowCount = 1,
            Padding = new Padding(0, 2, 0, 2)
        };

        // Small, vertically centered labels sit immediately to the left of
        // their corresponding controls so PERIOD, FROM and TO are always
        // completely visible and aligned with the middle of the inputs.
        filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 54));
        filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));
        filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 40));
        filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));
        filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 28));
        filters.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));
        filters.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
        filters.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        filters.Controls.Add(MakeLabel("PERIOD"), 0, 0);

        periodCombo.Dock = DockStyle.Fill;
        periodCombo.DropDownStyle = ComboBoxStyle.DropDownList;
        periodCombo.Items.AddRange(new object[] { "Daily", "Weekly", "Monthly", "Custom" });
        periodCombo.SelectedIndexChanged += (_, _) => ApplyPeriodSelection();
        filters.Controls.Add(periodCombo, 1, 0);

        filters.Controls.Add(MakeLabel("FROM"), 2, 0);
        filters.Controls.Add(MakeLabel("TO"), 4, 0);

        startPicker.Dock = DockStyle.Fill;
        startPicker.Format = DateTimePickerFormat.Short;
        filters.Controls.Add(startPicker, 3, 0);

        endPicker.Dock = DockStyle.Fill;
        endPicker.Format = DateTimePickerFormat.Short;
        filters.Controls.Add(endPicker, 5, 0);

        var refresh = new Button
        {
            Text = "VIEW REPORT",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            BackColor = Color.FromArgb(63, 103, 235),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(0, 0, 0, 0)
        };
        refresh.FlatAppearance.BorderSize = 0;
        refresh.Click += (_, _) => LoadReport();
        filters.Controls.Add(refresh, 6, 0);

        return filters;
    }

    private Control BuildSummaryCards()
    {
        var cards = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 3,
            RowCount = 2,
            Padding = new Padding(0, 4, 0, 4)
        };

        for (var i = 0; i < 3; i++)
            cards.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.333f));

        for (var i = 0; i < 2; i++)
            cards.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

        cards.Controls.Add(MakeCard("REPORT PERIOD", periodLabel), 0, 0);
        cards.Controls.Add(MakeCard("STOCK ENTERED", enteredStockLabel), 1, 0);
        cards.Controls.Add(MakeCard("STOCK SOLD", soldStockLabel), 2, 0);
        cards.Controls.Add(MakeCard("PROFIT", profitLabel), 0, 1);
        cards.Controls.Add(MakeCard("TOTAL EXPENSES", expensesLabel), 1, 1);
        cards.Controls.Add(MakeCard("NET PROFIT", netProfitLabel), 2, 1);

        return cards;
    }

    private Control BuildDailyGrid()
    {
        ConfigureGrid();

        dailySection = new Panel
        {
            Dock = DockStyle.Fill,
            BorderStyle = BorderStyle.FixedSingle,
            Padding = new Padding(0),
            BackColor = SystemColors.Control
        };

        dailyToggle = new Button
        {
            Text = "DAY WISE REPORT  ▼",
            Dock = DockStyle.Top,
            Height = 42,
            TextAlign = ContentAlignment.MiddleLeft,
            Padding = new Padding(12, 0, 12, 0),
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            BackColor = SystemColors.Control,
            ForeColor = SystemColors.ControlText,
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(0)
        };
        dailyToggle.FlatAppearance.BorderSize = 0;
        dailyToggle.Click += (_, _) => ToggleDailyReport();

        grid.Visible = false;
        dailySection.Controls.Add(grid);
        dailySection.Controls.Add(dailyToggle);
        dailyReportExpanded = false;

        return dailySection;
    }

    private void ToggleDailyReport()
    {
        if (rootLayout is null || dailySection is null || dailyToggle is null)
            return;

        dailyReportExpanded = !dailyReportExpanded;
        grid.Visible = dailyReportExpanded;
        dailyToggle.Text = dailyReportExpanded
            ? "DAY WISE REPORT  ▲"
            : "DAY WISE REPORT  ▼";

        rootLayout.RowStyles[2].SizeType = SizeType.Absolute;
        rootLayout.RowStyles[2].Height = dailyReportExpanded ? 300 : 44;
        rootLayout.PerformLayout();
        dailySection.PerformLayout();
    }

    private Control BuildPeriodDetails()
    {
        var outer = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true,
            Padding = new Padding(0, 4, 0, 0)
        };

        var title = new Label
        {
            Text = "WEEKLY REPORT",
            Dock = DockStyle.Top,
            Height = 28,
            Font = new Font("Segoe UI", 10, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        };
        outer.Controls.Add(title);

        var details = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            ColumnCount = 2,
            RowCount = 12,
            CellBorderStyle = TableLayoutPanelCellBorderStyle.Single,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        details.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 65));
        details.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35));

        AddDetailRow(details, 0, "Stock Entered", detailStockEntered);
        AddDetailRow(details, 1, "Stock Sold", detailStockSold);
        AddDetailRow(details, 2, "Revenue", detailRevenue);
        AddDetailRow(details, 3, "Cost of Goods", detailCostOfGoods);
        AddDetailRow(details, 4, "Profit from Sales", detailProfitFromSales);
        AddDetailRow(details, 5, "Returns", detailReturns);
        AddDetailRow(details, 6, "Exchange Profit", detailExchangeProfit);
        AddDetailRow(details, 7, "Commission", detailCommission);
        AddDetailRow(details, 8, "Fixed Salaries", detailFixedSalaries);
        AddDetailRow(details, 9, "Other Expenses", detailOtherExpenses);
        AddDetailRow(details, 10, "Total Expenses", detailTotalExpenses);
        AddDetailRow(details, 11, "Net Profit", detailNetProfit);

        outer.Controls.Add(details);
        return outer;
    }

    private static void AddDetailRow(TableLayoutPanel table, int row, string name, Label value)
    {
        table.RowStyles.Add(new RowStyle(SizeType.Absolute, 31));

        var label = new Label
        {
            Text = name,
            Dock = DockStyle.Fill,
            Padding = new Padding(12, 5, 5, 5),
            Font = new Font("Segoe UI", 9),
            TextAlign = ContentAlignment.MiddleLeft
        };

        value.Dock = DockStyle.Fill;
        value.Padding = new Padding(5, 5, 12, 5);
        value.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        value.TextAlign = ContentAlignment.MiddleRight;

        table.Controls.Add(label, 0, row);
        table.Controls.Add(value, 1, row);
    }

    private void LoadDefaultPeriod()
    {
        periodCombo.SelectedItem = "Daily";
        ApplyPeriodSelection();
        LoadReport();
    }

    private void ApplyPeriodSelection()
    {
        if (periodCombo.SelectedItem is not string selected)
            return;

        var today = DateTime.Today;

        switch (selected)
        {
            case "Daily":
                startPicker.Value = today;
                endPicker.Value = today;
                break;

            case "Weekly":
                var monday = today.AddDays(
                    -(int)today.DayOfWeek +
                    (today.DayOfWeek == DayOfWeek.Sunday ? -6 : 1));
                startPicker.Value = monday;
                endPicker.Value = monday.AddDays(6);
                break;

            case "Monthly":
                startPicker.Value = new DateTime(today.Year, today.Month, 1);
                endPicker.Value = new DateTime(
                    today.Year,
                    today.Month,
                    DateTime.DaysInMonth(today.Year, today.Month));
                break;
        }
    }

    private void LoadReport()
    {
        if (endPicker.Value.Date < startPicker.Value.Date)
        {
            MessageBox.Show(
                "The end date cannot be earlier than the start date.",
                "Invalid Dates",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        try
        {
            var period = periodCombo.SelectedItem?.ToString() ?? "Custom";
            var start = startPicker.Value.Date;
            var end = endPicker.Value.Date;

            var summary = reportService.GetSummary(start, end, period);

            periodLabel.Text =
                $"{summary.StartDate:dd-MMM-yyyy} → {summary.EndDate:dd-MMM-yyyy}";

            enteredStockLabel.Text =
                $"{Money(summary.StockEnteredValue)}\r\n" +
                $"{summary.StockEnteredItems} units";

            soldStockLabel.Text =
                $"{Money(summary.SoldStockValue)}\r\n" +
                $"{summary.SoldStockItems} units";

            profitLabel.Text = Money(summary.GrossProfit);
            expensesLabel.Text = Money(summary.TotalOperatingExpenses);
            netProfitLabel.Text = Money(summary.NetProfit);

            detailStockEntered.Text =
                $"{Money(summary.StockEnteredValue)} ({summary.StockEnteredItems} units)";
            detailStockSold.Text =
                $"{Money(summary.SoldStockValue)} ({summary.SoldStockItems} units)";
            detailRevenue.Text = Money(summary.Revenue);
            detailCostOfGoods.Text = Money(summary.CostOfGoods);
            detailProfitFromSales.Text = Money(summary.GrossProfit);
            detailReturns.Text =
                $"{Money(summary.ReturnedSales)} ({summary.ItemsReturned} item(s))";
            detailExchangeProfit.Text =
                $"{Money(summary.ExchangeProfit)} ({summary.Exchanges} exchange(s))";
            detailCommission.Text = Money(summary.CommissionExpense);
            detailFixedSalaries.Text = Money(summary.FixedSalaryExpense);
            detailOtherExpenses.Text = Money(summary.OtherExpenses);
            detailTotalExpenses.Text = Money(summary.TotalOperatingExpenses);
            detailNetProfit.Text = Money(summary.NetProfit);

            // The heading follows the selected period instead of always saying Weekly.
            if (Controls.Count > 0)
            {
                // Find the details title without adding another public control field.
                // The fourth row contains the period details panel.
                if (Controls[0] is TableLayoutPanel root && root.GetControlFromPosition(0, 3) is Panel panel)
                {
                    foreach (Control control in panel.Controls)
                    {
                        if (control is Label label && label.Dock == DockStyle.Top)
                        {
                            label.Text = $"{period.ToUpperInvariant()} REPORT";
                            break;
                        }
                    }
                }
            }

            grid.DataSource = reportService.GetDailyBreakdown(start, end);
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Could not load the profit report.\r\n\r\n" + ex.Message,
                "Report Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private void ConfigureGrid()
    {
        grid.Dock = DockStyle.Fill;
        grid.ReadOnly = true;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.AutoGenerateColumns = false;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = false;
        grid.RowHeadersVisible = false;
        grid.BackgroundColor = SystemColors.Window;
        grid.BorderStyle = BorderStyle.None;
        grid.EnableHeadersVisualStyles = true;
        grid.ColumnHeadersHeight = 32;
        grid.DefaultCellStyle = new DataGridViewCellStyle
        {
            Font = new Font("Segoe UI", 9),
            SelectionBackColor = Color.FromArgb(30, 120, 210),
            SelectionForeColor = Color.White,
            Padding = new Padding(5, 0, 5, 0)
        };
        grid.ColumnHeadersDefaultCellStyle = new DataGridViewCellStyle
        {
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            Alignment = DataGridViewContentAlignment.MiddleLeft
        };

        AddColumn("Date", "DATE", "dd-MMM-yyyy");
        AddColumn("StockEnteredItems", "STOCK ENTERED", "N0");
        AddColumn("StockEnteredValue", "STOCK VALUE", "#,##0.##");
        AddColumn("ItemsSold", "ITEMS SOLD", "N0");
        AddColumn("Revenue", "REVENUE", "#,##0.##");
        AddColumn("CostOfGoods", "COST OF GOODS", "#,##0.##");
        AddColumn("NetProfit", "NET PROFIT", "#,##0.##");
    }

    private void AddColumn(string property, string header, string format)
    {
        grid.Columns.Add(new DataGridViewTextBoxColumn
        {
            DataPropertyName = property,
            HeaderText = header,
            SortMode = DataGridViewColumnSortMode.NotSortable,
            DefaultCellStyle = new DataGridViewCellStyle
            {
                Format = format,
                Alignment = DataGridViewContentAlignment.MiddleLeft
            }
        });
    }

    private static Label MakeLabel(string text) => new()
    {
        Text = text,
        Dock = DockStyle.Fill,
        AutoSize = false,
        AutoEllipsis = false,
        TextAlign = ContentAlignment.MiddleRight,
        Font = new Font("Segoe UI", 6, FontStyle.Bold),
        Padding = new Padding(0, 0, 3, 0),
        Margin = new Padding(0)
    };

    private static Panel MakeCard(string title, Label value)
    {
        var panel = new Panel
        {
            Dock = DockStyle.Fill,
            Margin = new Padding(4),
            BorderStyle = BorderStyle.FixedSingle,
            Padding = new Padding(12)
        };

        var heading = new Label
        {
            Text = title,
            Dock = DockStyle.Top,
            Height = 30,
            Font = new Font("Segoe UI", 8, FontStyle.Bold),
            TextAlign = ContentAlignment.MiddleLeft
        };

        value.Dock = DockStyle.Fill;
        value.Font = new Font("Segoe UI", 11, FontStyle.Bold);
        value.TextAlign = ContentAlignment.MiddleLeft;
        value.AutoEllipsis = true;

        panel.Controls.Add(value);
        panel.Controls.Add(heading);
        return panel;
    }

    private static string Money(decimal value) => $"PKR {value:#,##0.##}";
}
