# UI Fix 37

- Changed every standard Back button to a red button with black text, without changing its text or navigation behavior.
- Updated the Admin and Staff dashboard sidebar branding from "AWAIS SHOP" to "Awais Shawl".
- Applied a cursive font to the "Awais Shawl" sidebar branding.
- No other functional or UI changes were made.
