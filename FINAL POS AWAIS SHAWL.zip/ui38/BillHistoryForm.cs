using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Windows.Forms;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class BillHistoryForm : Form
{
    private readonly DataGridView historyGrid = new();
    private readonly Label infoLabel = new();
    private readonly Button printButton = new();
    private readonly BillHistoryService service = new();
    private List<BillHistoryItem> bills = new();

    public BillHistoryForm()
    {
        Text = "Bill History - Last 3 Bills";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(900, 500);
        Size = new Size(1050, 650);

        BuildLayout();
        LoadHistory();
        BackButtonHelper.AddBackButton(this);
    }

    private void BuildLayout()
    {
        var title = new Label
        {
            Text = "LAST 3 COMPLETED BILLS",
            Dock = DockStyle.Top,
            Height = 55,
            Padding = new Padding(20, 15, 20, 5),
            Font = new Font("Segoe UI", 16, FontStyle.Bold)
        };

        infoLabel.Text = "These completed bills remain available here for reprinting if the printer fails or power is interrupted.";
        infoLabel.Dock = DockStyle.Top;
        infoLabel.Height = 45;
        infoLabel.Padding = new Padding(20, 0, 20, 5);
        infoLabel.Font = new Font("Segoe UI", 9);

        ConfigureGrid();

        var bottom = new TableLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 80,
            Padding = new Padding(20, 10, 20, 15),
            ColumnCount = 2
        };
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        bottom.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220));

        printButton.Text = "REPRINT SELECTED BILL";
        printButton.Dock = DockStyle.Fill;
        printButton.Font = new Font("Segoe UI", 10, FontStyle.Bold);
        printButton.Click += (_, _) => ReprintSelectedBill();
        printButton.Enabled = false;
        bottom.Controls.Add(new Label { Dock = DockStyle.Fill }, 0, 0);
        bottom.Controls.Add(printButton, 1, 0);

        Controls.Add(historyGrid);
        Controls.Add(bottom);
        Controls.Add(infoLabel);
        Controls.Add(title);
    }

    private void ConfigureGrid()
    {
        historyGrid.Dock = DockStyle.Fill;
        historyGrid.ReadOnly = true;
        historyGrid.AllowUserToAddRows = false;
        historyGrid.AllowUserToDeleteRows = false;
        historyGrid.AutoGenerateColumns = false;
        historyGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        historyGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        historyGrid.MultiSelect = false;
        historyGrid.RowHeadersVisible = false;

        AddColumn("InvoiceNumber", "Invoice", 1.4f);
        AddColumn("SaleDate", "Date / Time", 1.7f);
        AddColumn("TotalAmount", "Total (Rs.)", 1.1f, "N0");
        AddColumn("PaymentType", "Payment", 1.3f);
        AddColumn("SoldBy", "Processed By", 1.2f);
        AddColumn("SalesmanName", "Salesman", 1.2f);

        historyGrid.SelectionChanged += (_, _) => printButton.Enabled = historyGrid.CurrentRow?.DataBoundItem is BillHistoryItem;
        historyGrid.DoubleClick += (_, _) => ReprintSelectedBill();
    }

    private void AddColumn(string propertyName, string header, float weight, string? format = null)
    {
        var column = new DataGridViewTextBoxColumn
        {
            DataPropertyName = propertyName,
            HeaderText = header,
            FillWeight = weight,
            SortMode = DataGridViewColumnSortMode.NotSortable
        };

        if (!string.IsNullOrWhiteSpace(format))
            column.DefaultCellStyle.Format = format;

        historyGrid.Columns.Add(column);
    }

    private void LoadHistory()
    {
        try
        {
            bills = service.GetLastThreeBills();
            historyGrid.DataSource = bills;
            printButton.Enabled = bills.Count > 0;

            infoLabel.Text = bills.Count == 0
                ? "No completed bills are available yet."
                : $"The latest {bills.Count} completed bill(s) are stored here and can be reprinted at any time.";
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "Could not load bill history.\r\n\r\n" + ex.Message,
                "Bill History Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }

    private void ReprintSelectedBill()
    {
        if (historyGrid.CurrentRow?.DataBoundItem is not BillHistoryItem bill)
        {
            MessageBox.Show(
                "Select a bill first.",
                "No Bill Selected",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        PrintBill(bill);
    }

    private void PrintBill(BillHistoryItem bill)
    {
        try
        {
            using var document = new PrintDocument();
            document.DocumentName = $"Bill-{bill.InvoiceNumber}";

            const int receiptWidth = 330;
            int receiptHeight = Math.Clamp(330 + (bill.Items.Count * 42), 450, 2000);
            var receiptPaper = new PaperSize("Receipt 83mm", receiptWidth, receiptHeight);

            document.DefaultPageSettings.PaperSize = receiptPaper;
            document.DefaultPageSettings.Margins = new Margins(8, 8, 8, 8);
            document.DefaultPageSettings.Landscape = false;

            document.PrintPage += (_, e) =>
            {
                using var titleFont = new Font("Segoe UI", 15, FontStyle.Bold);
                using var sectionFont = new Font("Segoe UI", 10, FontStyle.Bold);
                using var bodyFont = new Font("Segoe UI", 9);
                using var smallFont = new Font("Segoe UI", 8);

                float y = 35;
                float left = e.MarginBounds.Left;
                float right = e.MarginBounds.Right;

                e.Graphics.DrawString("Awais Shall", titleFont, Brushes.Black, left, y);
                y += 32;
                e.Graphics.DrawString("SALES BILL / INVOICE", sectionFont, Brushes.Black, left, y);
                y += 22;
                e.Graphics.DrawString($"Invoice No: {bill.InvoiceNumber}", bodyFont, Brushes.Black, left, y);
                y += 18;
                e.Graphics.DrawString($"Date / Time: {bill.SaleDate:dd-MMM-yyyy hh:mm:ss tt}", bodyFont, Brushes.Black, left, y);
                y += 18;
                e.Graphics.DrawString($"Processed By: {bill.SoldBy}", bodyFont, Brushes.Black, left, y);
                y += 18;

                if (!string.IsNullOrWhiteSpace(bill.SalesmanName))
                {
                    e.Graphics.DrawString($"Salesman: {bill.SalesmanName}", bodyFont, Brushes.Black, left, y);
                    y += 18;
                }

                e.Graphics.DrawLine(Pens.Black, left, y, right, y);
                y += 10;
                e.Graphics.DrawString("ITEMS", sectionFont, Brushes.Black, left, y);
                y += 22;

                int index = 1;
                foreach (var item in bill.Items)
                {
                    e.Graphics.DrawString($"{index}. {item.ProductName}", bodyFont, Brushes.Black, left, y);
                    y += 18;
                    e.Graphics.DrawString($"   Unit/Tag: {item.UnitCode}", smallFont, Brushes.Black, left + 8, y);
                    e.Graphics.DrawString($"Rs. {item.SalePrice:N0}", bodyFont, Brushes.Black, right - 105, y);
                    y += 20;
                    index++;
                }

                e.Graphics.DrawLine(Pens.Black, left, y, right, y);
                y += 10;
                e.Graphics.DrawString($"Items: {bill.Items.Count}", bodyFont, Brushes.Black, left, y);
                y += 20;
                e.Graphics.DrawString($"TOTAL: Rs. {bill.TotalAmount:N0}", sectionFont, Brushes.Black, left, y);
                y += 22;
                e.Graphics.DrawString($"Payment Type: {bill.PaymentType}", bodyFont, Brushes.Black, left, y);
                y += 28;
                e.Graphics.DrawString("Thank you for shopping with us.", smallFont, Brushes.Black, left, y);
                y += 16;
                e.Graphics.DrawString("This bill contains the complete sale transaction details.", smallFont, Brushes.Black, left, y);

                e.HasMorePages = false;
            };

            document.Print();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "The selected bill is safely stored in history, but it could not be printed.\r\n\r\n" +
                "Please check that a printer is installed and available.\r\n\r\n" + ex.Message,
                "Reprint Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
        }
    }
}
