# Step 24 — Complete System Testing

This document is the final acceptance test plan for the Shop Management System.

## Preconditions

1. Build/Rebuild the solution before testing.
2. Start SQL Server and make sure the application's configured database is reachable.
3. Start the application.
4. Use the real Admin and Staff accounts configured for this installation.
5. Use test products/units so production inventory is not affected.
6. Keep screenshots of any failed test and record the exact date/time.

## Test A — Authentication & Roles

| ID | Test | Expected Result |
|---|---|---|
| A1 | Start application | Login screen appears before dashboard |
| A2 | Valid Admin login | Admin dashboard opens |
| A3 | Valid Staff login | Staff dashboard opens |
| A4 | Invalid password | Login is rejected |
| A5 | Unknown/invalid role | Dashboard access is rejected |
| A6 | Logout/clear session | Sensitive forms cannot be accessed as previous user |

## Test B — Product Entry / Stock Integrity

| ID | Test | Expected Result |
|---|---|---|
| B1 | Add a product with purchase price, sale price and quantity 50 | 50 physical inventory units are created |
| B2 | Generate/print tags | One tag is produced for each physical unit |
| B3 | Confirm inventory | Available quantity is 50 |
| B4 | Expand grouped product | Individual physical units/tags are shown |
| B5 | Sell one unit | Quantity becomes 49 |
| B6 | Return that exact unit | Quantity becomes 50 and same unit code is restored |
| B7 | Exchange a unit | Original unit returns to stock and replacement becomes sold |
| B8 | Repeat return/exchange on an already processed unit | Operation is rejected |

## Test C — Sales

| ID | Test | Expected Result |
|---|---|---|
| C1 | Scan a valid tag | Correct product/unit appears |
| C2 | Enter unit number when QR fails | Correct unit appears |
| C3 | Search by product name/code | Matching products appear for selection |
| C4 | Change customer sale price | New price is accepted only when it is >= purchase price |
| C5 | Complete cash sale | Bill is generated and inventory decreases |
| C6 | Complete credit/Khata sale | Customer balance is recorded correctly |
| C7 | Enter valid salesman code | Salesman name/code is attached to the sale |
| C8 | Enter invalid/inactive salesman code | Sale is blocked or code is rejected according to workflow |
| C9 | Bill visibility | Purchase price, commission percentage and commission amount are not shown to staff/customer |

## Test D — Returns & Exchanges

| ID | Test | Expected Result |
|---|---|---|
| D1 | Return by QR/tag | Exact sold unit is found |
| D2 | Return by unit number | Exact unit is found |
| D3 | Return by product search | Matching units are listed and exact unit can be selected |
| D4 | Process return | Unit status becomes InStock |
| D5 | Exchange with higher replacement price | Difference is calculated correctly |
| D6 | Exchange with lower replacement price | Difference/refund is calculated correctly |
| D7 | Exchange with equal price | Difference is zero |
| D8 | Stock after exchange | No duplicate physical unit is created |

## Test E — Khata / Credit

| ID | Test | Expected Result |
|---|---|---|
| E1 | Create credit sale | Customer balance is created |
| E2 | Search customer | Customer and outstanding balance are shown |
| E3 | Record payment | Outstanding balance decreases correctly |
| E4 | View Khata as Staff | Permitted customer/balance information is visible |
| E5 | View Khata as Staff | Purchase price and profit remain hidden |

## Test F — Salesman & Commission

| ID | Test | Expected Result |
|---|---|---|
| F1 | Add salesman | Unique 3-digit code is assigned |
| F2 | Configure product/suit commission | Percentage is stored |
| F3 | Sell using salesman code | Correct salesman is attached to sale |
| F4 | Multiple sales | Commission accumulates correctly |
| F5 | Return a commission-bearing sale | Corresponding commission is adjusted according to the return logic |

## Test G — Expenses

| ID | Test | Expected Result |
|---|---|---|
| G1 | Add Fixed Salary expense | Category and amount are stored |
| G2 | Add Electricity expense | Category and amount are stored |
| G3 | Add Other expense | Description, date/time and amount are stored |
| G4 | View expense totals | Category totals and overall total are correct |
| G5 | Delete an incorrect expense | Record is removed only when authorized |

## Test H — Salary & Advances

| ID | Test | Expected Result |
|---|---|---|
| H1 | Register employee salary | Monthly fixed salary is stored |
| H2 | View salary dashboard | Fixed salary, commission, advances and remaining salary are correct |
| H3 | Pay advance | Permanent advance record is created with date/time |
| H4 | Pay second advance | Total advances accumulate |
| H5 | Excessive advance | System prevents an invalid amount according to configured balance rule |
| H6 | Salary history | Advance history remains permanently visible |
| H7 | Final salary | Fixed salary + commission - advances = final payable |

## Test I — Profit Reports

| ID | Test | Expected Result |
|---|---|---|
| I1 | Daily report | Revenue, cost, gross profit and adjustments are correct |
| I2 | Weekly report | Weekly totals match underlying transactions |
| I3 | Monthly report | Monthly totals match underlying transactions |
| I4 | Custom date range | Only transactions in the selected range are included |
| I5 | Commission integration | Commission is separated from gross profit |
| I6 | Salary/expense integration | Operating costs are separated and deducted once |
| I7 | Net profit | Final net profit matches the defined formula |

## Test J — Security / Permissions

### Staff must NOT see

- Purchase Price
- Profit
- Commission percentage
- Commission amount
- Salary Management
- Salary Advances
- Salary History
- Final Salary
- Expenses
- Admin financial reports

### Staff CAN see

- Inventory
- Quantity
- Sales
- Returns
- Exchanges
- Permitted Khata information
- Salesman name/date/time on the bill

### Admin CAN see

- Purchase prices
- Profit reports
- Commission configuration and ledger
- Expenses
- Salaries
- Salary advances/history
- Khata
- Inventory

## Test K — Financial Reconciliation

Use one controlled test period and calculate independently:

`Revenue - Cost of Goods = Gross Profit`

`Gross Profit - Commission - Salaries - Other Expenses +/− required return/exchange adjustments = Net Profit`

Verify the application report against the independent calculation.

## Test L — Final Acceptance

The project is accepted only when:

- All critical tests A–K pass.
- No stock duplication occurs.
- No purchase price is exposed to Staff.
- No Admin-only financial data is exposed to Staff.
- Salary advances remain permanently recorded.
- Commission and salary figures are not double-counted.
- Profit reports reconcile with transaction data.
- The database opens and updates without data loss.
- The application can be closed and reopened without losing saved records.

## Result Recording

For each test, record: **PASS / FAIL / NOT TESTED**, plus a note and screenshot for failures.

> Step 24 is a final acceptance/testing stage. Runtime PASS status must be confirmed on the target Windows computer because it depends on the installed .NET runtime, SQL Server configuration, database contents, printer/QR hardware, and real transaction data.
