using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Data;
using ShopManagementSystem.Models;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class SalaryAdvanceForm : Form
{
    private readonly SalaryService service = new();
    private readonly ComboBox staffBox = new();
    private readonly Label salaryLabel = new();
    private readonly Label commissionLabel = new();
    private readonly Label advancesLabel = new();
    private readonly Label remainingLabel = new();
    private readonly Label statusLabel = new();
    private readonly NumericUpDown amountBox = new();
    private readonly TextBox notesBox = new();
    private readonly DataGridView historyGrid = new();

    public SalaryAdvanceForm()
    {
        if (!AuthorizationService.RequireAdmin(this, "Salary advances"))
            return;

        Text = "Salary Advance Management";
        StartPosition = FormStartPosition.CenterScreen;
        Size = new Size(1100, 720);
        MinimumSize = new Size(950, 620);
        BuildUi();
        LoadStaff();
            BackButtonHelper.AddBackButton(this);
}

    private void BuildUi()
    {
        var root = new TableLayoutPanel { Dock = DockStyle.Fill, Padding = new Padding(18), ColumnCount = 1, RowCount = 4 };
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 78));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 105));
        root.RowStyles.Add(new RowStyle(SizeType.Absolute, 125));
        root.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        root.Controls.Add(new Label
        {
            Text = "SALARY ADVANCES\r\nRecord advance payments and automatically deduct them from the employee's current salary balance.",
            Dock = DockStyle.Fill, Font = new Font("Segoe UI", 15, FontStyle.Bold), TextAlign = ContentAlignment.MiddleLeft
        }, 0, 0);

        var selector = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4 };
        selector.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 140));
        selector.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        selector.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 100));
        selector.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 55));
        selector.Controls.Add(new Label { Text = "EMPLOYEE", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) }, 0, 0);
        staffBox.Dock = DockStyle.Fill; staffBox.DropDownStyle = ComboBoxStyle.DropDownList; staffBox.SelectedIndexChanged += (_, _) => RefreshSelected();
        selector.Controls.Add(staffBox, 1, 0);
        selector.Controls.Add(new Label { Text = "STATUS", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) }, 2, 0);
        statusLabel.Text = "Select an employee"; statusLabel.Dock = DockStyle.Fill; statusLabel.TextAlign = ContentAlignment.MiddleLeft; statusLabel.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        selector.Controls.Add(statusLabel, 3, 0);
        root.Controls.Add(selector, 0, 1);

        var stats = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 4, Padding = new Padding(0, 8, 0, 8) };
        AddStat(stats, 0, "FIXED SALARY", salaryLabel);
        AddStat(stats, 1, "COMMISSION THIS MONTH", commissionLabel);
        AddStat(stats, 2, "ADVANCES THIS MONTH", advancesLabel);
        AddStat(stats, 3, "REMAINING", remainingLabel);
        root.Controls.Add(stats, 0, 2);

        var lower = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 1, RowCount = 2 };
        lower.RowStyles.Add(new RowStyle(SizeType.Absolute, 92));
        lower.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var payment = new TableLayoutPanel { Dock = DockStyle.Fill, ColumnCount = 5 };
        payment.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 145));
        payment.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 24));
        payment.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45));
        payment.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 15));
        payment.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 16));
        payment.Controls.Add(new Label { Text = "ADVANCE AMOUNT", Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleLeft, Font = new Font("Segoe UI", 9, FontStyle.Bold) }, 0, 0);
        amountBox.Dock = DockStyle.Fill; amountBox.DecimalPlaces = 0; amountBox.Maximum = 100000000; amountBox.ThousandsSeparator = true; amountBox.Text = string.Empty; amountBox.Enter += (_, _) => { if (amountBox.Value == 0) amountBox.Text = string.Empty; }; amountBox.MouseDown += (_, _) => { if (amountBox.Value == 0) amountBox.Text = string.Empty; };
        payment.Controls.Add(amountBox, 1, 0);
        notesBox.Dock = DockStyle.Fill; notesBox.PlaceholderText = "Reason / note (optional)";
        payment.Controls.Add(notesBox, 2, 0);
        var pay = new Button { Text = "PAY & RECORD", Dock = DockStyle.Fill, Font = new Font("Segoe UI", 9, FontStyle.Bold) }; pay.Click += (_, _) => PayAdvance();
        payment.Controls.Add(pay, 3, 0);
        var refresh = new Button { Text = "REFRESH", Dock = DockStyle.Fill }; refresh.Click += (_, _) => { LoadStaff(); RefreshSelected(); };
        payment.Controls.Add(refresh, 4, 0);
        lower.Controls.Add(payment, 0, 0);

        ConfigureGrid();
        lower.Controls.Add(historyGrid, 0, 1);
        root.Controls.Add(lower, 0, 3);
        Controls.Add(root);
    }

    private static void AddStat(TableLayoutPanel panel, int col, string title, Label value)
    {
        var box = new Panel { Dock = DockStyle.Fill, BorderStyle = BorderStyle.FixedSingle, Margin = new Padding(5), Padding = new Padding(8) };
        var titleLabel = new Label { Text = title, Dock = DockStyle.Top, Height = 25, Font = new Font("Segoe UI", 8, FontStyle.Bold) };
        value.Text = "Rs. 0"; value.Dock = DockStyle.Fill; value.Font = new Font("Segoe UI", 13, FontStyle.Bold); value.TextAlign = ContentAlignment.MiddleLeft;
        box.Controls.Add(value); box.Controls.Add(titleLabel); panel.Controls.Add(box, col, 0);
    }

    private void ConfigureGrid()
    {
        historyGrid.Dock = DockStyle.Fill; historyGrid.ReadOnly = true; historyGrid.AllowUserToAddRows = false; historyGrid.AutoGenerateColumns = false; historyGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect; historyGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        historyGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Date", HeaderText = "DATE / TIME", FillWeight = 24 });
        historyGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Amount", HeaderText = "AMOUNT", FillWeight = 18 });
        historyGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "PaidBy", HeaderText = "PAID BY", FillWeight = 18 });
        historyGrid.Columns.Add(new DataGridViewTextBoxColumn { Name = "Notes", HeaderText = "NOTE", FillWeight = 40 });
    }

    private void LoadStaff()
    {
        try
        {
            using var db = new ShopDbContext();
            var current = staffBox.SelectedItem as StaffChoice;
            var list = db.Salesmen.AsNoTracking().Where(x => x.IsActive).OrderBy(x => x.Name).Select(x => new StaffChoice(x.SalesmanId, x.Name, x.Code)).ToList();
            staffBox.DataSource = null; staffBox.DataSource = list; staffBox.DisplayMember = nameof(StaffChoice.Display); staffBox.ValueMember = nameof(StaffChoice.Id);
            if (current != null) { var found = list.FindIndex(x => x.Id == current.Id); if (found >= 0) staffBox.SelectedIndex = found; }
        }
        catch (Exception ex) { MessageBox.Show("Could not load employees.\r\n\r\n" + ex.Message, "Salary Advances", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void RefreshSelected()
    {
        if (staffBox.SelectedItem is not StaffChoice staff) { ClearSummary(); return; }
        try
        {
            var summary = service.GetCurrentSummary(staff.Id);
            salaryLabel.Text = $"Rs. {summary.MonthlySalary:#,##0.##}";
            commissionLabel.Text = $"Rs. {summary.CommissionThisMonth:#,##0.##}";
            advancesLabel.Text = $"Rs. {summary.AdvancesThisMonth:#,##0.##}";
            remainingLabel.Text = $"Rs. {summary.RemainingSalary:#,##0.##}";
            statusLabel.Text = summary.RemainingSalary > 0 ? "Advance available" : "No salary balance available";
            LoadHistory(staff.Id);
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Salary Advances", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private void ClearSummary()
    { salaryLabel.Text = commissionLabel.Text = advancesLabel.Text = remainingLabel.Text = "Rs. 0"; historyGrid.Rows.Clear(); }

    private void LoadHistory(int salesmanId)
    {
        historyGrid.Rows.Clear();
        foreach (var row in service.GetAdvanceHistory(salesmanId)) historyGrid.Rows.Add(row.PaidAt.ToString("dd-MMM-yyyy hh:mm tt"), $"Rs. {row.Amount:#,##0.##}", row.PaidBy, row.Notes);
    }

    private void PayAdvance()
    {
        if (staffBox.SelectedItem is not StaffChoice staff) { MessageBox.Show("Select an employee first.", "Salary Advance", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
        if (amountBox.Value <= 0) { MessageBox.Show("Enter an advance amount greater than zero.", "Salary Advance", MessageBoxButtons.OK, MessageBoxIcon.Information); return; }
        try
        {
            var paidBy = Session.CurrentUser?.Username ?? "Admin";
            service.AddAdvance(staff.Id, amountBox.Value, paidBy, notesBox.Text, true);
            MessageBox.Show($"Rs. {amountBox.Value:#,##0.##} advance recorded for {staff.Name}.\r\nThe amount has been deducted from the current salary balance.", "Advance Recorded", MessageBoxButtons.OK, MessageBoxIcon.Information);
            amountBox.Value = 0; amountBox.Text = string.Empty; notesBox.Clear(); RefreshSelected();
        }
        catch (Exception ex) { MessageBox.Show(ex.Message, "Could Not Record Advance", MessageBoxButtons.OK, MessageBoxIcon.Error); }
    }

    private sealed record StaffChoice(int Id, string Name, string Code)
    { public string Display => $"{Name} ({Code})"; }
}
