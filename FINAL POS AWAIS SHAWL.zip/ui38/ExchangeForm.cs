using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using Microsoft.EntityFrameworkCore;
using ShopManagementSystem.Services;

namespace ShopManagementSystem;

public class ExchangeForm : Form
{
    private readonly TextBox originalSearchBox = new();
    private readonly DataGridView originalGrid = new();

    private readonly TextBox replacementSearchBox = new();
    private readonly DataGridView replacementGrid = new();

    private readonly NumericUpDown replacementPriceBox = new();
    private readonly TextBox reasonBox = new();

    private readonly Label originalLabel = new();
    private readonly Label replacementLabel = new();
    private readonly Label differenceLabel = new();

    private readonly ExchangeService service = new();

    private List<ExchangeOriginalResult> originals = new();
    private List<ExchangeReplacementResult> replacements = new();

    private bool IsAdmin =>
        string.Equals(Session.CurrentUser?.Role, "Admin", StringComparison.OrdinalIgnoreCase);

    public ExchangeForm()
    {
        Text = "Product Exchange";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(1200, 750);
        Size = new Size(1400, 850);

        var top = BuildTop();
        var body = BuildBody();
        var footer = BuildFooter();

        Controls.Add(body);
        Controls.Add(footer);
        Controls.Add(top);
        BackButtonHelper.AddBackButton(this);

        Shown += (_, _) => originalSearchBox.Focus();
    }

    private Control BuildTop()
    {
        var panel = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 150,
            Padding = new Padding(20),
            ColumnCount = 4,
            RowCount = 2
        };

        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 170));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 150));
        panel.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 230));

        panel.Controls.Add(new Label
        {
            Text = "ORIGINAL ITEM",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        }, 0, 0);

        originalSearchBox.Dock = DockStyle.Fill;
        originalSearchBox.Font = new Font("Consolas", 12);
        originalSearchBox.PlaceholderText = "Scan returned tag or search unit/product";
        originalSearchBox.KeyDown += OriginalSearch_KeyDown;
        panel.Controls.Add(originalSearchBox, 1, 0);

        var originalButton = new Button
        {
            Text = "FIND ORIGINAL",
            Dock = DockStyle.Fill
        };
        originalButton.Click += (_, _) => SearchOriginal();
        panel.Controls.Add(originalButton, 2, 0);

        panel.Controls.Add(new Label
        {
            Text = IsAdmin
                ? "ADMIN: Purchase prices visible"
                : "STAFF: Purchase prices hidden",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 8, FontStyle.Bold)
        }, 3, 0);

        panel.Controls.Add(new Label
        {
            Text = "REPLACEMENT ITEM",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleLeft,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        }, 0, 1);

        replacementSearchBox.Dock = DockStyle.Fill;
        replacementSearchBox.Font = new Font("Consolas", 12);
        replacementSearchBox.PlaceholderText = "Scan QR or search available replacement";
        replacementSearchBox.KeyDown += ReplacementSearch_KeyDown;
        panel.Controls.Add(replacementSearchBox, 1, 1);

        var replacementButton = new Button
        {
            Text = "FIND REPLACEMENT",
            Dock = DockStyle.Fill
        };
        replacementButton.Click += (_, _) => SearchReplacement();
        panel.Controls.Add(replacementButton, 2, 1);

        panel.Controls.Add(new Label
        {
            Text = "Only InStock physical units can be selected.",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 8)
        }, 3, 1);

        return panel;
    }

    private Control BuildBody()
    {
        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            Orientation = Orientation.Vertical,
            SplitterDistance = 660,
            Padding = new Padding(20, 0, 20, 0)
        };

        var left = new Panel { Dock = DockStyle.Fill };
        var leftTitle = new Label
        {
            Text = "ORIGINAL SOLD ITEM",
            Dock = DockStyle.Top,
            Height = 32,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        };
        ConfigureOriginalGrid();
        left.Controls.Add(originalGrid);
        left.Controls.Add(leftTitle);

        var right = new Panel { Dock = DockStyle.Fill };
        var rightTitle = new Label
        {
            Text = "AVAILABLE REPLACEMENT",
            Dock = DockStyle.Top,
            Height = 32,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        };
        ConfigureReplacementGrid();
        right.Controls.Add(replacementGrid);
        right.Controls.Add(rightTitle);

        split.Panel1.Controls.Add(left);
        split.Panel2.Controls.Add(right);

        return split;
    }

    private Control BuildFooter()
    {
        var footer = new TableLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 145,
            Padding = new Padding(20, 10, 20, 15),
            ColumnCount = 4,
            RowCount = 2
        };

        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 210));
        footer.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 190));

        originalLabel.Text = "Original: not selected";
        originalLabel.Dock = DockStyle.Fill;
        originalLabel.TextAlign = ContentAlignment.MiddleLeft;
        footer.Controls.Add(originalLabel, 0, 0);

        replacementLabel.Text = "Replacement: not selected";
        replacementLabel.Dock = DockStyle.Fill;
        replacementLabel.TextAlign = ContentAlignment.MiddleLeft;
        footer.Controls.Add(replacementLabel, 0, 1);

        footer.Controls.Add(new Label
        {
            Text = "REPLACEMENT SALE PRICE",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 8, FontStyle.Bold)
        }, 1, 0);

        replacementPriceBox.DecimalPlaces = 0;
        replacementPriceBox.Maximum = 100000000;
        replacementPriceBox.Increment = 100;
        replacementPriceBox.ThousandsSeparator = true;
        replacementPriceBox.Text = string.Empty;
        replacementPriceBox.Enter += (_, _) => { if (replacementPriceBox.Value == 0) replacementPriceBox.Text = string.Empty; };
        replacementPriceBox.MouseDown += (_, _) => { if (replacementPriceBox.Value == 0) replacementPriceBox.Text = string.Empty; };
        replacementPriceBox.Dock = DockStyle.Fill;
        replacementPriceBox.ValueChanged += (_, _) => UpdateDifference();
        footer.Controls.Add(replacementPriceBox, 1, 1);

        footer.Controls.Add(new Label
        {
            Text = "RETURN / EXCHANGE REASON",
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = new Font("Segoe UI", 8, FontStyle.Bold)
        }, 2, 0);

        reasonBox.Dock = DockStyle.Fill;
        reasonBox.PlaceholderText = "Optional";
        footer.Controls.Add(reasonBox, 2, 1);

        differenceLabel.Text = "Difference: select both items";
        differenceLabel.Dock = DockStyle.Fill;
        differenceLabel.TextAlign = ContentAlignment.MiddleCenter;
        differenceLabel.Font = new Font("Segoe UI", 9, FontStyle.Bold);
        footer.Controls.Add(differenceLabel, 3, 0);

        var exchangeButton = new Button
        {
            Text = "PROCESS EXCHANGE",
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 10, FontStyle.Bold)
        };
        exchangeButton.Click += (_, _) => ProcessExchange();
        footer.Controls.Add(exchangeButton, 3, 1);

        return footer;
    }

    private void ConfigureOriginalGrid()
    {
        originalGrid.Dock = DockStyle.Fill;
        originalGrid.ReadOnly = true;
        originalGrid.AllowUserToAddRows = false;
        originalGrid.AutoGenerateColumns = false;
        originalGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        originalGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        originalGrid.MultiSelect = false;

        AddColumn(originalGrid, "UnitCode", "Tag", 100);
        AddColumn(originalGrid, "ProductName", "Product", 120);
        AddColumn(originalGrid, "ProductCode", "Code", 85);
        AddColumn(originalGrid, "OriginalSalePrice", "Old Sale Price", 100, "N0");
        AddColumn(originalGrid, "InvoiceNumber", "Invoice", 105);

        if (IsAdmin)
            AddColumn(originalGrid, "PurchasePrice", "Purchase Price", 100, "N0");

        originalGrid.SelectionChanged += (_, _) => UpdateOriginal();
        originalGrid.DoubleClick += (_, _) => UpdateOriginal();
        originalGrid.DataError += Grid_DataError;
    }

    private void ConfigureReplacementGrid()
    {
        replacementGrid.Dock = DockStyle.Fill;
        replacementGrid.ReadOnly = true;
        replacementGrid.AllowUserToAddRows = false;
        replacementGrid.AutoGenerateColumns = false;
        replacementGrid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        replacementGrid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        replacementGrid.MultiSelect = false;

        AddColumn(replacementGrid, "UnitCode", "Tag", 100);
        AddColumn(replacementGrid, "ProductName", "Product", 120);
        AddColumn(replacementGrid, "ProductCode", "Code", 85);
        AddColumn(replacementGrid, "SalePrice", "Current Sale Price", 105, "N0");

        if (IsAdmin)
            AddColumn(replacementGrid, "PurchasePrice", "Purchase Price", 100, "N0");

        replacementGrid.SelectionChanged += (_, _) => UpdateReplacement();
        replacementGrid.DoubleClick += (_, _) => UpdateReplacement();
        replacementGrid.DataError += Grid_DataError;
    }

    private void Grid_DataError(object? sender, DataGridViewDataErrorEventArgs e)
    {
        // A grid can briefly report a stale row index while its DataSource is
        // being detached after a completed exchange. Do not show the default
        // WinForms modal error dialog; the reset below safely clears the grid.
        e.ThrowException = false;
    }

    private void ResetExchangeGrids()
    {
        // IMPORTANT: detach the DataSource BEFORE clearing the backing lists.
        // Clearing a List<T> while DataGridView is still bound to it can leave
        // WinForms with a stale current-row index ("Index 0 does not have a value").
        originalGrid.CurrentCell = null;
        replacementGrid.CurrentCell = null;
        originalGrid.DataSource = null;
        replacementGrid.DataSource = null;
        originals.Clear();
        replacements.Clear();
        originalGrid.ClearSelection();
        replacementGrid.ClearSelection();
    }

    private static void AddColumn(
        DataGridView grid,
        string property,
        string header,
        int weight,
        string? format = null)
    {
        var c = new DataGridViewTextBoxColumn
        {
            DataPropertyName = property,
            HeaderText = header,
            FillWeight = weight
        };

        if (format != null)
            c.DefaultCellStyle = new DataGridViewCellStyle { Format = format };

        grid.Columns.Add(c);
    }

    private void OriginalSearch_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            SearchOriginal();
        }
    }

    private void ReplacementSearch_KeyDown(object? sender, KeyEventArgs e)
    {
        if (e.KeyCode == Keys.Enter)
        {
            e.SuppressKeyPress = true;
            SearchReplacement();
        }
    }

    private void SearchOriginal()
    {
        var query = originalSearchBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(query))
            return;

        var exact = service.FindOriginal(query);

        if (exact != null)
        {
            originals = new List<ExchangeOriginalResult> { exact };
        }
        else
        {
            originals = service.SearchOriginals(query);
        }

        originalGrid.DataSource = null;
        originalGrid.DataSource = originals;

        if (originals.Count == 0)
        {
            originalLabel.Text = "Original: no eligible sold item found";
            MessageBox.Show(
                "No eligible sold item was found. Search by tag/unit number, product code, or product name.",
                "Original Item Not Found",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        originalGrid.Rows[0].Selected = true;
        UpdateOriginal();
    }

    private void SearchReplacement()
    {
        var query = replacementSearchBox.Text.Trim();
        if (string.IsNullOrWhiteSpace(query))
            return;

        // Exact tag first, otherwise name/code search.
        using var db = new ShopManagementSystem.Data.ShopDbContext();

        var exact = db.InventoryUnits
            .AsNoTracking()
            .Where(x => x.UnitCode == query && x.Status == "InStock")
            .Select(x => new ExchangeReplacementResult
            {
                InventoryUnitId = x.InventoryUnitId,
                UnitCode = x.UnitCode,
                ProductName = x.Product!.ProductName,
                ProductCode = x.Product.ProductCode,
                SalePrice = x.SalePrice,
                PurchasePrice = x.PurchasePrice,
                Status = x.Status
            })
            .SingleOrDefault();

        replacements = exact != null
            ? new List<ExchangeReplacementResult> { exact }
            : service.SearchAvailableReplacement(query);

        replacementGrid.DataSource = null;
        replacementGrid.DataSource = replacements;

        if (replacements.Count == 0)
        {
            replacementLabel.Text = "Replacement: no available unit found";
            MessageBox.Show(
                "No InStock replacement unit was found. Search by tag/unit number, product code, or product name.",
                "Replacement Not Found",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        replacementGrid.Rows[0].Selected = true;
        UpdateReplacement();
    }

    private ExchangeOriginalResult? GetOriginal()
    {
        return originalGrid.CurrentRow?.DataBoundItem as ExchangeOriginalResult;
    }

    private ExchangeReplacementResult? GetReplacement()
    {
        return replacementGrid.CurrentRow?.DataBoundItem as ExchangeReplacementResult;
    }

    private void UpdateOriginal()
    {
        var item = GetOriginal();

        if (item == null)
        {
            originalLabel.Text = "Original: not selected";
            return;
        }

        originalLabel.Text =
            $"Original: {item.ProductName} | {item.UnitCode} | Rs. {item.OriginalSalePrice:N0}";

        if (GetReplacement() == null)
            replacementPriceBox.Value = 0;

        UpdateDifference();
    }

    private void UpdateReplacement()
    {
        var item = GetReplacement();

        if (item == null)
        {
            replacementLabel.Text = "Replacement: not selected";
            return;
        }

        replacementLabel.Text =
            $"Replacement: {item.ProductName} | {item.UnitCode} | Rs. {item.SalePrice:N0}";

        replacementPriceBox.Value =
            Math.Min(replacementPriceBox.Maximum, item.SalePrice);

        UpdateDifference();
    }

    private void UpdateDifference()
    {
        var original = GetOriginal();
        var replacement = GetReplacement();

        if (original == null || replacement == null)
        {
            differenceLabel.Text = "Difference: select both items";
            return;
        }

        var diff = replacementPriceBox.Value - original.OriginalSalePrice;

        if (diff > 0)
            differenceLabel.Text = $"Customer pays: Rs. {diff:N0} more";
        else if (diff < 0)
            differenceLabel.Text = $"Customer refund: Rs. {Math.Abs(diff):N0}";
        else
            differenceLabel.Text = "No price difference";
    }

    private void ProcessExchange()
    {
        var original = GetOriginal();
        var replacement = GetReplacement();

        if (original == null)
        {
            MessageBox.Show(
                "Select the original sold item first.",
                "Original Item Required",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        if (replacement == null)
        {
            MessageBox.Show(
                "Select an available replacement item.",
                "Replacement Required",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);
            return;
        }

        if (replacement.InventoryUnitId == original.InventoryUnitId)
        {
            MessageBox.Show(
                "The original and replacement cannot be the same physical unit.",
                "Invalid Exchange",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        if (replacementPriceBox.Value < replacement.PurchasePrice)
        {
            MessageBox.Show(
                "The replacement sale price cannot be lower than its purchase price.",
                "Invalid Sale Price",
                MessageBoxButtons.OK,
                MessageBoxIcon.Warning);
            return;
        }

        var difference = replacementPriceBox.Value - original.OriginalSalePrice;

        var amountText = difference > 0
            ? $"Customer pays Rs. {difference:N0} additional."
            : difference < 0
                ? $"Customer receives Rs. {Math.Abs(difference):N0} refund."
                : "There is no price difference.";

        var confirm = MessageBox.Show(
            $"Confirm exchange?\n\n" +
            $"OLD:\n{original.ProductName}\n{original.UnitCode}\n" +
            $"Original sale price: Rs. {original.OriginalSalePrice:N0}\n\n" +
            $"NEW:\n{replacement.ProductName}\n{replacement.UnitCode}\n" +
            $"Replacement sale price: Rs. {replacementPriceBox.Value:N0}\n\n" +
            amountText,
            "Confirm Exchange",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (confirm != DialogResult.Yes)
            return;

        try
        {
            var result = service.CompleteExchange(
                original,
                replacement,
                replacementPriceBox.Value,
                Session.CurrentUser?.Username ?? "Staff",
                reasonBox.Text);

            MessageBox.Show(
                $"Exchange completed successfully.\n\n" +
                $"Old unit: {result.OriginalUnitCode} → InStock\n" +
                $"New unit: {result.ReplacementUnitCode} → Sold\n\n" +
                $"{result.Message}",
                "Exchange Completed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information);

            originalSearchBox.Clear();
            replacementSearchBox.Clear();
            reasonBox.Clear();
            ResetExchangeGrids();
            originalLabel.Text = "Original: not selected";
            replacementLabel.Text = "Replacement: not selected";
            differenceLabel.Text = "Difference: select both items";
            replacementPriceBox.Value = 0;
            originalSearchBox.Focus();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                ex.Message,
                "Exchange Could Not Be Completed",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
